Apollo VCL (tm) 
Version 6.1.0.8
Oct. 6th, 2003

For Borland Delphi 5,6,7 and C++Builder 5,6

(c) 1999-2003 Vista Software. All rights reserved.
www.vistasoftware.com
------------------------------------------------------------

This README.TXT file contains last minute changes and various other 
important and helpful information to get you started.

* Get the FREE LITE versions DBF-Desktop and dbfUtils, which allow you 
* to visually create and manage your data structures. Download here:
* http://www.vistasoftware.com/apollo_utilities.asp

	A) Installation and Deployment
	B) InfoPower Support
	C) Upgrading From Apollo 4.x/5.x to Apollo VCL 6.1
	D) Delphi 5, 6, 7 Installation
	E) C++Builder 5, 6 Installation   
	F) Using with Apollo SQL 6.1
	G) New/Changes
	
-------------------------------------------------------
A) Installation and Deployment

To deploy an Apollo VCL application, you must copy the following
files to your destination computer:

	C:\Apollo\SDE61\SDE*.DLL
	to
	C:\WinNT\System32
	-or-
	C:\Windows\System

If your application uses SQL, then you must also deploy the following:

	C:\Apollo\SQL61\ApolloSQL61.DLL
	to
	C:\WinNT\System32
	-or-
	C:\Windows\System
-------------------------------------------------------
B) InfoPower

ApolloTB.pas is located in Apollo's \InfoPower sub-directory. It is included 
for InfoPower users who wish to connect InfoPower components to an 
TApolloTable object. 

-------------------------------------------------------
C) Upgrading From Apollo 4.x/5.x to Apollo VCL 6.1

See the ApolloVCL6.hlp file for tips on upgrading existing projects 
from Apollo 4.x/5.x to 6.1

-------------------------------------------------------
D) Delphi Installation

Note: Delphi Trial Editions are not supported by the Apollo VCL Evaluation Edition. 
However, the full version of Apollo VCL does support the Delphi Trial Editions

Substitue D? with your version of Delphi (e.g. D7 = Delphi 7)
Open the (.DPK) file and build the package to install:

1. From the IDE, select 'File | Open Project'.  
2. In the Open File dialog, change the 'Files of type' dropdown list to show all 
   'Delphi Package (*.dpk)' files. 
3. Select C:\Apollo\VCL61\D?\Apollo6D?.DPK (runtime package)
4. Click the 'Compile' button.
5. Open C:\Apollo\VCL61\D?\Apollo6D?d.DPK file (designtime package)
6. Click the 'Install' button.

You should receive a confirmation message dialog that shows you the names of the
new components that have been added to the component palette. These will be under
a tab labeled 'Apollo'. Select 'Tools | Environment Options' from the main menu. 

From this dialog, select the 'Library' tab and insure that the directory name 
where the new Apollo6D7.BPL (D7), Apollo6D6.BPL (D6) or Apollo6D5.BPL (D5) file is 
listed in the 'Library Path'.

-------------------------------------------------------
E) C++Builder Installation
Substitue CB? with your version of C++Builder (e.g. CB6 = C++Builder 6)
   
1. From the IDE, select 'File | Open Project'.  
2. Change the 'Files of type' dropdown list to either show all 'C++Builder project 
   (*.bpr, *.bpg, *.bpk)' or 'C++Builder package (*.bpk)' files. 
3. Select C:\Apollo\VCL61\CB?\Apollo6CB?.BPK (runtime package)
4. Click the 'Compile' button. 
5. Open C:\Apollo\VCL61\CB?\Apollo6CB?d.DPK file (designtime package)
6. Click the 'Install' button.

You should receive a confirmation message dialog that shows you the names of the
new components that have been added to the component palette. These will be under 
a tab labeled 'Apollo'. 

From the main menu, select 'Tools | Environment Options'. Select the 'Library' 
tab and insure that the directory name where the new Apollo6CB?.BPL file is 
listed in the 'Library Path'.

Note: If you receive "Unable to open ApoDSet.hpp", then you will need to add
	C:\Apollo\VCL61\CB6 or \CB5
to your:
	Project Options -> Directories -> Include path

Note: You may need to copy the Apollo6CB6.BPL/Apollo6CB5.BPL to 
c:\Program Files\Borland\C++Builder6\Projects\BPL 
-or-
c:\Program Files\Borland\C++Builder5\Projects\BPL

-------------------------------------------------------
F) Using with Apollo SQL 6.1

Apollo SQL is designed to work with Apollo VCL's TApolloQuery component. 
Setting TApolloQuery.AccessMethod to amLocal will let you use SQL in 
local mode.

Drop a TApolloConnection component on the form and connect the TApolloQuery 
component to it through the ApolloConnection property.  For local SQL use, 
the TApolloConnection component does not need to be active. 

Set the TApolloQuery.DatabaseName property to the physical drive and path 
where the data is located, or specify an alias defined within a TApolloDatabase 
component.

Important: Because DBF tables are actually individual files, you must populate 
the TApolloQuery.TableNames property with the list of tables you will be 
referencing in the query. 

Click on the TApolloQuery.TableNames property to open the TableNames list. 
Right-click on the TableNames property editor and add the tables. 
Set the TableName, TableType and Alias for each table. Close the property 
editor when done.

You can also do this in code using SetTables(). See the help for details.

The actual SQL statements are set in TApolloQuery.SQL property.  
See the Apollo SQL help file for a syntax reference.

To open a Query that returns a result set (i.e. Select), call 
TApolloQuery.Open or set TApolloQuery.Active to True. 
To issue a SELECT statement, or call ExecSQL to issue a DDL command 
(UPDATE, DELTE, INSERT, CREATE TABLE, etc�).

Important 
TApolloQuery.AccessMethod determines is the Apollo Database Server is used 
(amServer) to manage the data or if the local ApolloSQL61.DLL is used to 
manage the data (amLocal).

TApolloQuery.ApolloConnection must be set to a TApolloConnection at all times 
- either local or in server mode. 

When the TApolloConnection component is set to amLocal and uses Apollo SQL,
the Active, Host, Port, User, and Password properties of the connectionstring 
are ignored. Those properties are used only when connecting to an Apollo Server.  
Progress of the SQL operation can be tracked through the TApolloConnection events, 
such as OnServerProgress, when using Apollo SQL on local tables.

-------------------------------------------------------
G) New/Changes

v5.1.1.0 (04-06-00):
- Added new support for C++Builder 5.0.
- Optimistic Buffering was not properly defaulting to False. This has been FIXED.
- Setting the Filter property at run-time was not always working properly.  This has 
  been FIXED.
- Using the CTOD xBase function in an index or filter expression with date values
  greater than 2000 were not always being evaluated properly unless SetCentury was 
  True.  This has been FIXED.
- Setting fields to type fkLookup at design-time would sometimes result in a run-time
  error.  This has been FIXED.
- The IndexDefs.FindIndexForFields method was only working for non-expression indexes.
  This has been FIXED.
- With a filter active, sliding the thumbnail down in a DBGrid could result in a 
  'Record Not Found' message.  This has been FIXED.
- For remote tables with Apollo Database Server, the GetBlob method was returning
  a blob length value that was one byte too large.  This has been FIXED.

v5.1.2.0 (04-20-00):
- Improved client/server performance of TApolloTable when used with the Apollo 
  Database Server.  The speed on remote table access with TApolloTable now 
  approaches that already found in TApolloQuery.  This involved changes in both 
  the TApolloTable component as well as the Apollo Database Server application.
- Added support for the use of IS NULL and IS NOT NULL in the WHERE clause of an 
  SQL SELECT statement within TApolloQuery. See the updated ApolloSQL help file 
  for specific details of this new functionality.
- Improved performance of TApolloTable's Next, Prior, and MoveBy methods when 
  SpeedMode is set to True.
- Improved the on-line documentation (.HLP) files.
- Changed TApolloTable.Version property value to no longer be stored in the .DFM.
- Added support for Locate method in TApolloQuery. 
- Fixed obscure Access Violation error that could occur within a DBGrid after 
  moving the horizontal scroll bar all the way to the right and then resizing the
  grid view to display more rows.
- Fixed an issue where, on remote tables being accessed via TApolloQuery, 
  conditional indexes would sometimes erroneously be used to optimize SQL 
  expressions.  This change was actually made within the Apollo Database Server 
  application. 
- Fixed an issue where TApolloTable.BlobToFile could fail on remote tables 
  accessed through the Apollo Database Server when the field name is less than 
  10 bytes long.
- Attempting to create a new table where a field contains an invalid field name
  (using CreateField) now raises an exception.
- Attempting to open a table with TApolloTable through the Apollo Database Server
  without TApolloConnection's User and Password properties set now raises an 
  exception.
- TApolloEnv.OpenDataSets would not always open all tables. This has been FIXED.

v5.1.3.0 (05-15-00):
- Added support for using new ApolloSQL add-in with TApolloQuery on local tables.
  A new AccessMethod property has been added to TApolloQuery in support of this.
  This property defaults to amServer, to be backwards compatible with existing
  applications that are already communicating with the Apollo Database Server. For
  more information on using TApolloQuery on local tables using the new ApolloSQL 
  add-in, please visit the Vista Software web site (www.ApolloDatabase.com).
- Added support for using parameters in the SQL statements.  For example, given an 
  SQL statement like "SELECT FROM Test WHERE (Last = :LastName)", you can set 
  TApolloQuery.ParamByName('LastName').AsString to the desired Last name value 
  and then open the query.  See the TApolloQuery.Params property in the Apollo VCL 
  help file or the SELECT command in the ApolloSQL help file for additional details. 
- Added support for SetTranslated (ANSI/OEM) support on tables opened through a SQL
  SELECT statement using TApolloQuery.  See the TApolloQuery.TableNames property in
  the Apollo VCL help file for additional details.
- Clipper .NTX indexes would not always sort in the correct order. This has been
  FIXED.
- When using the Apollo Database Server, a JOIN call could result in a lock-up with
  certain index expressions.  This has been FIXED.
- After inserting a new record, the Bookmark property may not have been properly 
  initialized.  This has been FIXED.
- TApolloTable.GetTrimString was not handling date values properly for international
  date formats. This has been FIXED.
- The FieldCount method could return an incorrect value for some Visual FoxPro tables.
  This has been FIXED.
- Creating a new table in code on a dynamically-created TApolloTable object (not from
  a component dropped on the form) could result in an error.  This has been FIXED.
- Miscellaneous additions and corrections to the on-line help files.

NOTE:  You must now include the ApCommon unit in your USES line when using the 
       TApolloTableType (ttSXFOX, ttSXNSX, ttSXNTX) or TAccessMethod (amLocal or 
       amServer) types in your code.

v5.1.4.0 (07-26-00):
- Optimized the time required to open remote tables/indexes with TApolloTable via 
  Apollo Database Server. 
- Added new FetchCount property to TApolloTable to allow multiple records to be
  read from the remote server when using AccessMethod = amServer.  The default is
  fifty (50). Increasing this value will speed up the time required when scrolling 
  through the table on faster network connections.  For example, with a FetchCount 
  value of 100, a call to the server is only required once for each 100 records 
  scrolled -- to fetch the next 100.  
- The default value of TApolloQuery.FetchCount has been increased from 50 to 100.
- The OpenDataSets, CloseDataSets, and RefreshDataSets routines now also work for 
  components that inherit from TApolloTable, TApolloEnv, and TApolloDatabase.
- The xBase TRIM function would not work properly on values that were already
  trimmed.  One extra byte would be trimmed from the end of the string.  This has
  been FIXED.
- Added additional TTable-emulation support for the following methods under 
  TApolloTable:
   AddIndex    
   ApplyRange  
   CloseIndexFile
   CreateTable
   DeleteIndex
   EditKey
   EditRangeEnd
   EditRangeStart
   FindNearest
   GotoCurrent
   GotoKey
   GotoNearest
   OpenIndexFile  
   SetKey
   SetRangeEnd
   SetRangeStart  

- String parameters containing a colon (:) or a single or double quote that are 
  passed to a parameterized query are now supported in TApolloQuery.
- EvalString, EvalNumeric, and EvalLogical were not working properly on tables
  being accessed via the Apollo Database Server.  This has been FIXED.
- Fixed a small memory leak when opening and closing tables. Also fixed other
  leaks related to freeing of the TApolloTable object.
- Storing values to one-byte character fields could fail. This has been FIXED.
- Using LIKE in an SQL statement was not always being processed correctly.
  This has been FIXED.
- SetScope parameters on tables opened through the Apollo Database Server were
  being trimmed of trailing spaces.  The trailing spaces are now preserved.
- A Seek on tables opened through the Apollo Database Server would not always
  properly refresh to the found record.  This has been FIXED.
- Using TApolloQuery to access blob data greater than 64k could raise an error.
  This has been FIXED.
- A problem with LEFT OUTER JOINs has been addressed.
- An issue where TApolloTable.FileToBlob was not always working properly on 
  remote tables has been resolved.
- Error-handling on tables accessed through the Apollo Database Server has been
  enhanced.
- JOIN operations using a WHERE clause are now optimized and are much faster 
  than in previous releases.
- Appending large amounts of new records to a CDX index could result in an 
  Access Violation.  This has been FIXED.
- Using the SQL UPDATE command to replace memo data longer than 256 bytes was 
  failing.  This has been FIXED.
- After posting a newly appended records, the record pointer was not always being 
  positioned on the last record, but was placed on the second to last record.  
  This has been FIXED.
- Doing a Print Preview with QuickReports could result in a 3200 Error (Invalid
  Workarea). This has been FIXED.
- Miscellaneous other code optimizations, clean-up, and documentation updates.

v5.1.4.1 (08-13-00):
- CopyFileText and AppendFrom (when using a text file) were not working properly.  
  These have been FIXED. 
- Setting a Scope on an NTX index could result in an incorrect view.  This was 
  specific to NTX and has been FIXED.
- A GotoBookmark issue under TApolloQuery that could result in a 'Record not found'
  message has been FIXED. 
- When using SetTranslate on a HiPer-SIx (ttSXNSX) table that was also using a 
  MEMO field, the memo pointer value was not always stored properly.  This has been
  FIXED.
- Calling FilterDlg could result in an Access Violation.  This has been FIXED.
- On remote tables under the Apollo Database Server, the EOF flag would return 
  True in some cases where it should have reported False.  This has been FIXED.
- On a Master/Detail relationship, the RecCount value would sometimes report the 
  record count of the incorrect table.  This has been FIXED.
- Using TApolloQuery, if no records were contained in an SQL result set, an empty
  record was appearing in an attached DBGrid.  This has been FIXED.

v5.1.4.2 (08-20-00):
- When executing an SQLstatement that did not return any rows, a blank row could
  be displayed in the grid.  This has been FIXED.
- An issue that could cause parameterized queries to fail to execute has been fixed. 
- An issue that could cause TApolloEnv.RefreshDataSets to go into an endless loop 
  has been fixed.

v5.1.4.3 (08-27-00):
- AfterScroll event now fires when controls are disabled.
- Calling Refresh with a filter active could result in an endless loop of Skips. 
- Fixed a bug in refreshing (Resync) an RYO index when dropping a KEY.
- SQL LIKE expressions were not always handling matches properly. 
- ApolloTable.CreateTable was not properly resolving the data path from the alias.  
- ApolloQuery.GotoBookmark was not working on the last record. 

v5.1.4.4 (10-03-00):
- The complete Apollo VCL component source is now included. 
- Opening and closing different queries pointing to the same tables several times 
  could cause an AV in the .EXE or an SQL_prepare error. FIXED. 
- When calling TApolloEnv.OpenDataSet, if a fault occurred opening one table 
  between several tables, the rest of the files remained closed. Now, when open a 
  file faults, the rest of them are still opened. 
- Enhanced TCP/IP performance in Apollo Database Server. 
- TApolloTable.RecCount property was not being updated correctly after AppendFrom. 
  FIXED. 
- With the BDE, if a string field has spaces, the value of the field always 
  returned an empty string. With Apollo, when a string field has spaces, the Value 
  property returned a string with spaces when the record is not posted and returned 
  an empty string when the record was posted. FIXED. 
- When using a TApolloTable for an encrypted table using SetPassword, if you change 
  your TableName, the other table was affected with the password and it is being 
  wrongly encrypted. FIXED. 
- Dropping the first record from a RYO index then calling GoTop would result in a 
  dataset that contains ONLY the record you dropped. FIXED. 
- Behavior of Like and = operator in TApolloQuery behaved differently than BDE 
  TQuery. FIXED. 
- Calling TApolloTable.SetScope With NTX caused slowness when two instances pointed 
  to the same physical table. FIXED. 
- "Record Not Found" message appeares when grouping columns using dxDBGrid from 
  DevExpress. FIXED. 
- "Invalid argument to encode date" message appeared when using OnFilterEvent and 
  Filter/Filtered properties. FIXED. 
- AutoRefresh did not work as expected. FIXED. 
- Problem opening NSX file with long field names. FIXED. 
- NTX with SetTranslate using regional settings other than U.S. caused index to 
  behave incorrectly. FIXED. 
- Dates shown as 0/0/0000 instead of as blank when using TApolloQuery. FIXED. 
- Adding records to a table by code caused DBGrid to act bizarre when you did not 
  have U.S. Regional settings, and when using SetTranslate. FIXED. 
- Incorrect data sorting using SQL with TApolloQuery. FIXED. 

----------------------------------------------------------------
v5.2 (03-25-01)
5.2 is a significant update. Many issues were fixed and some optimization
was introduced. List to be posted on the website.
-  DBGrid became stuck while traversing certain tables if the size of the Grid 
   was the exact height to hold all records. If it was bigger no problem. Fixed.
-  Inconsistent result of TApolloTable.KeyData depending on the index expression.
   It would return the complete key value or it may not. Fixed.
-  Changing certain field values for a given record caused the DBGrid to enter 
   into an infinite loop   

SDE
-  A FOR clause in an index sometimes causes FoxPro to not find records. Fixed.
-  Some seek operations would fail using International characters. Fixed.
-  Extremely slow appending records using NSX indexes. Fixed.

SQL
-  Apollo SQL now make proper use of indexes to improve query speed results.
   Huge performance gains of anywhere from 10x to 50x (or more) can now
   be acheived when using SELECT. 
-  Using TApolloQuery, sorting on memofields would cause memo data to not appear 
   in dataaware components. Fixed.
-  Sporadic query results returned. Fixed.
-  An empty result from TApolloQuery would cause an AV with QuickReports when 
   you try to print.Fixed.
-  Executing a SQL statement affected other TApolloTables that were scoped. Fixed.
-  When a SQL query using "like" and "%" was executed, it affected subsequent
   uses of ApolloTable.Query. Fixed.
-  Issueing a SQL command cleared some Master/Detail relationships set by 
   MasterSource/Fields and SetScope methods. Fixed.
-  SQL now performs left joins correctly.
-  TApolloSQL didn't support Calculated or LookupFields. Fixed.
-  If a query returns a single record, and then later another query is issed 
   that returns multiple records, the pointer seems "stuck" on the first record 
   and does not allow you to move from there. Fixed.
-  Support for new operators '=>' and '=<' in the FOR clause of Queries, has been 
   added for backwards compatibility with FoxPro 
-  A join with an AND condition in where clause causeed an "Unable to execute" 
   error. Fixed.
-  Certain SQL results didn't work when you combined a date comparison and other 
   fields in the WHERE clause. Fixed.
-  Certain SQL statements return inexplicable "dummydate" error. Fixed.
-  NSX slowness. A query performed when on a table with an index active was actually 
   slower than without the index. Fixed.
----------------------------------------------------------------
v5.2 (05-10-01)
VCL
- Fixed memory leak in client/server mode when opening and closing tables
- Fixed FetchCount with non-even values
- SetTranslate() has been changed to a published property called "OEMTranslate"

SDE
- When calling sx_SetDeleted(..) while a Table is open, the Timestamp of
   the Table change to current date during sx_Close, even if the table was not
   altered. FIXED
-  Added support to set constant 2005/SDE_SP_BDESPECIFIC using sx_SysProp
   which toggles LIKE behavior to be compatible with either BDE or Oracle.
   BDE behavior is the default.
-  Usage of operators AND, OR and NOT raised incorrect results for Query. FIXED.
   Caused indirectly by LIKE operator implementation in previous build.
- Added new xBase operator 'LIKE'.  Respects standard SQL LIKE operator, 
   except standard specified 'escape' symbol.

SQL
- Added support for ALTER TABLE
----------------------------------------------------------------
v5.2.0.1 (08-02-01)
VCL
- Added support for Delphi 6

SDE
- New 5.2.0.8 version included.
1. Fixed improper treatment for Hong-Kong regional settings
2. sx_SetScope now truncates string values containing double quotes
3. Fixed incorrect treatment of soft-carriage and escape in FPT memo fields
4. Fixed incorrect automatic unlock in sx_Commit before file buffers were flushed 
    and user's sx_Unlock was applied
5. Added automatic merging of lines for single memo field in FTP
6. Added ability to set User delimiter symbol for sx_AppendFrom and sx_CopyFileText 
   calls with new sx_SetUserDelimiter method;
----------------------------------------------------------------
v5.2.0.6 (08-21-01)
- CachedUpdates property has been removed

SQL
- Greatly improved date and boolean data access.

SDE
- New 5.2.0.11 version included. See SDE readme for details.
----------------------------------------------------------------
v5.2.0.7 (09-05-01)
- New 30-day evals are valid for all customers even if you have previously evaluated 
  an Apollo product, you may re-install these new evals
- minor optimizations 
- New \Samples\Delphi\SQL\SQL.dpr sample
----------------------------------------------------------------
v5.2.0.8 (09-30-01)
- Problem with multi-select DBgrid. Fixed.
- Calling AppendRecord inside a BeforePost event would cause a blank record to be 
  added to the wrong table. Fixed.
- Inserting records using Quantum Grid's TdxDbLookupCombo would cause 
  "Invalid variant conversion". Fixed.
- SetOrder. Fixed.
- New C++Builder sample on how to use Nevrona's RAVE reporter
   (See: C:\Apollo5\VCL\Samples\CBuilder\ServerDLL)
   Contributed by: Scott Prokopetz 

----------------------------------------------------------------
v5.2.0.9 (11-12-01)
- RAVE 4 DIBL support added for Nevrona's RAVE Report engine.
- InfoPower 2000 and 3000 CompareBookmarks issue fixed.
- Added new CommitLevel added to both TApolloQuery and TApolloTable.
- TApolloQuery TableNames property also supports CommitLevel for individual
   tables referenced by the SQL
- Users of OptimisticCommit should migrate to CommitLevel.
- CommitLevel supported in SQL inline definitions:

  ApolloQuery1.SQL.Text := 'Update MyData Set First = "ASDF"'+
                           '[* TableName:Test.dbf, Alias:MyData,
			   CommitLevel:clNormal *]';
- Creating a new table via code using CreateNew failed to set "TableName" 
  based on the FileName. Fixed.
- Calling Locate on an empty Query result caused an AV instead of 
   returning False. Fixed.
- TApolloTable.Query() now supports IsNull( <field>, <boolean> )
	e.g. 
	IsNull("LAST", True) is like calling IsNull("LAST")
	IsNull("LAST", False) is like calling NOT IsNull("LAST")
- CompareBookmarks function fixed. Affects DevExpress Quantum Grid
- TApBlobStream.Create function was moving record pointers incorrectly. 
   This affected memo data. Fixed.
- New SDE 5.2.0.20 DLLs 
----------------------------------------------------------------
v6.0.0.1 (12-15-01)
Official 6.0 Release.

----------------------------------------------------------------
v6.1.0.0 (10-01-02)
6.1 Pre-Release.
- fixes and enhancements throughout
- fixed TApolloDatabase located in datamodules to display correctly
  in the Object Inspector's TApolloDatase dropdown picklist
- added CB6, D7 support
- "Locate" with float values. FIXED
- "Invalid date" or "Invalid value" error message sometimes occured when a DBF 
   was updated by FoxPro. FIXED.
- "Invalid variant operation" when setting lookup fields in runtimes for empty values. FIXED
- Calculated fields support added for TApolloQuery
----------------------------------------------------------------
v6.1.0.0 (12-22-02)
- designtime and runtime packages seperated for all Delphi versions
- TApolloEnv and TApolloDatabase bug under Delphi 7. Fixed.
- SQL related issues with long integer support. Fixed.
- new enumeration support (courtesy of Ron Hoek). New.
- new DADE support for ReportBuilder
----------------------------------------------------------------
v6.1.0.0 (12-24-02)
- designtime and runtime packages seperated for all CBuilder versions
- designtime packages renamed from "dcl" to "d"
- SQL slowness in WHERE clause fixed
----------------------------------------------------------------
v6.1.0.2 (03-01-03)
- minor fixes throughout
- code changes to support SDE61
----------------------------------------------------------------
v6.1.0.4 (07-20-03)
- Fixes problem with duplicated records when using TdxDBGrid that have
  memo fields in the grid.
- Fixes problem with memo fields being called inside OnCalcFields event. 
- Fixes problem when scrolling a table with memo fields using TDBCtrlGrid.
SQL Related:
- Fixes problem with JOINs not resolving consistently when the order
  of joined tables is listed in a different order
- Fixes slowness in accessing DBF/NTX files
- Fixes problem with opening readonly tables (from a readonly device 
  such as a CDROM).
----------------------------------------------------------------
v6.1.0.5 (07-23-03)
- new SDE 6.1.0.15 DLLs 
SQL Related
- Fixed simple non-where clause select support
----------------------------------------------------------------
v6.1.0.7 (10-01-03)
- new SDE 6.1.0.16 DLLs 
- Fields with Ascii chars less than 30 were being trimmed. Fixed.
SQL Related
- When a join contained both an Inner and Outer Join and the fields
  order in the On statement was flipped compared to the table order, 
  it caused an infinite loop. Fixed.
- When a table encrypted with a password was used in a SQL statement using
  Apollo server, the statement returned no results. Fixed.
- Joins with a WHERE clause using Date fields in Left Outer Join where 
  not respecting the condition in where clause. Fixed.
- Joins with an "is null" or "is not null" against date fields where not 
  being correctly resolved. Fixed.
- Joins using alias name for tables but not for fields, were not being 
  correctly resolving the where clause. Fixed.
- The syntax 'Select * From "c:\test\table1.dbf"' (using full path), was 
  not working for sub-selects. Fixed.
- Joins sometimes showed incorrect memo values. Fixed.
----------------------------------------------------------------
v6.1.0.8 (10-06-03)
- SDE filter such as: "DateField > Ctod('01/01/2003')" returned records with blank dates. FIXED
- inline SQL fixed to be not case sensitive. e.g. this now works:
	Select * From Clipper 
	[* TableName:CliPper.dbf, Alias:ClipPEr, TableType:tTsXnTx,  
	ExtraIndexes: CLIp1.ntx;Clip2.ntx *]';
- Apollo Server fixed to support setting and switching between NTX indexes

