// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ApWin.pas' rev: 6.00

#ifndef ApWinHPP
#define ApWinHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Dialogs.hpp>	// Pascal unit
#include <ApCommon.hpp>	// Pascal unit
#include <WinSock.hpp>	// Pascal unit
#include <APGLOBAL.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Apwin
{
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TProgressEvent)(Classes::TComponent* Sender, const int plWork, const int plWorkSize);

typedef void __fastcall (__closure *TReadProgressEvent)(Classes::TComponent* Sender, int Min, int Max, int Position);

typedef void __fastcall (__closure *TWriteProgressEvent)(Classes::TComponent* Sender, int Min, int Max, int Position);

typedef TMetaClass*ExceptionClass;

class DELPHICLASS EApSDEException;
class PASCALIMPLEMENTATION EApSDEException : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDEException(const AnsiString Msg) : Sysutils::Exception(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDEException(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDEException(int Ident)/* overload */ : Sysutils::Exception(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDEException(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDEException(const AnsiString Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDEException(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDEException(int Ident, int AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDEException(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDEException(void) { }
	#pragma option pop
	
};


typedef TMetaClass*TClassApSDEException;

#pragma pack(push, 1)
struct TSunB
{
	char s_b1;
	char s_b2;
	char s_b3;
	char s_b4;
} ;
#pragma pack(pop)

class DELPHICLASS EApSDESocketError;
class PASCALIMPLEMENTATION EApSDESocketError : public EApSDEException 
{
	typedef EApSDEException inherited;
	
private:
	int FiLastError;
	
public:
	__fastcall virtual EApSDESocketError(const AnsiString sMsg, const int iErr, const int iVoid);
	__property int LastError = {read=FiLastError, nodefault};
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDESocketError(const AnsiString Msg) : EApSDEException(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDESocketError(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : EApSDEException(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDESocketError(int Ident)/* overload */ : EApSDEException(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDESocketError(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : EApSDEException(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDESocketError(const AnsiString Msg, int AHelpContext) : EApSDEException(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDESocketError(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : EApSDEException(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDESocketError(int Ident, int AHelpContext)/* overload */ : EApSDEException(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDESocketError(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : EApSDEException(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDESocketError(void) { }
	#pragma option pop
	
};


class DELPHICLASS EApSDEResponseError;
class PASCALIMPLEMENTATION EApSDEResponseError : public EApSDEException 
{
	typedef EApSDEException inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDEResponseError(const AnsiString Msg) : EApSDEException(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDEResponseError(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : EApSDEException(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDEResponseError(int Ident)/* overload */ : EApSDEException(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDEResponseError(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : EApSDEException(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDEResponseError(const AnsiString Msg, int AHelpContext) : EApSDEException(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDEResponseError(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : EApSDEException(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDEResponseError(int Ident, int AHelpContext)/* overload */ : EApSDEException(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDEResponseError(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : EApSDEException(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDEResponseError(void) { }
	#pragma option pop
	
};


class DELPHICLASS EApSDEClosedSocket;
class PASCALIMPLEMENTATION EApSDEClosedSocket : public EApSDEException 
{
	typedef EApSDEException inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDEClosedSocket(const AnsiString Msg) : EApSDEException(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDEClosedSocket(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : EApSDEException(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDEClosedSocket(int Ident)/* overload */ : EApSDEException(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDEClosedSocket(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : EApSDEException(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDEClosedSocket(const AnsiString Msg, int AHelpContext) : EApSDEException(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDEClosedSocket(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : EApSDEException(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDEClosedSocket(int Ident, int AHelpContext)/* overload */ : EApSDEException(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDEClosedSocket(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : EApSDEException(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDEClosedSocket(void) { }
	#pragma option pop
	
};


class DELPHICLASS EApSDEInvalidSocket;
class PASCALIMPLEMENTATION EApSDEInvalidSocket : public EApSDEException 
{
	typedef EApSDEException inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDEInvalidSocket(const AnsiString Msg) : EApSDEException(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDEInvalidSocket(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : EApSDEException(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDEInvalidSocket(int Ident)/* overload */ : EApSDEException(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDEInvalidSocket(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : EApSDEException(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDEInvalidSocket(const AnsiString Msg, int AHelpContext) : EApSDEException(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDEInvalidSocket(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : EApSDEException(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDEInvalidSocket(int Ident, int AHelpContext)/* overload */ : EApSDEException(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDEInvalidSocket(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : EApSDEException(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDEInvalidSocket(void) { }
	#pragma option pop
	
};


class DELPHICLASS EApSDEConnClosedGraceful;
class PASCALIMPLEMENTATION EApSDEConnClosedGraceful : public EApSDEException 
{
	typedef EApSDEException inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDEConnClosedGraceful(const AnsiString Msg) : EApSDEException(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDEConnClosedGraceful(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : EApSDEException(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDEConnClosedGraceful(int Ident)/* overload */ : EApSDEException(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDEConnClosedGraceful(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : EApSDEException(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDEConnClosedGraceful(const AnsiString Msg, int AHelpContext) : EApSDEException(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDEConnClosedGraceful(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : EApSDEException(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDEConnClosedGraceful(int Ident, int AHelpContext)/* overload */ : EApSDEException(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDEConnClosedGraceful(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : EApSDEException(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDEConnClosedGraceful(void) { }
	#pragma option pop
	
};


class DELPHICLASS EApSDEConnectRefused;
class PASCALIMPLEMENTATION EApSDEConnectRefused : public EApSDEException 
{
	typedef EApSDEException inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDEConnectRefused(const AnsiString Msg) : EApSDEException(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDEConnectRefused(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : EApSDEException(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDEConnectRefused(int Ident)/* overload */ : EApSDEException(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDEConnectRefused(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : EApSDEException(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDEConnectRefused(const AnsiString Msg, int AHelpContext) : EApSDEException(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDEConnectRefused(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : EApSDEException(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDEConnectRefused(int Ident, int AHelpContext)/* overload */ : EApSDEException(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDEConnectRefused(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : EApSDEException(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDEConnectRefused(void) { }
	#pragma option pop
	
};


class DELPHICLASS EApSDEGetMessage;
class PASCALIMPLEMENTATION EApSDEGetMessage : public EApSDEException 
{
	typedef EApSDEException inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDEGetMessage(const AnsiString Msg) : EApSDEException(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDEGetMessage(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : EApSDEException(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDEGetMessage(int Ident)/* overload */ : EApSDEException(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDEGetMessage(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : EApSDEException(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDEGetMessage(const AnsiString Msg, int AHelpContext) : EApSDEException(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDEGetMessage(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : EApSDEException(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDEGetMessage(int Ident, int AHelpContext)/* overload */ : EApSDEException(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDEGetMessage(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : EApSDEException(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDEGetMessage(void) { }
	#pragma option pop
	
};


class DELPHICLASS EApSDEInterrupted;
class PASCALIMPLEMENTATION EApSDEInterrupted : public EApSDEException 
{
	typedef EApSDEException inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDEInterrupted(const AnsiString Msg) : EApSDEException(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDEInterrupted(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : EApSDEException(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDEInterrupted(int Ident)/* overload */ : EApSDEException(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDEInterrupted(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : EApSDEException(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDEInterrupted(const AnsiString Msg, int AHelpContext) : EApSDEException(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDEInterrupted(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : EApSDEException(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDEInterrupted(int Ident, int AHelpContext)/* overload */ : EApSDEException(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDEInterrupted(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : EApSDEException(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDEInterrupted(void) { }
	#pragma option pop
	
};


class DELPHICLASS EApSDETimedOut;
class PASCALIMPLEMENTATION EApSDETimedOut : public EApSDEInterrupted 
{
	typedef EApSDEInterrupted inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDETimedOut(const AnsiString Msg) : EApSDEInterrupted(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDETimedOut(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : EApSDEInterrupted(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDETimedOut(int Ident)/* overload */ : EApSDEInterrupted(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDETimedOut(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : EApSDEInterrupted(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDETimedOut(const AnsiString Msg, int AHelpContext) : EApSDEInterrupted(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDETimedOut(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : EApSDEInterrupted(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDETimedOut(int Ident, int AHelpContext)/* overload */ : EApSDEInterrupted(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDETimedOut(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : EApSDEInterrupted(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDETimedOut(void) { }
	#pragma option pop
	
};


class DELPHICLASS EApSDENotWaiting;
class PASCALIMPLEMENTATION EApSDENotWaiting : public EApSDEException 
{
	typedef EApSDEException inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDENotWaiting(const AnsiString Msg) : EApSDEException(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDENotWaiting(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : EApSDEException(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDENotWaiting(int Ident)/* overload */ : EApSDEException(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDENotWaiting(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : EApSDEException(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDENotWaiting(const AnsiString Msg, int AHelpContext) : EApSDEException(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDENotWaiting(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : EApSDEException(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDENotWaiting(int Ident, int AHelpContext)/* overload */ : EApSDEException(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDENotWaiting(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : EApSDEException(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDENotWaiting(void) { }
	#pragma option pop
	
};


class DELPHICLASS EApSDENotListening;
class PASCALIMPLEMENTATION EApSDENotListening : public EApSDEException 
{
	typedef EApSDEException inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDENotListening(const AnsiString Msg) : EApSDEException(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDENotListening(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : EApSDEException(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDENotListening(int Ident)/* overload */ : EApSDEException(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDENotListening(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : EApSDEException(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDENotListening(const AnsiString Msg, int AHelpContext) : EApSDEException(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDENotListening(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : EApSDEException(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDENotListening(int Ident, int AHelpContext)/* overload */ : EApSDEException(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDENotListening(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : EApSDEException(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDENotListening(void) { }
	#pragma option pop
	
};


class DELPHICLASS EApSDEAlreadyListening;
class PASCALIMPLEMENTATION EApSDEAlreadyListening : public EApSDEException 
{
	typedef EApSDEException inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDEAlreadyListening(const AnsiString Msg) : EApSDEException(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDEAlreadyListening(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : EApSDEException(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDEAlreadyListening(int Ident)/* overload */ : EApSDEException(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDEAlreadyListening(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : EApSDEException(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDEAlreadyListening(const AnsiString Msg, int AHelpContext) : EApSDEException(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDEAlreadyListening(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : EApSDEException(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDEAlreadyListening(int Ident, int AHelpContext)/* overload */ : EApSDEException(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDEAlreadyListening(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : EApSDEException(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDEAlreadyListening(void) { }
	#pragma option pop
	
};


class DELPHICLASS EApSDEAlreadyConnected;
class PASCALIMPLEMENTATION EApSDEAlreadyConnected : public EApSDEException 
{
	typedef EApSDEException inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDEAlreadyConnected(const AnsiString Msg) : EApSDEException(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDEAlreadyConnected(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : EApSDEException(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDEAlreadyConnected(int Ident)/* overload */ : EApSDEException(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDEAlreadyConnected(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : EApSDEException(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDEAlreadyConnected(const AnsiString Msg, int AHelpContext) : EApSDEException(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDEAlreadyConnected(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : EApSDEException(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDEAlreadyConnected(int Ident, int AHelpContext)/* overload */ : EApSDEException(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDEAlreadyConnected(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : EApSDEException(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDEAlreadyConnected(void) { }
	#pragma option pop
	
};


class DELPHICLASS EApSDEAlreadyConnecting;
class PASCALIMPLEMENTATION EApSDEAlreadyConnecting : public EApSDEException 
{
	typedef EApSDEException inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApSDEAlreadyConnecting(const AnsiString Msg) : EApSDEException(Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApSDEAlreadyConnecting(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size) : EApSDEException(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApSDEAlreadyConnecting(int Ident)/* overload */ : EApSDEException(Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApSDEAlreadyConnecting(int Ident, const System::TVarRec * Args, const int Args_Size)/* overload */ : EApSDEException(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApSDEAlreadyConnecting(const AnsiString Msg, int AHelpContext) : EApSDEException(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApSDEAlreadyConnecting(const AnsiString Msg, const System::TVarRec * Args, const int Args_Size, int AHelpContext) : EApSDEException(Msg, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApSDEAlreadyConnecting(int Ident, int AHelpContext)/* overload */ : EApSDEException(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApSDEAlreadyConnecting(System::PResStringRec ResStringRec, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : EApSDEException(ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApSDEAlreadyConnecting(void) { }
	#pragma option pop
	
};


class DELPHICLASS TDummy;
class PASCALIMPLEMENTATION TDummy : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TDummy(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TDummy(void) { }
	#pragma option pop
	
};


class DELPHICLASS TApSDE;
class PASCALIMPLEMENTATION TApSDE : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	int fiPort;
	AnsiString fsBoundIP;
	Classes::TStrings* fslstLocalAddresses;
	AnsiString __fastcall GetLocalAddress();
	Classes::TStrings* __fastcall GetLocalAddresses(void);
	AnsiString __fastcall GetLocalName();
	void __fastcall PopulateLocalAddresses(void);
	
protected:
	int fHandle;
	AnsiString FHexHandle;
	DYNAMIC void __fastcall AllocateSocket(const int piSocketType);
	void __fastcall Bind(void);
	void __fastcall Listen(void);
	void __fastcall ListenNonDefault(const int piQueueCount);
	
public:
	virtual void __fastcall CloseSocket(void);
	virtual bool __fastcall Connected(void);
	__fastcall virtual TApSDE(Classes::TComponent* AOwner);
	__fastcall virtual ~TApSDE(void);
	virtual void __fastcall Disconnect(void);
	/*         class method */ static void __fastcall Raise_SocketError(TMetaClass* vmt, const int iErr);
	/*         class method */ static int __fastcall ResolveHost(TMetaClass* vmt, const AnsiString psHost, AnsiString &psIP);
	/*         class method */ static AnsiString __fastcall ResolveIP(TMetaClass* vmt, const AnsiString psIP);
	/*         class method */ static bool __fastcall CheckForSocketError(TMetaClass* vmt, const int iResult);
	/*         class method */ static bool __fastcall CheckForSocketError2(TMetaClass* vmt, const int iResult, const int * aiIgnore, const int aiIgnore_Size);
	/*         class method */ static AnsiString __fastcall SockErrMsg(TMetaClass* vmt, const int iErr);
	/*         class method */ static AnsiString __fastcall TInAddrToString(TMetaClass* vmt, in_addr prIP);
	__property int Handle = {read=fHandle, nodefault};
	__property AnsiString HexHandle = {read=FHexHandle, write=FHexHandle};
	__property AnsiString LocalAddress = {read=GetLocalAddress};
	__property Classes::TStrings* LocalAddresses = {read=GetLocalAddresses};
	__property AnsiString LocalName = {read=GetLocalName};
	__property AnsiString BoundIP = {read=fsBoundIP, write=fsBoundIP};
	
__published:
	__property int Port = {read=fiPort, write=fiPort, nodefault};
};


class DELPHICLASS TApSDESocket;
class PASCALIMPLEMENTATION TApSDESocket : public TApSDE 
{
	typedef TApSDE inherited;
	
private:
	AnsiString FUser;
	AnsiString FPassword;
	bool fbClosedGracefully;
	bool fbUseNagle;
	AnsiString fnLogFile;
	AnsiString fsEOLTerminator;
	bool FbASCIIFilter;
	short FnResultNo;
	int FlLastWork;
	int FiBufferChunk;
	int fiReadBufferPos;
	int lWork;
	int lWorkSize;
	Classes::TFileStream* strmLog;
	Apglobal::TStringEvent fOnStatus;
	Apglobal::TStringEvent fOnCaptureLine;
	TProgressEvent fOnWork;
	TReadProgressEvent FOnReadProgress;
	TWriteProgressEvent FOnWriteProgress;
	Apcommon::TxProgressEvent FOnServerProgress;
	
protected:
	AnsiString fsPeerAddress;
	AnsiString fsCommandResult;
	AnsiString fsReadBuffer;
	Classes::TStrings* FslstCommandResultLong;
	void __fastcall SRaise(TMetaClass* exception);
	__property Apglobal::TStringEvent OnCaptureLine = {read=fOnCaptureLine, write=fOnCaptureLine};
	void __fastcall BeginWork(const int lSize);
	int __fastcall Capture(System::TObject* objc, const AnsiString * asDelim, const int asDelim_Size);
	void __fastcall CaptureHeader(Classes::TStrings* pslstHeaders, const AnsiString psDelim);
	void __fastcall CheckForDisconnect(void);
	virtual short __fastcall Command(const AnsiString sOut, const short nResponse, const Byte nLevel, const AnsiString sMsg);
	void __fastcall ConvertHeadersToValues(Classes::TStrings* pslstHeaders);
	virtual void __fastcall DoWork(int lNewWork);
	AnsiString __fastcall ExtractXBytesFromBuffer(const int piPos);
	DYNAMIC void __fastcall DoStatus(const AnsiString sMsg);
	void __fastcall EndWork(void);
	short __fastcall GetResponse(void);
	bool __fastcall Readable(const int piMSec);
	void __fastcall ReadToBuffer(void *pBuffer, const int piByteCount);
	AnsiString __fastcall ReadBuffer();
	int __fastcall ReadBufferSize(void);
	Byte __fastcall ReadByte(void);
	void __fastcall ReadFromWinsock(void);
	Shortint __fastcall ReadShortInt(void);
	AnsiString __fastcall ReadLnAndEcho(const AnsiString psMask);
	AnsiString __fastcall ReadLnWait();
	void __fastcall SetBufferChunk(const int iValue);
	int __fastcall WriteFromBuffer(const void *pBuffer, const int piByteCount);
	void __fastcall WriteHeaders(Classes::TStrings* pslstHeaders);
	void __fastcall WriteTStrings(Classes::TStrings* pslst);
	__property AnsiString CommandResult = {read=fsCommandResult};
	__property Classes::TStrings* CommandResultLong = {read=FslstCommandResultLong};
	__property AnsiString EOLTerminator = {read=fsEOLTerminator, write=fsEOLTerminator};
	__property short ResultNo = {read=FnResultNo, nodefault};
	__property bool ASCIIFilter = {read=FbASCIIFilter, write=FbASCIIFilter, default=0};
	__property int BufferChunk = {read=FiBufferChunk, write=SetBufferChunk, nodefault};
	__property AnsiString LogFile = {read=fnLogFile, write=fnLogFile};
	__property bool UseNagle = {read=fbUseNagle, write=fbUseNagle, default=1};
	__property bool ClosedGracefully = {read=fbClosedGracefully, write=fbClosedGracefully, nodefault};
	
public:
	__fastcall virtual TApSDESocket(Classes::TComponent* AOwner);
	__fastcall virtual ~TApSDESocket(void);
	__property AnsiString User = {read=FUser, write=FUser};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property AnsiString PeerAddress = {read=fsPeerAddress};
	void __fastcall WriteLn(const AnsiString sOut);
	AnsiString __fastcall ReadLn();
	virtual AnsiString __fastcall Read(const int piLen);
	virtual AnsiString __fastcall ReadWaitSec(const int piLen, int piMS);
	int __fastcall Write(AnsiString psOut);
	void __fastcall ReadToStream(Classes::TStream* strm, const int iCount);
	int __fastcall WriteToStream(Classes::TStream* strm, const bool bAll);
	int __fastcall WriteToStream2(AnsiString sHeader, Classes::TStream* strm);
	
__published:
	__property Apglobal::TStringEvent OnStatus = {read=fOnStatus, write=fOnStatus};
	__property TReadProgressEvent OnReadProgress = {read=FOnReadProgress, write=FOnReadProgress};
	__property TWriteProgressEvent OnWriteProgress = {read=FOnWriteProgress, write=FOnWriteProgress};
	__property Apcommon::TxProgressEvent OnServerProgress = {read=FOnServerProgress, write=FOnServerProgress};
};


class DELPHICLASS TApSDEClient;
class PASCALIMPLEMENTATION TApSDEClient : public TApSDESocket 
{
	typedef TApSDESocket inherited;
	
private:
	AnsiString fsUser;
	AnsiString fsHost;
	AnsiString fsPassword;
	AnsiString fsUserID;
	
protected:
	__property AnsiString UserID = {read=fsUserID, write=fsUserID};
	void __fastcall SetUser(AnsiString Value);
	
public:
	virtual void __fastcall Connect(void);
	__fastcall virtual ~TApSDEClient(void);
	virtual void __fastcall Disconnect(void);
	
__published:
	__property AnsiString Host = {read=fsHost, write=fsHost};
	__property AnsiString User = {read=fsUser, write=SetUser};
	__property AnsiString Password = {read=fsPassword, write=fsPassword};
public:
	#pragma option push -w-inl
	/* TApSDESocket.Create */ inline __fastcall virtual TApSDEClient(Classes::TComponent* AOwner) : TApSDESocket(AOwner) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE AnsiString sStackDescription;
extern PACKAGE int iMaxSockets;
extern PACKAGE int iMaxUDPSize;
static const Word TCPIP_BUFFERCHUNK = 0x2000;
static const Shortint WSPORT_ECHO = 0x7;
static const Shortint WSPORT_DISCARD = 0x9;
static const Shortint WSPORT_SYSTAT = 0xb;
static const Shortint WSPORT_DAYTIME = 0xd;
static const Shortint WSPORT_NETSTAT = 0xf;
static const Shortint WSPORT_QOTD = 0x11;
static const Shortint WSPORT_CHARGEN = 0x13;
static const Shortint WSPORT_FTP = 0x15;
static const Shortint WSPORT_TELNET = 0x17;
static const Shortint WSPORT_SMTP = 0x19;
static const Shortint WSPORT_TIME = 0x25;
static const Shortint WSPORT_WHOIS = 0x2b;
static const Shortint WSPORT_DOMAIN = 0x35;
static const Shortint WSPORT_TFTP = 0x45;
static const Shortint WSPORT_FINGER = 0x4f;
static const Shortint WSPORT_HTTP = 0x50;
static const Shortint WSPORT_POP2 = 0x6d;
static const Shortint WSPORT_POP3 = 0x6e;
static const Shortint WSPORT_AUTH = 0x71;
static const Shortint WSPORT_NNTP = 0x77;
static const Word WSPORT_SSL = 0x1bb;
static const Shortint wsOk = 0x1;
static const Shortint wsErr = 0x0;
#define MultiPartBoundary "=_NextPart_2rfksadvnqw3nerasdf"
extern PACKAGE System::TDateTime __fastcall GmtOffsetStrToDateTime(AnsiString s);
extern PACKAGE AnsiString __fastcall DateTimeToGmtOffSetStr(System::TDateTime dttm, bool bSubGMT);

}	/* namespace Apwin */
using namespace Apwin;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ApWin
