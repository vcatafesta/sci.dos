// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'APGLOBAL.pas' rev: 6.00

#ifndef APGLOBALHPP
#define APGLOBALHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Messages.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Apglobal
{
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TStringEvent)(Classes::TComponent* Sender, const AnsiString sOut);

#pragma option push -b-
enum APGLOBAL__1 { rfReplaceAll, rfIgnoreCase };
#pragma option pop

typedef Set<APGLOBAL__1, rfReplaceAll, rfIgnoreCase>  TReplaceFlags;

//-- var, const, procedure ---------------------------------------------------
static const char CR = '\xd';
static const char LF = '\xa';
#define EOL "\r\n"
static const char TAB = '\x9';
static const char CHAR0 = '\x0';
static const char CHAR32 = '\x20';
extern PACKAGE bool bVoid;
extern PACKAGE AnsiString sVoid;
extern PACKAGE void __fastcall StreamWrite(Classes::TStream* strm, const AnsiString sOut);
extern PACKAGE void __fastcall StreamWriteLn(Classes::TStream* strm, const AnsiString sOut);
extern PACKAGE int __fastcall iiif(const bool pbCondition, const int piTrue, const int piFalse);
extern PACKAGE AnsiString __fastcall siif(const bool pbCondition, const AnsiString psTrue, const AnsiString psFalse);
extern PACKAGE bool __fastcall StreamEOF(Classes::TStream* strm);
extern PACKAGE AnsiString __fastcall StreamReadLn(Classes::TStream* strm);
extern PACKAGE AnsiString __fastcall StreamReadShortLn(Classes::TStream* strm);
extern PACKAGE AnsiString __fastcall StreamReadLongLn(Classes::TStream* strm, bool &bEOL, int iSize);
extern PACKAGE AnsiString __fastcall StreamReadXChars(Classes::TStream* strm, const int iChars);
extern PACKAGE int __fastcall RPos(const AnsiString sSub, const AnsiString sIn, int piStart);
extern PACKAGE int __fastcall PosInStrArray(const AnsiString SearchStr, const AnsiString * Contents, const int Contents_Size);
extern PACKAGE AnsiString __fastcall UpcaseFirst(AnsiString s);
extern PACKAGE Byte __fastcall StrToMonth(const AnsiString sMonth);
extern PACKAGE Byte __fastcall StrToDay(const AnsiString sDay);
extern PACKAGE bool __fastcall IsNumeric(char c);
extern PACKAGE AnsiString __fastcall StringReplace(const AnsiString S, const AnsiString OldPattern, const AnsiString NewPattern, TReplaceFlags Flags);
extern PACKAGE AnsiString __fastcall NoAngleBrackets(const AnsiString s);
extern PACKAGE AnsiString __fastcall TabPAD(AnsiString S);
extern PACKAGE AnsiString __fastcall Pad10(int I);
extern PACKAGE System::TDateTime __fastcall OffsetFromUTC(void);

}	/* namespace Apglobal */
using namespace Apglobal;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// APGLOBAL
