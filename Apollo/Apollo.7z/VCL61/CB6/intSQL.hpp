// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'IntSQL.pas' rev: 6.00

#ifndef IntSQLHPP
#define IntSQLHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ApCommon.hpp>	// Pascal unit
#include <DB.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Intsql
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
#define DLL_NAME "ApolloSQL61.DLL"
extern PACKAGE bool SQLDLLLoaded;
extern PACKAGE char * __stdcall (*dll_sql_Prepare)(Classes::TComponent* Owner, int &SQLID, Apcommon::TxProgressEvent xqPregress, int DefaultTableType, char * DefaultPassword, bool DefaultTranslate, int iTableCount, char * sTables, char * sPath, Word FDeleted, Word FCentury, int FMemoBlockSize, char * FDateFormat, Classes::TMemoryStream* FParamsStrm, bool FReadOnly, Apcommon::TApolloCommitLevel FCommitLevel, int &iError);
extern PACKAGE char * __stdcall (*dll_sql_OpenSQL)(int SQLID, char * FSQL, int &iRecCount, int &iFieldCount, int &iRecSize, int &iError);
extern PACKAGE char * __stdcall (*dll_sql_GetStructure)(int SQLID, char * &pMem, int &iSize);
extern PACKAGE char * __stdcall (*dll_sql_GetRecord)(int SQLID, char * &pMem, int iRecNo, int iFetchCount, int &iRecRead, int &iSize);
extern PACKAGE char * __stdcall (*dll_sql_ExecSQL)(int SQLID, char * FSQL, Classes::TMemoryStream* FParamsStrm, int &iError);
extern PACKAGE char * __stdcall (*dll_sql_CloseSQL)(int SQLID, int &iError);
extern PACKAGE char * __stdcall (*dll_sql_UnPrepareSQL)(int SQLID, int &iError);
extern PACKAGE char * __stdcall (*dll_sql_ReadBlobData)(int SQLID, char * &pMem, int iRecNo, int iFieldIndex, int &iError);
extern PACKAGE char * __stdcall (*dll_sql_RecCount)(int SQLID, int &iRecCount, int &iError);
extern PACKAGE char * __stdcall (*dll_sql_Refresh)(int SQLID, int &iError);
extern PACKAGE void __stdcall (*dll_sql_SetSystemCollation)(void);
extern PACKAGE void __stdcall (*dll_sql_SetMachineCollation)(void);
extern PACKAGE void __stdcall (*dll_sql_AddDudenCollation)(void);
extern PACKAGE void __stdcall (*dll_sql_AddEtecCollation)(void);
extern PACKAGE void __fastcall LoadSQLDLL(void);

}	/* namespace Intsql */
using namespace Intsql;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// IntSQL
