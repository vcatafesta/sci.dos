// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'compStream.pas' rev: 6.00

#ifndef compStreamHPP
#define compStreamHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <DB.hpp>	// Pascal unit
#include <ActiveX.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Compstream
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall ParamsToStream(Db::TParams* Params, Classes::TMemoryStream* &M);
extern PACKAGE void __fastcall StreamToParams(Classes::TMemoryStream* M, Db::TParams* &Params);
extern PACKAGE void __fastcall PointerToVarArray(void * ptr, int iSize, OleVariant &Value);
extern PACKAGE void __fastcall VarArrayToPointer(const OleVariant &Value, void * &Ptr);
extern PACKAGE AnsiString __fastcall ComponentToVar(Classes::TComponent* Component);
extern PACKAGE Classes::TComponent* __fastcall VarToComponent(AnsiString Value);
extern PACKAGE Variant __fastcall ComponentToVariant(Classes::TComponent* Component);
extern PACKAGE Classes::TComponent* __fastcall VariantToComponent(const Variant &Value);
extern PACKAGE void __fastcall VariantToStream(const Variant * V, const int V_Size, Classes::TMemoryStream* &M);
extern PACKAGE void __fastcall StreamToVariant(Classes::TMemoryStream* M, Variant &V);

}	/* namespace Compstream */
using namespace Compstream;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// compStream
