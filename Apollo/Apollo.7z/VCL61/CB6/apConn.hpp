// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ApConn.pas' rev: 6.00

#ifndef ApConnHPP
#define ApConnHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Variants.hpp>	// Pascal unit
#include <IntCrypt.hpp>	// Pascal unit
#include <FileCtrl.hpp>	// Pascal unit
#include <IntSQL.hpp>	// Pascal unit
#include <ApCommon.hpp>	// Pascal unit
#include <DB.hpp>	// Pascal unit
#include <ExtCtrls.hpp>	// Pascal unit
#include <ApWin.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Graphics.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Messages.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Apconn
{
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TSocketConnectionLoginEvent)(System::TObject* Sender, bool LoginAccepted, AnsiString Msg);

typedef void __fastcall (__closure *TSocketConnectionLogoutEvent)(System::TObject* Sender);

typedef void __fastcall (__closure *TSocketConnectionErrorEvent)(System::TObject* Sender, AnsiString Command, AnsiString Msg);

typedef void __fastcall (__closure *TSocketConnectionServerMsgEvent)(System::TObject* Sender, AnsiString Msg);

typedef void __fastcall (__closure *TSocketConnectionServerStreamEvent)(System::TObject* Sender, Classes::TMemoryStream* Stream);

class DELPHICLASS TApolloConnection;
class PASCALIMPLEMENTATION TApolloConnection : public Apwin::TApSDEClient 
{
	typedef Apwin::TApSDEClient inherited;
	
private:
	bool FCompression;
	AnsiString FCompressionPassword;
	int FCompressionLevel;
	Extctrls::TTimer* FTimer;
	int FTriggersInterval;
	bool FTriggers;
	AnsiString FSQLDataPath;
	Classes::TList* FTransList;
	Classes::TMemoryStream* FTransStream;
	Word nCurWorkArea;
	char *FActiveBuffer;
	bool FLogged;
	AnsiString FVersion;
	AnsiString FDummyVersion;
	AnsiString FSerial;
	int FTimeOut;
	AnsiString FLicenseKey;
	AnsiString FDataBaseName;
	TSocketConnectionLoginEvent FOnLogin;
	TSocketConnectionErrorEvent FOnError;
	TSocketConnectionLogoutEvent FOnLogout;
	TSocketConnectionServerMsgEvent FOnServerMessage;
	TSocketConnectionServerStreamEvent FOnServerStream;
	AnsiString FServerName;
	AnsiString FGroupName;
	int FConnType;
	Classes::TMemoryStream* FReadStream;
	Classes::TMemoryStream* FWriteStream;
	char InBuff[65538];
	char * __fastcall FillInBuff(void);
	virtual void __fastcall SetActive(bool Value);
	void __fastcall ServiceIncoming(System::TObject* Sender);
	bool __fastcall GetTriggers(void);
	void __fastcall SetTriggers(bool Value);
	void __fastcall SetTriggersInterval(int Value);
	void __fastcall SetCompressionPassword(AnsiString Value);
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	AnsiString __fastcall PathFromAlias();
	
public:
	__property int ConnType = {read=FConnType, write=FConnType, nodefault};
	__property bool Compression = {read=FCompression, write=FCompression, nodefault};
	__property AnsiString CompressionPassword = {read=FCompressionPassword, write=SetCompressionPassword};
	__property AnsiString SQLDataPath = {read=FSQLDataPath, write=FSQLDataPath};
	__property bool Triggers = {read=GetTriggers, write=SetTriggers, nodefault};
	__property int TriggersInterval = {read=FTriggersInterval, write=SetTriggersInterval, nodefault};
	__fastcall virtual TApolloConnection(Classes::TComponent* AOwner);
	__fastcall virtual ~TApolloConnection(void);
	void * __fastcall ap_SetDLLProcName(AnsiString sDatabaseName, AnsiString sProcName);
	void __fastcall CloseDataSets(void);
	void __fastcall OpenDataSets(void);
	int __fastcall StartTransaction(void);
	int __fastcall Commit(void);
	int __fastcall RollBack(void);
	__property Classes::TMemoryStream* ReadStream = {read=FReadStream, write=FReadStream};
	__property Classes::TMemoryStream* WriteStream = {read=FWriteStream, write=FWriteStream};
	__property Classes::TMemoryStream* TransStream = {read=FTransStream, write=FTransStream};
	__property char * ActiveBuffer = {read=FActiveBuffer};
	bool __fastcall Login(void);
	void __fastcall Logout(void);
	bool __fastcall IsServerConnectedToRelay(void);
	void * __fastcall GetServerListFromRelay(void);
	void __fastcall ClientError(const AnsiString Command, const AnsiString ErrMsg);
	bool __fastcall Ping(void);
	char * __fastcall ClientXmit(const AnsiString scAction, AnsiString sPacket, bool bWaitForResponse);
	void * __fastcall ClientStreamReceive(const AnsiString scAction, AnsiString sPacket);
	int __fastcall FillReadStream(bool bTriggers);
	Classes::TMemoryStream* __fastcall ClientStreamSendReceive(const AnsiString scAction);
	AnsiString __fastcall GetConnectionID();
	AnsiString __fastcall GetServerName();
	bool __fastcall DeleteFile(AnsiString sDataBaseName, AnsiString sFileName);
	bool __fastcall DeleteFileExt(AnsiString sDataBaseName, AnsiString sFileName);
	bool __fastcall FileExists(AnsiString sDataBaseName, AnsiString sFileName);
	int __fastcall FileLength(AnsiString sDataBaseName, AnsiString sFileName);
	bool __fastcall FileIsInUse(AnsiString sDataBaseName, AnsiString sFileName);
	int __fastcall FileSend(AnsiString sDataBaseName, AnsiString srcFile, AnsiString desFile);
	int __fastcall FileReceive(AnsiString sDataBaseName, AnsiString srcFile, AnsiString desFile);
	System::TDateTime __fastcall GetServerDateTime(void);
	void * __fastcall GetTableNames(void);
	Classes::TStringList* __fastcall GetTableNamesList(AnsiString sDatabaseName);
	void * __fastcall GetDataBaseNames(void);
	Classes::TStringList* __fastcall GetDatabaseNamesList(void);
	void * __fastcall GetIndexNames(AnsiString sTableName, short iTableType);
	void * __fastcall GetDLLProcedureNames(AnsiString sDatabaseName);
	void * __fastcall CreateScript(AnsiString ScriptName, Classes::TStringList* ScriptText, int iLang, bool bSave);
	void * __fastcall StopScript(AnsiString ScriptName);
	void * __fastcall GetScriptsList(void);
	void * __fastcall DropScript(AnsiString ScriptName);
	void * __fastcall RunScript(AnsiString ScriptName, const Variant * InParams, const int InParams_Size);
	void * __fastcall CheckScriptSyntax(AnsiString ScriptName, int &CharNo, void *LineNo);
	bool __fastcall UpdateScriptText(AnsiString ScriptName, Classes::TStrings* ScriptText, bool bSave);
	void * __fastcall GetScriptText(AnsiString ScriptName);
	void * __fastcall GetDLLProcs(AnsiString sDLLName);
	void * __fastcall GetFiles(AnsiString sSrchStr);
	void __fastcall GetUserNames(Classes::TStringList* uList);
	Classes::TStringList* __fastcall GetUserNamesList(void);
	void * __fastcall FindDrives(void);
	void * __fastcall FindDirectories(const AnsiString ParentDirectory);
	void * __fastcall FindFiles(AnsiString Directory, AnsiString Mask);
	void * __fastcall GetServerLog(void);
	void * __fastcall ap_ExecDLLProc(void);
	__property AnsiString DataBaseName = {read=FDataBaseName, write=FDataBaseName};
	char * __fastcall ap_Alias(Word iWA);
	int __fastcall ap_Append(void);
	int __fastcall ap_AppendBlank(void);
	Word __fastcall ap_AppendFrom(char * cpFileName, short iSourceType, char * cpScopeExpr);
	char * __fastcall ap_BaseDate(void);
	char * __fastcall ap_BaseName(void);
	Word __fastcall ap_BlobToFile(char * cpFieldName, char * cpFileName, int iRecNo);
	Word __fastcall ap_Bof(void);
	void __fastcall ap_Close(void);
	void __fastcall ap_CloseAll(void);
	void __fastcall ap_CloseIndexes(void);
	void __fastcall ap_Commit(void);
	int __fastcall ap_CommitLevel(int iVal);
	Word __fastcall ap_CopyFile(char * sToFileName);
	Word __fastcall ap_CopyFileText(char * sTextFileName, short iFileType);
	Word __fastcall ap_CopyStructure(char * sFileName, char * sAlias);
	Word __fastcall ap_CopyStructureExtended(char * cpFileName);
	int __fastcall ap_Count(void);
	Word __fastcall ap_CreateExec(void);
	void __fastcall ap_CreateField(char * cpName, char * cpType, short iLength, short iDecimals);
	Word __fastcall ap_CreateFrom(char * cpFileName, char * cpAlias, char * cpStruFile, short iRDEType);
	short __fastcall ap_CreateNew(char * cpDataBaseName, char * cpFileName, short iRdeType, short iNumFields);
	Word __fastcall ap_DbfDecrypt(void);
	Word __fastcall ap_DbfEncrypt(void);
	char * __fastcall ap_DBFilter(void);
	char * __fastcall ap_Decrypt(char * cpBuffer, char * cpPassword, int iLen);
	void __fastcall ap_Delete(void);
	Word __fastcall ap_Deleted(void);
	char * __fastcall ap_Descend(char * cpKeyString);
	Word __fastcall ap_Empty(char * sFieldName);
	Word __fastcall ap_Eof(void);
	char * __fastcall ap_Encrypt(char * cpBuffer, char * cpPassword, int iLen);
	int __fastcall ap_ErrorLevel(int iErrorLevel);
	Word __fastcall ap_EvalLogical(char * sExpression);
	double __fastcall ap_EvalNumeric(char * sExpression);
	char * __fastcall ap_EvalString(char * sExpression);
	short __fastcall ap_EvalTest(char * sExpression);
	Word __fastcall ap_FieldCount(void);
	Word __fastcall ap_FieldDecimals(char * cpFieldName);
	char * __fastcall ap_FieldName(Word uiFieldNum);
	Word __fastcall ap_FieldNum(char * cpFieldName);
	Word __fastcall ap_FieldOffset(char * cpFieldName);
	char * __fastcall ap_FieldType(char * cpFieldName);
	Word __fastcall ap_FieldWidth(char * cpFieldName);
	Word __fastcall ap_FilterAlias(char * cpAliasName, char * cpFieldName);
	char * __fastcall ap_FilterDlg(HWND hwnd, char * cpExpr, char * cpCaption, Word bHasIndexList);
	Word __fastcall ap_Flock(void);
	Word __fastcall ap_Found(void);
	Word __fastcall ap_GetBitMap(char * cpFieldName, HWND hwnd);
	int __fastcall ap_GetBlob(char * cpFieldName, void * vpVar);
	int __fastcall ap_GetBlobLength(char * cpFieldName);
	char * __fastcall ap_GetByte(char * cpFieldName);
	int __fastcall ap_GetDateJulian(char * cpFieldName);
	char * __fastcall ap_GetDateString(char * cpFieldName);
	double __fastcall ap_GetDouble(char * cpFieldName);
	char * __fastcall ap_GetFields(void);
	short __fastcall ap_GetInteger(char * cpFieldName);
	Word __fastcall ap_GetLogical(char * cpFieldName);
	int __fastcall ap_GetLong(char * cpFieldName);
	char * __fastcall ap_GetMemo(char * cpFieldName, Word uiLineWidth);
	char * __fastcall ap_GetPage(int Count);
	Word __fastcall ap_GetQueryBit(int lRecNum);
	void __fastcall ap_GetRecord(char * cpRecord, int iRecSize);
	char * __fastcall ap_GetScope(short iWhichScope);
	char * __fastcall ap_GetString(char * cpFieldName);
	void * __fastcall ap_GetStructure(void);
	char * __fastcall ap_GetTrimString(char * cpFieldName);
	int __fastcall ap_Go(int lRecNum);
	void __fastcall ap_GoBottom(void);
	void __fastcall ap_GoTop(void);
	short __fastcall ap_Index(char * cpFileName, char * cpExpr, short iOption, Word bDescend, char * cpCondition);
	void __fastcall ap_IndexClose(void);
	int __fastcall ap_IndexCount(void);
	char * __fastcall ap_IndexCondition(void);
	int __fastcall ap_IndexDescending(void);
	Word __fastcall ap_IndexFlip(void);
	char * __fastcall ap_IndexKey(void);
	char * __fastcall ap_IndexKeyField(void);
	char * __fastcall ap_IndexName(short iIndex);
	short __fastcall ap_IndexOpen(char * cpFileName);
	short __fastcall ap_IndexOrd(void);
	short __fastcall ap_IndexTag(char * cpFileName, char * cpTagName, char * cpExpr, short iOption, Word bDescend, char * cpCondition);
	short __fastcall ap_IndexType(void);
	Word __fastcall ap_IsEncrypted(short iFileOrRec);
	Word __fastcall ap_KeyAdd(char * cpTagname);
	char * __fastcall ap_KeyData(void);
	Word __fastcall ap_KeyDrop(char * cpTagname);
	int __fastcall ap_Locate(char * cpExpression, Word iDirection, Word bContinue);
	Word __fastcall ap_LockCount(void);
	Word __fastcall ap_Locked(int lRecNum);
	void __fastcall ap_DBRlockList(char * ulpArray);
	char * __fastcall ap_MemAlloc(int lNumberOfBytes);
	void __fastcall ap_MemDealloc(void * vpPtr);
	short __fastcall ap_OpenMode(void);
	double __fastcall ap_OrderPosGet(void);
	void __fastcall ap_OrderPosSet(double dPosition);
	int __fastcall ap_OrderRecNo(void);
	void __fastcall ap_Pack(void);
	int __fastcall ap_PutBlob(char * cpFieldName, void * vpVar, int lSize);
	void __fastcall ap_PutRecord(char * cpRecord, int iRecSize);
	int __fastcall ap_PutMemo(char * cpFieldName, char * vpData);
	int __fastcall ap_Query(char * cpExpression);
	int __fastcall ap_QueryRowCount(char * cpExpression, int &RowCount);
	int __fastcall ap_QueryRecCount(void);
	BOOL __fastcall ap_QuerySetExact(BOOL bSetQueryExact);
	short __fastcall ap_QueryTest(char * cpExpression);
	void __fastcall ap_Recall(void);
	int __fastcall ap_RecCount(void);
	int __fastcall ap_RecNo(void);
	int __fastcall ap_RecSize(void);
	void __fastcall ap_Reindex(void);
	void __fastcall ap_Replace(char * cpFieldname, short iDataType, void * vpData);
	Word __fastcall ap_Rlock(int lRecNum);
	Word __fastcall ap_RYOFilterActivate(short iFilterHandle, short iBoolOperation);
	short __fastcall ap_RYOFilterCopy(void);
	short __fastcall ap_RYOFilterCreate(void);
	Word __fastcall ap_RYOFilterDestroy(short iFilterHandle);
	Word __fastcall ap_RYOFilterGetBit(short iFilterHandle, int lRecNo);
	Word __fastcall ap_RYOFilterRestore(char * cpFileName);
	Word __fastcall ap_RYOFilterSave(short iFilterHandle, char * cpFileName);
	Word __fastcall ap_RYOFilterSetBit(short iFilterHandle, int lRecNo, short iOnOrOff);
	Word __fastcall ap_RYOKeyAdd(char * cpTagname, char * cpKey);
	Word __fastcall ap_RYOKeyDrop(char * cpTagname);
	Word __fastcall ap_Seek(char * cpKeyValue);
	Word __fastcall ap_SeekBin(char * cpKeyValue, Word uiLength);
	int __fastcall ap_Select(int uiBaseArea);
	void __fastcall ap_SetCentury(Word uiOnOff);
	void __fastcall ap_SetDateFormat(Word uiDateType);
	void __fastcall ap_SetDeleted(Word uiDeleted);
	Word __fastcall ap_SetEpoch(Word uiBaseYear);
	int __fastcall ap_SetErrorFunc(int pFunc, int pData);
	void __fastcall ap_SetExact(Word uiOnOff);
	void __fastcall ap_SetFields(char * FFields);
	void __fastcall ap_SetFilter(char * cpExpression);
	void __fastcall ap_SetGaugeHook(HWND hwndGauge);
	void __fastcall ap_SetLockTimeout(short iSeconds);
	Word __fastcall ap_SetMemoBlockSize(Word uiBlockSize);
	short __fastcall ap_SetOrder(short iIndex);
	void __fastcall ap_SetPassword(char * cpEncodeKey);
	void __fastcall ap_SetQueryBit(int lRecNo, Word bValue);
	void __fastcall ap_SetRelation(Word uiChildArea, char * cpKeyExpr);
	Word __fastcall ap_SetScope(char * cpLowVal, char * cpHighVal);
	void __fastcall ap_SetSoftSeek(Word uiOnOff);
	void __fastcall ap_SetStringType(Word uiStringType);
	void __fastcall ap_SetTranslate(Word uiOnOff);
	void __fastcall ap_SetTurboRead(Word uiOnOff);
	void __fastcall ap_Skip(int lNumRecs);
	int __fastcall ap_SysProp(Word uiSysItem, void * vpData);
	short __fastcall ap_TagArea(char * cpTagName);
	BOOL __fastcall ap_TagDelete(char * cpTagname);
	char * __fastcall ap_TagName(short iTagArea);
	void __fastcall ap_Unlock(int lRecNum);
	short __fastcall ap_Use(char * cpDataBaseName, char * cpFileName, short iOpenMode, short iRdeType);
	short __fastcall ap_UseEx(char * cpDataBaseName, char * cpFileName, short iOpenMode, short iRdeType, unsigned uiMode);
	short __fastcall ap_QuickUse(AnsiString sDataBaseName, AnsiString sFileName, short iOpenMode, short iRdeType, int &FRowCount, int &FFieldCount, int &FRecordSize, Word &FIsEncrypted, AnsiString &FPassword, Word FTurboRead, AnsiString FIndexName, int FEpoch, int FDateFormat, int FMemoBlockSize, Word FDeleted, Word FCentury, Word FSoftSeek, Word FExact, Word FTranslate, Word FApplyEnvSettings, AnsiString FIndexCondition, int FCommitLevel, int &FIndexOrd, Db::TIndexDefs* &FIndexDefs, int &iError, AnsiString &sError);
	char * __fastcall ap_Version(void);
	Word __fastcall ap_WorkArea(char * cpAlias);
	void __fastcall ap_Zap(void);
	short __fastcall ap_GetTableType(AnsiString sDatabaseName, AnsiString sTableName);
	void __fastcall ap_SetSystemCollation(void);
	void __fastcall ap_SetMachineCollation(void);
	void __fastcall ap_AddDudenCollation(void);
	void __fastcall ap_AddEtecCollation(void);
	Classes::TMemoryStream* __fastcall ap_GoBofRecord(void);
	Classes::TMemoryStream* __fastcall ap_GoEofRecord(void);
	Classes::TMemoryStream* __fastcall ap_GoTopRecord(void);
	Classes::TMemoryStream* __fastcall ap_GoBottomRecord(void);
	Classes::TMemoryStream* __fastcall ap_GoRecord(const int lRecNum);
	Classes::TMemoryStream* __fastcall ap_GoGetRecord(void);
	int __fastcall ap_GoSkip(const int lRecNum, const int OffSet);
	int __fastcall ap_GoToRow(const int RowNo);
	int __fastcall ap_GetRowNo(void);
	void __fastcall ap_EnvSettings(int Epoch, int DateFormat, int MemoBlockSize, Word Deleted, Word Century, Word SoftSeek, Word Exact);
	Db::TGetResult __fastcall ap_TraverseTable(Word FirstCrack, Word LastCrack, int FEOFAction, Db::TGetMode GetMode, int &RecNo, char * LSDERecordBuffer, int iRecSize, int FetchCount);
	Db::TGetResult __fastcall ap_MultiTraverseTable(int &ReadCount, Word FirstCrack, Word LastCrack, int FEOFAction, Db::TGetMode GetMode, Db::TGetMode LastGetMode, char * LSDERecordBuffer, int iRecSize, int FetchCount, int LastRecNo, Classes::TList* &FFetchRecs);
	Word __fastcall ap_tps_BeginTransaction(void);
	Word __fastcall ap_tps_Commit(void);
	Word __fastcall ap_tps_RollBack(void);
	int __fastcall ap_sql_Prepare(Apcommon::TAccessMethod AccessMethod, AnsiString sDataBaseName, Classes::TCollection* TableNames, Word Century, AnsiString DateFormat, Word Deleted, int MemoBlockSize, Db::TParams* FParams, bool FReadOnly, Apcommon::TApolloTableType FDefaultTableType, AnsiString FDefaultPassword, bool FDefaultTranslate, Apcommon::TApolloCommitLevel FCommitLevel, int &iError, AnsiString &sError);
	void __fastcall ap_sql_ExecSQL(Apcommon::TAccessMethod AccessMethod, Word WASQL, AnsiString SQL, Db::TParams* FParams, int &iError, AnsiString &sError);
	void __fastcall ap_sql_OpenSQL(Apcommon::TAccessMethod AccessMethod, Word WASQL, AnsiString SQL, int &RowCount, int &FieldCount, int &RecordSize, int &iError, AnsiString &sError);
	void __fastcall ap_sql_CloseSQL(Apcommon::TAccessMethod AccessMethod, Word WASQL);
	void __fastcall ap_sql_UnPrepare(Apcommon::TAccessMethod AccessMethod, Word WASQL);
	int __fastcall ap_sql_RecCount(Apcommon::TAccessMethod AccessMethod, Word WASQL);
	void * __fastcall ap_sql_GetStructure(Apcommon::TAccessMethod AccessMethod, Word WASQL);
	void * __fastcall ap_sql_GetRecord(Apcommon::TAccessMethod AccessMethod, Word WASQL, int RecNo, int FetchCount, int RecordCount);
	Classes::TMemoryStream* __fastcall ap_sql_ReadBlobData(Apcommon::TAccessMethod AccessMethod, int WASQL, int RecNo, int FieldIndex);
	void __fastcall ap_sql_Refresh(Apcommon::TAccessMethod AccessMethod, Word WASQL);
	void __fastcall ap_sql_SetSystemCollation(Apcommon::TAccessMethod AccessMethod);
	void __fastcall ap_sql_SetMachineCollation(Apcommon::TAccessMethod AccessMethod);
	void __fastcall ap_sql_AddDudenCollation(Apcommon::TAccessMethod AccessMethod);
	void __fastcall ap_sql_AddEtecCollation(Apcommon::TAccessMethod AccessMethod);
	
__published:
	__property bool Active = {read=Connected, write=SetActive, nodefault};
	__property AnsiString ServerName = {read=FServerName, write=FServerName};
	__property AnsiString GroupName = {read=FGroupName, write=FGroupName};
	__property int TimeOut = {read=FTimeOut, write=FTimeOut, nodefault};
	__property AnsiString Version = {read=FVersion, write=FDummyVersion};
	__property TSocketConnectionLoginEvent OnLogin = {read=FOnLogin, write=FOnLogin};
	__property TSocketConnectionLogoutEvent OnLogout = {read=FOnLogout, write=FOnLogout};
	__property TSocketConnectionErrorEvent OnError = {read=FOnError, write=FOnError};
	__property TSocketConnectionServerMsgEvent OnServerMessage = {read=FOnServerMessage, write=FOnServerMessage};
	__property TSocketConnectionServerStreamEvent OnServerStream = {read=FOnServerStream, write=FOnServerStream};
};


//-- var, const, procedure ---------------------------------------------------
static const int SECONDS_PER_DAY = 0x15180;
#define sc_NOTHING "0000"
#define sc_TRIG_PROGRESS "0300"
#define sc_TRIG_MESSAGE "0301"
#define sc_TRIG_SHUTDOWN "0302"
#define sc_TRIG_STREAM "0303"
#define sc_WHOAREYOU "0448"
#define sc_WRONG_SERVERID "0449"
#define sc_MAXEDCONNECTION "0450"
#define sc_ACCESS_ACCT "0451"
#define sc_ACCESS_DENIED "0453"
#define sc_ROUTER_DOWN "0454"
#define sc_SERVER_DOWN "0455"
#define sc_ACCESS_ERROR "0456"
#define sc_ACCESS_OK "0457"
#define sc_ALLDONE "0458"
#define sc_CONNECTIONID "0459"
#define sc_FILERECEIVE "0036"
#define sc_FILESEND "0037"
#define sc_FILELENGTH "0038"
#define sc_GETDATABASENAMES "0039"
#define sc_GETTABLENAMES "0040"
#define sc_DATACOMPRESSION "0041"
#define sc_ExecProc "0042"
#define sc_GetProcedureNames "0043"
#define sc_GetParams "0044"
#define sc_SetParams "0045"
#define sc_GETINDEXNAMES "0046"
#define sc_GAUGE "0047"
#define sc_TEST "0048"
#define sc_REJECTEDMAXCON "0049"
#define sc_REJECTEDPASS "0050"
#define sc_REJECTEDUSER "0051"
#define sc_DATASECURED "0052"
#define sc_SERVERNAME "0053"
#define sc_FILEEXISTS "0054"
#define sc_DELETEFILE "0055"
#define sc_GETSERVERDATETIME "0056"
#define sc_GETDLLPROCS "0057"
#define sc_GETFILES "0058"
#define sc_FINDDRIVES "0059"
#define sc_FINDDIRECTORIES "0060"
#define sc_FINDFILES "0061"
#define sc_GETUSERNAMES "0062"
#define sc_CreateScript "0063"
#define sc_StopScript "0064"
#define sc_GetScriptsList "0065"
#define sc_DropScript "0066"
#define sc_RunScript "0067"
#define sc_CheckScriptSyntax "0068"
#define sc_UpdateScriptText "0069"
#define sc_GetScriptText "0070"
#define sc_FileIsInUse "0071"
#define sc_COPYFILE_EX "0072"
#define sc_GETSERVERLOG "0073"
#define sc_Login "0464"
#define sc_Logout "0465"
#define sc_UseEX "0467"
#define sc_USE "0468"
#define sc_QUICKUSE "0469"
#define sc_RECCOUNT "0470"
#define sc_QUERY "0471"
#define sc_APPEND "0472"
#define sc_APPENDBLANK "0473"
#define sc_APPENDFROM "0474"
#define sc_BLOBTOFILE "0475"
#define sc_BOF "0476"
#define sc_DELETE "0477"
#define sc_DELETED "0478"
#define sc_EOF "0479"
#define sc_GETBLOB "0480"
#define sc_GETBLOBLENGTH "0481"
#define sc_GETBYTE "0482"
#define sc_GETDATEJULIAN "0483"
#define sc_GETDATESTRING "0484"
#define sc_GETDOUBLE "0485"
#define sc_GETINTEGER "0486"
#define sc_GETLOGICAL "0487"
#define sc_GETLONG "0488"
#define sc_GETMEMO "0489"
#define sc_GETRECORD "0490"
#define sc_GetSTRING "0491"
#define sc_GETTRIMSTRING "0492"
#define sc_GO "0493"
#define sc_GOBOTTOM "0494"
#define sc_GOTOP "0495"
#define sc_KEYADD "0496"
#define sc_KEYDROP "0497"
#define sc_PUTBLOB "0498"
#define sc_RECNO "0500"
#define sc_REPLACE "0501"
#define sc_RLOCK "0502"
#define sc_SEEK "0503"
#define sc_SELECT "0504"
#define sc_SETSOFTSEEK "0505"
#define sc_SETEXACT "0506"
#define sc_SETORDER "0507"
#define sc_SETDELETED "0508"
#define sc_SKIP "0509"
#define sc_UNLOCK "0510"
#define sc_COMMIT "0511"
#define sc_COMMITLEVEL "0512"
#define sc_DESCEND "0513"
#define sc_RECSIZE "0514"
#define sc_READRECORD "0515"
#define sc_COUNT "0516"
#define sc_TagArea "0517"
#define sc_TagName "0518"
#define sc_QUERYRECCOUNT "0519"
#define sc_ORDERRECNO "0520"
#define sc_PACK "0521"
#define sc_ZAP "0522"
#define sc_WRITERECORD "0499"
#define sc_CLOSETABLE "0523"
#define sc_ORDERPOSGET "0524"
#define sc_INDEXNAME "0525"
#define sc_INDEXORD "0526"
#define sc_INDEXCOUNT "0527"
#define sc_INDEXDESCEND "0528"
#define sc_LOCATE "0529"
#define sc_ALIAS "0530"
#define sc_BASEDATE "0531"
#define sc_BASENAME "0532"
#define sc_CLOSEINDEXES "0533"
#define sc_INDEX "0534"
#define sc_COPYFILE "0535"
#define sc_COPYFILETEXT "0536"
#define sc_DBFDECRYPT "0537"
#define sc_DBFENCRYPT "0538"
#define sc_DBFILTER "0539"
#define sc_EMPTY "0540"
#define sc_ERRORLEVEL "0541"
#define sc_REINDEX "0542"
#define sc_EVALLOGICAL "0543"
#define sc_EVALNUMERIC "0544"
#define sc_EVALSTRING "0545"
#define sc_EVALTEST "0546"
#define sc_FLOCK "0547"
#define sc_FOUND "0548"
#define sc_GETQUERYBIT "0549"
#define sc_GETSCOPE "0550"
#define sc_INDEXCLOSE "0551"
#define sc_INDEXCONDITION "0552"
#define sc_INDEXTYPE "0553"
#define sc_INDEXKEY "0554"
#define sc_INDEXKEYFIELD "0555"
#define sc_SETCENTURY "0556"
#define sc_SETDATEFORMAT "0557"
#define sc_ORDERPOSSET "0558"
#define sc_CREATEEXEC "0559"
#define sc_CREATEFIELD "0560"
#define sc_CREATEFROM "0561"
#define sc_CREATENEW "0562"
#define sc_SYSPROP "0563"
#define sc_INDEXTAG "0564"
#define sc_CLOSEALL "0565"
#define sc_SETPASSWORD "0566"
#define sc_SETSCOPE "0567"
#define sc_INDEXFLIP "0568"
#define sc_RECALL "0569"
#define sc_QUERYTEST "0570"
#define sc_WORKAREA "0571"
#define sc_DECRYPT "0572"
#define sc_ENCRYPT "0573"
#define sc_FILTERALIAS "0574"
#define sc_FILTERDLG "0575"
#define sc_SETTURBOREAD "0576"
#define sc_SetLockTimeOut "0577"
#define sc_IsEncrypted "0578"
#define sc_KEYDATA "0579"
#define sc_LOCKED "0580"
#define sc_GETSTRUCTURE "0581"
#define sc_READFIELDS "0582"
#define sc_SETFIELDS "0583"
#define sc_PUTMEMO "0584"
#define sc_SETQUERYBIT "0585"
#define sc_SEEKBIN "0586"
#define sc_SETTRANSLATE "0587"
#define sc_DBRLockList "0588"
#define sc_LockCount "0589"
#define sc_SETRELATION "0590"
#define sc_TRAVERSETABLE "0591"
#define sc_SETFILTER "0592"
#define sc_SETEPOCH "0593"
#define sc_SETMEMOBLOCKSIZE "0594"
#define sc_RYOFILTERACTIVATE "0595"
#define sc_RYOFILTERCOPY "0596"
#define sc_RYOFILTERCREATE "0597"
#define sc_RYOFILTERDESTROY "0598"
#define sc_RYOFILTERGETBIT "0599"
#define sc_RYOFILTERRESTORE "0600"
#define sc_RYOFILTERSAVE "0601"
#define sc_RYOFILTERSETBIT "0602"
#define sc_RYOKEYADD "0603"
#define sc_RYOKEYDROP "0604"
#define sc_FIELDCOUNT "0610"
#define sc_FIELDDECIMALS "0611"
#define sc_FIELDNAME "0612"
#define sc_FIELDNUM "0613"
#define sc_FIELDOFFSET "0614"
#define sc_FIELDTYPE "0615"
#define sc_FIELDWIDTH "0616"
#define sc_GetPage "0617"
#define sc_VERSION "0618"
#define sc_INDEXOPEN "0620"
#define sc_ENVSETTINGS "0621"
#define sc_COPYSTRUCTURE "0622"
#define sc_CopyStructureExtended "0623"
#define sc_PUTBLOBBYTES "0624"
#define sc_OPENMODE "0625"
#define sc_MULTITRAVERSETABLE "0626"
#define sc_SendWriteStream "0628"
#define sc_SetCompressionPassword "0629"
#define sc_QUERYSETEXACT "0630"
#define sc_TagDelete "0631"
#define sc_GoBofRecord "0632"
#define sc_GoEofRecord "0633"
#define sc_GoBottomRecord "0634"
#define sc_GoTopRecord "0635"
#define sc_GoSkip "0636"
#define sc_GoRecord "0637"
#define sc_GETTABLETYPE "0638"
#define sc_GoGetRecord "0639"
#define sc_SetSystemCollation "0640"
#define sc_SetMachineCollation "0641"
#define sc_AddDudenCollation "0642"
#define sc_AddEtecCollation "0643"
#define sc_GoToRow "0644"
#define sc_GetRowNo "0645"
#define sc_QueryRowCount "0646"
#define sc_CreateConnection "0647"
#define sc_IsServerConnectedToRelay "0648"
#define sc_GetServerListFromRelay "0649"
#define sc_tps_BEGINTRANSACTION "0700"
#define sc_tps_COMMIT "0701"
#define sc_tps_ROLLBACK "0702"
#define sc_tps_APPLYUPDATES "0703"
#define sc_sql_PREPARE "0800"
#define sc_sql_UNPREPARE "0801"
#define sc_sql_OPENSQL "0802"
#define sc_sql_EXECSQL "0803"
#define sc_sql_CLOSESQL "0804"
#define sc_sql_RECCOUNT "0805"
#define sc_sql_GETSTRUCTURE "0806"
#define sc_sql_READRECORD "0807"
#define sc_sql_READBLOBDATA "0808"
#define sc_sql_REFRESH "0809"
#define sc_sql_CREATETABLE "0810"
#define sc_sql_CREATEINDEX "0811"
#define sc_SQL_SetSystemCollation "0820"
#define sc_SQL_SetMachineCollation "0821"
#define sc_SQL_AddDudenCollation "0822"
#define sc_SQL_AddEtecCollation "0823"
static const int MAXRECLEN = 0x10001;

}	/* namespace Apconn */
using namespace Apconn;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ApConn
