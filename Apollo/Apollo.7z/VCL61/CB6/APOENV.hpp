// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ApoEnv.pas' rev: 6.00

#ifndef ApoEnvHPP
#define ApoEnvHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ApCommon.hpp>	// Pascal unit
#include <ApConn.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <DBCommon.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <DB.hpp>	// Pascal unit
#include <SDE61.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Apoenv
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TApolloApplyType { atLocal, atServer };
#pragma option pop

typedef Set<TApolloApplyType, atLocal, atServer>  TApolloApplyTo;

class DELPHICLASS TApolloEnv;
class PASCALIMPLEMENTATION TApolloEnv : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	TApolloApplyTo FApolloApplyTo;
	Apconn::TApolloConnection* FApolloConnection;
	bool FAutoRefresh;
	Word FCentury;
	Apcommon::TApolloDateFrmt FDateFormat;
	Word FDeleted;
	int FLockTimeOut;
	Word FMemoBlockSize;
	bool FOptimisticBuffer;
	bool FSoftSeek;
	bool FExact;
	int FEpoch;
	int FErrorLevel;
	Word FCountNeedsRefresh;
	int FErrorFunc;
	
protected:
	Word __fastcall GetCentury(void);
	Apcommon::TApolloDateFrmt __fastcall GetDateFormat(void);
	int __fastcall GetLockTimeout(void);
	Word __fastcall GetDeleted(void);
	int __fastcall GetEpoch(void);
	Word __fastcall GetExact(void);
	Word __fastcall GetOptimisticBuffer(void);
	Word __fastcall GetMemoBlockSize(void);
	Word __fastcall GetSoftSeek(void);
	virtual void __fastcall Loaded(void);
	
public:
	__fastcall virtual TApolloEnv(Classes::TComponent* Owner);
	__fastcall virtual ~TApolloEnv(void);
	int __fastcall ErrorLevel(const int Value);
	int __fastcall GetErrorLevel(void);
	void __fastcall CloseDataSets(void);
	void __fastcall OpenDataSets(void);
	void __fastcall RefreshDataSets(void);
	void __fastcall SetCentury(const Word Value);
	void __fastcall SetDateFormat(const Apcommon::TApolloDateFrmt Value);
	void __fastcall SetDeleted(const Word Value);
	void __fastcall SetEpoch(const int Value);
	int __fastcall SetErrorFunc(const int pFunc, const int pData);
	void __fastcall SetExact(const Word Value);
	void __fastcall SetLockTimeOut(const int Value);
	void __fastcall SetOptimisticBuffer(const Word Value);
	void __fastcall SetMemoBlockSize(const Word Value);
	void __fastcall SetSoftSeek(const Word Value);
	int __fastcall SysProp(Word uiSysItem, void * vpData);
	
__published:
	__property Apconn::TApolloConnection* ApolloConnection = {read=FApolloConnection, write=FApolloConnection};
	__property TApolloApplyTo ApplyTo = {read=FApolloApplyTo, write=FApolloApplyTo, nodefault};
	__property bool AutoRefresh = {read=FAutoRefresh, write=FAutoRefresh, default=1};
	__property Word Century = {read=GetCentury, write=SetCentury, default=-1};
	__property Apcommon::TApolloDateFrmt DateFormat = {read=GetDateFormat, write=SetDateFormat, default=7};
	__property Word Deleted = {read=GetDeleted, write=SetDeleted, default=0};
	__property int Epoch = {read=GetEpoch, write=SetEpoch, default=1980};
	__property Word Exact = {read=GetExact, write=SetExact, default=0};
	__property int ErrorFunc = {read=FErrorFunc, nodefault};
	__property Word CountNeedsRefresh = {read=FCountNeedsRefresh, nodefault};
	__property int LockTimeOut = {read=GetLockTimeout, write=SetLockTimeOut, default=1};
	__property Word MemoBlockSize = {read=GetMemoBlockSize, write=SetMemoBlockSize, default=64};
	__property Word OptimisticBuffer = {read=GetOptimisticBuffer, write=SetOptimisticBuffer, default=0};
	__property Word SoftSeek = {read=GetSoftSeek, write=SetSoftSeek, default=0};
};


class DELPHICLASS TApolloDatabase;
class PASCALIMPLEMENTATION TApolloDatabase : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	AnsiString FDataPath;
	AnsiString FDataPathAlias;
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation);
	
public:
	__fastcall virtual TApolloDatabase(Classes::TComponent* Owner);
	__fastcall virtual ~TApolloDatabase(void);
	void __fastcall CloseDataSets(void);
	void __fastcall EnumTableNames(Classes::TStrings* List, const AnsiString Ext = "dbf");
	void __fastcall EnumDataSets(Classes::TList* List);
	void __fastcall OpenDataSets(void);
	void __fastcall RefreshDataSets(void);
	
__published:
	__property AnsiString DataPath = {read=FDataPath, write=FDataPath};
	__property AnsiString DataPathAlias = {read=FDataPathAlias, write=FDataPathAlias};
};


//-- var, const, procedure ---------------------------------------------------
static const Word EPOCH_DEFAULT = 0x7bc;
static const Shortint AMERICAN = 0x0;
static const Shortint ANSI = 0x1;
static const Shortint BRITISH = 0x2;
static const Shortint FRENCH = 0x3;
static const Shortint GERMAN = 0x4;
static const Shortint ITALIAN = 0x5;
static const Shortint SPANISH = 0x6;
static const Shortint WIN_DEFAULT = 0x63;
extern PACKAGE Classes::TList* __fastcall apDatabaseList(void);
extern PACKAGE void __fastcall apAddDatabase(Classes::TComponent* oComp);
extern PACKAGE void __fastcall apRemoveDatabase(Classes::TComponent* oComp);

}	/* namespace Apoenv */
using namespace Apoenv;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ApoEnv
