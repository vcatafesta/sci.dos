// Borland C++ Builder
// Copyright (c) 1995, 2002 by Borland Software Corporation
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ApCommon.pas' rev: 6.00

#ifndef ApCommonHPP
#define ApCommonHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <DB.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <SDE61.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Apcommon
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TxProgressStatus { psXStart, psXProgress, psXEnd };
#pragma option pop

typedef void __fastcall (__closure *TxProgressEvent)(System::TObject* Sender, TxProgressStatus Status, int Min, int Max, int Position);

#pragma option push -b-
enum TApolloTableType { ttSXNONE, ttSXNTX, ttSXFOX, ttSXNSX, ttSXNSX_DBT };
#pragma option pop

#pragma option push -b-
enum TApolloCommitLevel { clFull, clNormal, clNone };
#pragma option pop

#pragma option push -b-
enum TAccessMethod { amLocal, amServer };
#pragma option pop

#pragma option push -b-
enum TDriveType { dtUnknown, dtNoDrive, dtFloppy, dtFixed, dtNetwork, dtCDROM, dtRAM };
#pragma option pop

#pragma option push -b-
enum TApolloDateFrmt { dfAmerican, dfAnsi, dfBritish, dfFrench, dfGerman, dfItalian, dfSpanish, dfWinDefault };
#pragma option pop

#pragma option push -b-
enum TRowType { rtNone, rtGoTop_BOF, rtGotop, rtGoBottom, rtGoBottom_EOF, rtGo, rtSkip };
#pragma option pop

struct ADBRecList;
typedef ADBRecList *PADBRecList;

typedef DynamicArray<void * >  ApCommon__1;

struct ADBRecList
{
	Db::TGetResult GetResult;
	int RecNum;
	double OrderPosGet;
	char *RecBuffer;
	bool BOF;
	bool EoF;
	int RowNo;
	TRowType RowType;
	int PreviousRow;
	int NextRow;
	DynamicArray<void * >  Blobs;
} ;

class DELPHICLASS TTickClock;
class PASCALIMPLEMENTATION TTickClock : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	int iStartedClock;
	bool FProcessMessages;
	int __fastcall MSSeconds(void);
	
public:
	void __fastcall Sleep(int iMS);
	bool __fastcall Delay(int iMS);
	void __fastcall Reset(void);
	__fastcall TTickClock(bool bProcessMessage);
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TTickClock(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
static const Shortint VER_MONTH = 0xb;
static const Shortint VER_DAY = 0x5;
static const Word VER_YEAR = 0x7d3;
#define APDS_VER "6.1.0.8"
#define ApolloSQL_VER "6.1.0.8"
#define ApolloCONNECTION_VER "6.1.0.8"
#define ApolloServerScript_VER "6.1.0.8"
#define ApolloADBInterface_VER "6.1.0.8"
#define ApolloADBX60_VER "6.1.0.8"
#define ApolloServerDLL_VER "6.1.0.8"
#define ApolloSDEInterface_VER "6.1.0.8"
extern PACKAGE bool IsApolloASPRunning;
extern PACKAGE bool ApolloDebugging;
static const int DB_S_ENDOFCURSOR = 0x40ec3;
static const int E_DAO_FAIL = 0x7fffbffb;
static const Shortint S_DAO_OK = 0x0;
extern PACKAGE AnsiString __fastcall Padr(AnsiString cStr, int nRepeat, char cChar);
extern PACKAGE AnsiString __fastcall SubStr(const AnsiString cString, int nStart, int nEnd);
extern PACKAGE AnsiString __fastcall LogicalToYN(bool YN);
extern PACKAGE bool __fastcall YNToLogical(AnsiString YN);
extern PACKAGE AnsiString __fastcall sLeft(const AnsiString cString, int nCount);
extern PACKAGE int __fastcall InternalGoToRow(const int RowNo);
extern PACKAGE int __fastcall InternalGetRowNo(void);
extern PACKAGE int __fastcall InternalGoSkip(int RowNo, int OffSet);
extern PACKAGE void __fastcall InternalGetRecord(Classes::TMemoryStream* &Stream);
extern PACKAGE bool __fastcall InternalBreakRecords(Classes::TMemoryStream* pMem, bool &BOF, bool &EoF, int &RecNo, int &RowNo, double &OrderPosGet, char * &ActiveBuffer, const int RecSize);

}	/* namespace Apcommon */
using namespace Apcommon;
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ApCommon
