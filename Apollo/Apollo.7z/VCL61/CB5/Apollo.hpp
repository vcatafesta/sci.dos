// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Apollo.pas' rev: 5.00

#ifndef ApolloHPP
#define ApolloHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Db.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Apollo
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TApollo;
class PASCALIMPLEMENTATION TApollo : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	Db::TDataSource* FDataSource;
	Classes::TStringList* FIndexes;
	AnsiString FFilter;
	bool FTurboRead;
	
public:
	__fastcall virtual TApollo(Classes::TComponent* AOwner);
	__fastcall virtual ~TApollo(void);
	
__published:
	__property Db::TDataSource* DataSource = {read=FDataSource, write=FDataSource};
	__property Classes::TStringList* ExtraIndexes = {read=FIndexes, write=FIndexes};
	__property AnsiString Filter = {read=FFilter, write=FFilter};
	__property bool TurboRead = {read=FTurboRead, write=FTurboRead, nodefault};
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Apollo */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Apollo;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Apollo
