// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ApoServerDLL.pas' rev: 5.00

#ifndef ApoServerDLLHPP
#define ApoServerDLLHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <ApCommon.hpp>	// Pascal unit
#include <ApoDSet.hpp>	// Pascal unit
#include <ApConn.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <TypInfo.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Aposerverdll
{
//-- type declarations -------------------------------------------------------
typedef void __fastcall (__closure *TExecDLLErrorEvent)(System::TObject* Sender, AnsiString ErrorMsg
	, int ErrorNo);

class DELPHICLASS EApolloServerDLL;
class PASCALIMPLEMENTATION EApolloServerDLL : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApolloServerDLL(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApolloServerDLL(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApolloServerDLL(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApolloServerDLL(int Ident, const System::TVarRec * 
		Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApolloServerDLL(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApolloServerDLL(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApolloServerDLL(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApolloServerDLL(System::PResStringRec ResStringRec
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApolloServerDLL(void) { }
	#pragma option pop
	
};


class DELPHICLASS TApolloServerDLL;
class PASCALIMPLEMENTATION TApolloServerDLL : public Classes::TComponent 
{
	typedef Classes::TComponent inherited;
	
private:
	AnsiString FDummyVersion;
	Apconn::TApolloConnection* FApolloConnection;
	AnsiString FDatabaseName;
	AnsiString FVersion;
	AnsiString FProcName;
	Db::TParams* FProcParams;
	AnsiString FErrorMsg;
	int FErrorNo;
	TExecDLLErrorEvent FOnError;
	void __fastcall SetApolloConnection(Apconn::TApolloConnection* Val);
	void __fastcall SetDatabaseName(AnsiString Value);
	void __fastcall SetDLLProcName(AnsiString Value);
	void __fastcall InternalGetParams(void);
	void __fastcall InternalSetParams(void);
	
protected:
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation
		);
	virtual void __fastcall Loaded(void);
	
public:
	__fastcall virtual TApolloServerDLL(Classes::TComponent* AOwner);
	__fastcall virtual ~TApolloServerDLL(void);
	__property AnsiString ErrorMsg = {read=FErrorMsg, write=FErrorMsg};
	__property int ErrorNo = {read=FErrorNo, write=FErrorNo, nodefault};
	
__published:
	__property Apconn::TApolloConnection* ApolloConnection = {read=FApolloConnection, write=SetApolloConnection
		};
	__property AnsiString DatabaseName = {read=FDatabaseName, write=SetDatabaseName};
	__property AnsiString ProcName = {read=FProcName, write=SetDLLProcName};
	__property Db::TParams* ProcParams = {read=FProcParams, write=FProcParams};
	__property TExecDLLErrorEvent OnError = {read=FOnError, write=FOnError};
	__property AnsiString Version = {read=FVersion, write=FDummyVersion};
	bool __fastcall ExecProc(void);
};


//-- var, const, procedure ---------------------------------------------------
#define ERR_EMPTY_PROCNAME "ProcName is empty!"

}	/* namespace Aposerverdll */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Aposerverdll;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ApoServerDLL
