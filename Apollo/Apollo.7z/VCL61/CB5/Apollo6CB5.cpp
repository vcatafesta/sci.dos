//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("Apollo6CB5.res");
USEUNIT("ApoDSet.pas");
USEUNIT("ApoEnv.pas");
USEUNIT("ApCommon.pas");
USEUNIT("ApConn.pas");
USEUNIT("ApGlobal.pas");
USEUNIT("ApoQSet.pas");
USEUNIT("ApWin.pas");
USEUNIT("Apollo.pas");
USEUNIT("CompStream.pas");
USEPACKAGE("vcl50.bpi");
USEPACKAGE("vcldb50.bpi");
USEPACKAGE("vclbde50.bpi");
USEUNIT("SDE61.PAS");
USEPACKAGE("Vclx50.bpi");
USELIB("fts32.lib");
USEUNIT("IntSQL.PAS");
USEUNIT("IntCrypt.pas");
USEUNIT("ApoServerDLL.PAS");
//---------------------------------------------------------------------------
#pragma package(smart_init)
//---------------------------------------------------------------------------
//   Package source.
//---------------------------------------------------------------------------
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void*)
{
	return 1;
}
//---------------------------------------------------------------------------
