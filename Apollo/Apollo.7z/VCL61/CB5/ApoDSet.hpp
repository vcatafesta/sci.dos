// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ApoDSet.pas' rev: 5.00

#ifndef ApoDSetHPP
#define ApoDSetHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Registry.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <ApConn.hpp>	// Pascal unit
#include <ApCommon.hpp>	// Pascal unit
#include <ApoEnv.hpp>	// Pascal unit
#include <SDE61.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <DBCommon.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Apodset
{
//-- type declarations -------------------------------------------------------
#pragma option push -b-
enum TUpdateKind { ukModify, ukInsert, ukDelete };
#pragma option pop

#pragma option push -b-
enum TUpdateStatus { usUnmodified, usModified, usInserted, usDeleted };
#pragma option pop

#pragma option push -b-
enum TUpdateAction { uaFail, uaAbort, uaSkip, uaRetry, uaApplied };
#pragma option pop

#pragma option push -b-
enum ApoDSet__1 { rtModified, rtInserted, rtDeleted, rtUnmodified };
#pragma option pop

typedef Set<ApoDSet__1, rtModified, rtUnmodified>  TUpdateRecordTypes;

typedef void __fastcall (__closure *TUpdateRecordEvent)(Db::TDataSet* DataSet, TUpdateKind UpdateKind
	, TUpdateAction &UpdateAction);

typedef void __fastcall (__closure *TUpdateErrorEvent)(Db::TDataSet* DataSet, Db::EDatabaseError* E, 
	TUpdateKind UpdateKind, TUpdateAction &UpdateAction);

struct FetchList;
typedef FetchList *PFetchList;

struct FetchList
{
	Db::TGetResult GetResult;
	int RecNum;
	int RecOrdinal;
	char *Data;
	bool Next;
} ;

struct RecList;
typedef RecList *PRecList;

struct RecList
{
	TUpdateStatus upStatus;
	TUpdateAction upAction;
	Word SDEDeleted;
	int BackIndex;
	int RecNo;
	int RecNum;
	AnsiString Data;
} ;

typedef DynamicArray<int >  TServerRecNo;

class DELPHICLASS EApolloError;
class PASCALIMPLEMENTATION EApolloError : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApolloError(const AnsiString Msg) : Sysutils::Exception(Msg
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApolloError(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApolloError(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApolloError(int Ident, const System::TVarRec * Args
		, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApolloError(const AnsiString Msg, int AHelpContext) : 
		Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApolloError(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApolloError(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApolloError(System::PResStringRec ResStringRec, 
		const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApolloError(void) { }
	#pragma option pop
	
};


typedef DynamicArray<int >  TLockList;

#pragma pack(push, 1)
struct TApBlobData
{
	int Size;
	char *Data;
	char SDEPointer[10];
	Byte Modified;
	Byte Loaded;
} ;
#pragma pack(pop)

typedef TApBlobData *PBlobData;

struct TRecInfo;
typedef TRecInfo *PRecInfo;

#pragma pack(push, 1)
struct TRecInfo
{
	int Bookmark;
	Db::TBookmarkFlag BookmarkFlag;
} ;
#pragma pack(pop)

#pragma pack(push, 1)
struct TDateFld
{
	char Year[4];
	char Month[2];
	char Day[2];
} ;
#pragma pack(pop)

class DELPHICLASS TFieldInfo;
class PASCALIMPLEMENTATION TFieldInfo : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	int SDEOffset;
	int NativeOffset;
	int Width;
	int Decimals;
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TFieldInfo(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TFieldInfo(void) { }
	#pragma option pop
	
};


struct TDbfStruct
{
	AnsiString sName;
	AnsiString sType;
	int iLength;
	int iDecimals;
} ;

struct RTagInfo
{
	BOOL bActive;
	int iIndexOrder;
	BOOL bHasParentIndex;
	BOOL bUnique;
	BOOL bDesc;
	BOOL bRYO;
	char *cpTagName;
	char *cpKeyExpr;
	char *cpForExpr;
} ;

class DELPHICLASS TApBlobStream;
class DELPHICLASS TApolloTable;
class DELPHICLASS TTagStructure;
typedef DynamicArray<RTagInfo >  ApoDSet__8;

struct ApoDSet__7
{
	int iCount;
	DynamicArray<RTagInfo >  pTagsInfo;
} ;

class PASCALIMPLEMENTATION TTagStructure : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	ApoDSet__7 RTagBackInfo;
	AnsiString __fastcall GetTagName(int iIndex);
	AnsiString __fastcall GetKeyExpr(int iIndex);
	AnsiString __fastcall GetForExpr(int iIndex);
	bool __fastcall GetActiveStatus(int iIndex);
	int __fastcall GetOrder(int iIndex);
	bool __fastcall IsHasParent(int iIndex);
	bool __fastcall IsUnique(int iIndex);
	bool __fastcall IsDescend(int iIndex);
	bool __fastcall IsRyo(int iIndex);
	
public:
	__fastcall virtual ~TTagStructure(void);
	__property int _TagCount = {read=RTagBackInfo.iCount, nodefault};
	__property AnsiString _TagName[int iIndex] = {read=GetTagName};
	__property AnsiString _KeyExpr[int iIndex] = {read=GetKeyExpr};
	__property AnsiString _ForExpr[int iIndex] = {read=GetForExpr};
	__property bool _IsActive[int iIndex] = {read=GetActiveStatus};
	__property int _Order[int iIndex] = {read=GetOrder};
	__property bool _HasParent[int iIndex] = {read=IsHasParent};
	__property bool _IsUnique[int iIndex] = {read=IsUnique};
	__property bool _IsDescend[int iIndex] = {read=IsDescend};
	__property bool _IsRyo[int iIndex] = {read=IsRyo};
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TTagStructure(void) : System::TObject() { }
	#pragma option pop
	
};


#pragma option push -b-
enum TEOFAction { eaEOF, eaMoveLast };
#pragma option pop

#pragma option push -b-
enum TSequencedCount { scAllCount, scFilterOnlyCount, scRawCount };
#pragma option pop

#pragma option push -b-
enum TApolloRangeSet { rsNone, rsStart, rsEnd };
#pragma option pop

typedef DynamicArray<AnsiString >  ApoDSet__01;

typedef DynamicArray<int >  ApoDSet__11;

typedef DynamicArray<int >  ApoDSet__21;

typedef DynamicArray<int >  ApoDSet__31;

typedef DynamicArray<AnsiString >  ApoDSet__41;

class PASCALIMPLEMENTATION TApolloTable : public Db::TDataSet 
{
	typedef Db::TDataSet inherited;
	
private:
	bool FIndirectlyAssigned;
	TTagStructure* m_TagInfo;
	
protected:
	Apcommon::TApolloCommitLevel FCommitLevel;
	Classes::TStrings* FStructList;
	AnsiString FLastIndexNameVar;
	BOOL FInTrans;
	DynamicArray<int >  FServerRecNo;
	int FFetchCount;
	int FFetchLastRec;
	Db::TGetMode FFetchSavedDirection;
	int FFetchReadCount;
	FetchList *AFetch;
	Classes::TList* FFetchRecs;
	Classes::TList* FRecords;
	Classes::TList* FBackRecords;
	RecList *ARecord;
	int FRecNo;
	int fFRecOrdinal;
	bool FCachedUpdates;
	bool FUpdatesPending;
	TUpdateRecordTypes FUpdateRecordTypes;
	TUpdateRecordEvent FOnUpdateRecord;
	TUpdateErrorEvent FOnUpdateError;
	Word FCountNeedsRefresh;
	bool FCentury;
	bool FExact;
	bool FSoftSeek;
	Apcommon::TApolloDateFrmt FDateFormat;
	Word FTranslate;
	int FMemoBlockSize;
	AnsiString FErrorMsg;
	int FErrorFunc;
	int FRecSize;
	int FEpoch;
	int FErrorLevel;
	Word FDeleted;
	TEOFAction FEOFAction;
	int FRowCount;
	int FRecCount;
	TSequencedCount FSequencedCount;
	AnsiString FDatabaseName;
	Apoenv::TApolloDatabase* FDatabase;
	Apcommon::TApolloTableType FTableType;
	Word FTurboRead;
	Word FApplyEnvSettings;
	Variant FRangeStart;
	Variant FRangeEnd;
	TApolloRangeSet FRangeSet;
	bool FAddingIndex;
	AnsiString FPassword;
	short iWA;
	AnsiString FLastScopeVar;
	AnsiString FScopeBegin;
	AnsiString FScopeEnd;
	bool FScoped;
	Word FSpeedMode;
	AnsiString FDataPath;
	bool FSequenced;
	Classes::TStringList* FExtraIndexes;
	Db::TIndexDefs* FIndexDefs;
	Db::TMasterDataLink* FMasterLink;
	int FRecBufSize;
	int FRecInfoOfs;
	int FBlobCacheOfs;
	int FCalcFieldsOfs;
	AnsiString FTableName;
	Word FExclusive;
	Word FReadOnly;
	Classes::TList* LFieldOffsets;
	Word FCursorOpen;
	Word FFirstCrack;
	Word FLastCrack;
	AnsiString LLocateExpression;
	Word LLocateDirection;
	AnsiString FIndexName;
	Word FAppending;
	int FDummyNum;
	AnsiString FDummyString;
	int FOldRec;
	Word FWriteBlobHdr;
	char *LSDERecordBuffer;
	bool LOpeningTable;
	AnsiString FFilterStr;
	bool FFiltered;
	char *LFilterRecordBuffer;
	Word FIsTableEncrypted;
	int FSDEFieldCount;
	int FLocateIndexOrd;
	int FIndexOrd;
	AnsiString FIndexCondition;
	bool FOptimisticCommit;
	Apcommon::TAccessMethod FAccessMethod;
	Word FIsEncrypted;
	DynamicArray<int >  FLockList;
	Word FUpdateLockList;
	Apconn::TApolloConnection* FApolloConnection;
	int __fastcall GetFRecOrdinal(void);
	__property int FRecOrdinal = {read=GetFRecOrdinal, write=fFRecOrdinal, nodefault};
	void __fastcall SetTranslate(Word Value);
	void __fastcall SetApolloConnection(Apconn::TApolloConnection* Val);
	void __fastcall SetAccessMethod(Apcommon::TAccessMethod Value);
	void __fastcall RaiseApollo(AnsiString msg);
	void __fastcall ClearFetchedItems(void);
	Db::TGetResult __fastcall FetchRecord(Word FirstCrack, Word LastCrack, int FEOFAction, Db::TGetMode 
		GetMode, int &iRecNo);
	void __fastcall OpenTable(void);
	void __fastcall SetTableType(Apcommon::TApolloTableType Value);
	void __fastcall SetCommitLevel(Apcommon::TApolloCommitLevel Value);
	void __fastcall CheckMasterRange(void);
	void __fastcall MasterChanged(System::TObject* Sender);
	void __fastcall MasterDisabled(System::TObject* Sender);
	Db::TDataSource* __fastcall GetMasterSource(void);
	void __fastcall SetMasterSource(Db::TDataSource* Value);
	AnsiString __fastcall GetMasterFields(void);
	void __fastcall SetMasterFields(const AnsiString Value);
	AnsiString __fastcall GetMasterVal(void);
	void __fastcall SetIndexName(AnsiString Value);
	void __fastcall GetDataPath(void);
	virtual void __fastcall DoOnNewRecord(void);
	virtual void __fastcall InternalOpen(void);
	virtual void __fastcall InternalClose(void);
	virtual void __fastcall InternalInitFieldDefs(void);
	HIDESBASE void __fastcall CreateFields(void);
	PBlobData __fastcall GetBlobData(Db::TField* Field);
	int __fastcall GetLockList(int Index);
	Word __fastcall GetApolloBOF(void);
	Word __fastcall GetApolloEOF(void);
	Apoenv::TApolloDatabase* __fastcall GetDatabase(void);
	void __fastcall SetDatabaseName(AnsiString Value);
	void __fastcall SetTableName(AnsiString Value);
	bool __fastcall GetExists(void);
	AnsiString __fastcall GetIndexExt(void);
	AnsiString __fastcall GetMemoExt(void);
	int __fastcall GetIndexFieldCount(void);
	int __fastcall GetSXRecno(void);
	int __fastcall GetSXRecCount(void);
	AnsiString __fastcall GetUniqueAliasName(AnsiString sTableName);
	int __fastcall ApolloTableType(Apcommon::TApolloTableType Value);
	Word __fastcall GetDeleted(void);
	void __fastcall SetExclusive(Word Value);
	void __fastcall SetExtraIndexes(Classes::TStringList* Value);
	void __fastcall SetReadOnly(Word Value);
	void __fastcall SetSequenced(bool Value);
	AnsiString __fastcall GetVersion(void);
	void __fastcall SetScopeBegin(AnsiString Value);
	void __fastcall SetScoped(bool Value);
	void __fastcall SetScopeEnd(AnsiString Value);
	void __fastcall SetSpeedMode(Word Value);
	void __fastcall WriteNativeToSDE(char * Buffer);
	void __fastcall ReadSDEToNative(char * Buffer);
	void __fastcall SetWriteBlobHdr(Word Value);
	void __fastcall SetSxQuery(AnsiString Value);
	void __fastcall UpdateFieldAndIndexDefs(void);
	virtual void __fastcall InternalRefresh(void);
	virtual void __fastcall ClearBuffers(void);
	virtual void __fastcall ClearCalcFields(char * Buffer);
	virtual char * __fastcall AllocRecordBuffer(void);
	virtual void __fastcall FreeRecordBuffer(char * &Buffer);
	virtual void __fastcall GetBookmarkData(char * Buffer, void * Data);
	virtual Db::TBookmarkFlag __fastcall GetBookmarkFlag(char * Buffer);
	Word __fastcall GetLockCount(void);
	virtual Db::TGetResult __fastcall GetRecord(char * Buffer, Db::TGetMode GetMode, bool DoCheck);
	virtual Word __fastcall GetRecordSize(void);
	virtual void __fastcall InternalAddRecord(void * Buffer, bool Append);
	virtual void __fastcall InternalDelete(void);
	virtual void __fastcall InternalFirst(void);
	virtual void __fastcall InternalGotoBookmark(void * Bookmark);
	virtual void __fastcall InternalHandleException(void);
	virtual void __fastcall InternalInitRecord(char * Buffer);
	virtual void __fastcall InternalLast(void);
	virtual void __fastcall InternalPost(void);
	virtual void __fastcall InternalSetToRecord(char * Buffer);
	virtual bool __fastcall IsCursorOpen(void);
	virtual void __fastcall SetBookmarkFlag(char * Buffer, Db::TBookmarkFlag Value);
	virtual void __fastcall SetBookmarkData(char * Buffer, void * Data);
	virtual void __fastcall SetFieldData(Db::TField* Field, void * Buffer)/* overload */;
	virtual bool __fastcall GetCanModify(void);
	virtual void __fastcall RefreshInternalCalcFields(char * Buffer);
	AnsiString __fastcall PathFromAlias(void);
	virtual void __fastcall Loaded(void);
	virtual void __fastcall DoBeforeEdit(void);
	virtual void __fastcall DoBeforeInsert(void);
	virtual void __fastcall DoAfterInsert(void);
	virtual void __fastcall DoAfterCancel(void);
	virtual void __fastcall DoAfterScroll(void);
	virtual void __fastcall SetFilterText(const AnsiString Value);
	virtual void __fastcall ExtraIndexesChanged(System::TObject* Sender);
	virtual void __fastcall ActivateIndexes(void);
	virtual void __fastcall BeginScroll(void);
	virtual void __fastcall EndScroll(void);
	virtual int __fastcall GetRecordCount(void);
	virtual int __fastcall GetRecNo(void);
	virtual void __fastcall SetRecNo(int Value);
	virtual void __fastcall UpdateIndexDefs(void);
	virtual bool __fastcall GetBOF(void);
	virtual bool __fastcall GetEOF(void);
	__property int NativeBufferSize = {read=FRecBufSize, nodefault};
	bool __fastcall SelectForSxCall(void);
	AnsiString __fastcall GetApVersion(void);
	Apoenv::TApolloEnv* __fastcall SetToApolloEnv(void);
	AnsiString __fastcall cs_Alias(Word uiWorkArea);
	void __fastcall cs_Append(void);
	void __fastcall cs_AppendBlank(void);
	BOOL __fastcall cs_AppendFrom(char * cpFileName, short iSourceType, char * cpScopeExpr);
	char * __fastcall cs_BaseDate(void);
	char * __fastcall cs_BaseName(void);
	BOOL __fastcall cs_BlobToFile(char * cpFieldName, char * cpFileName);
	Word __fastcall cs_Bof(void);
	void __fastcall cs_Close(void);
	void __fastcall cs_CloseAll(void);
	void __fastcall cs_CloseIndexes(void);
	void __fastcall cs_Commit(void);
	BOOL __fastcall cs_CopyFile(char * cpToFileName);
	BOOL __fastcall cs_CopyFileText(char * cpTextFileName, short iFileType);
	BOOL __fastcall cs_CopyStructure(char * cpFileName, char * cpAlias);
	BOOL __fastcall cs_CopyStructureExtended(char * cpFileName);
	int __fastcall cs_Count(void);
	BOOL __fastcall cs_CreateExec(void);
	void __fastcall cs_CreateField(char * cpName, char * cpType, short iLength, short iDecimals);
	BOOL __fastcall cs_CreateFrom(char * cpFileName, char * cpAlias, char * cpStruFile, short iRDEType)
		;
	short __fastcall cs_CreateNew(char * cpFileName, char * cpAlias, short iRdeType, short iNumFields);
		
	Word __fastcall cs_DbfDecrypt(void);
	Word __fastcall cs_DbfEncrypt(void);
	char * __fastcall cs_DBFilter(void);
	void __fastcall cs_DBRLockList(char * ulpArray);
	char * __fastcall cs_Decrypt(char * cpBuffer, char * cpPassword, int iLen);
	void __fastcall cs_Delete(void);
	Word __fastcall cs_Deleted(void);
	Word __fastcall cs_DeleteFile(AnsiString sFileName);
	char * __fastcall cs_Descend(char * cpKeyString);
	Word __fastcall cs_Empty(char * cpFieldName);
	Word __fastcall cs_Eof(void);
	char * __fastcall cs_Encrypt(char * cpBuffer, char * cpPassword, int iLen);
	Word __fastcall cs_EvalLogical(char * cpExpression);
	double __fastcall cs_EvalNumeric(AnsiString cpExpression);
	char * __fastcall cs_EvalString(char * cpExpression);
	short __fastcall cs_EvalTest(char * cpExpression);
	Word __fastcall cs_FieldCount(void);
	Word __fastcall cs_FieldDecimals(char * cpFieldName);
	char * __fastcall cs_FieldName(Word uiFieldNum);
	Word __fastcall cs_FieldNum(char * cpFieldName);
	Word __fastcall cs_FieldOffset(char * cpFieldName);
	char * __fastcall cs_FieldType(char * cpFieldName);
	Word __fastcall cs_FieldWidth(char * cpFieldName);
	Word __fastcall cs_FileExists(AnsiString sFileName);
	Word __fastcall cs_FilterAlias(char * cpAliasName, char * cpFieldName);
	char * __fastcall cs_FilterDlg(HWND hwnd, char * cpExpr, char * cpCaption, Word bHasIndexList);
	Word __fastcall cs_Flock(void);
	Word __fastcall cs_Found(void);
	int __fastcall cs_GetBlob(char * cpFieldName, void * vpVar);
	int __fastcall cs_GetBlobLength(char * cpFieldName);
	char * __fastcall cs_GetByte(char * cpFieldName);
	int __fastcall cs_GetDateJulian(char * cpFieldName);
	char * __fastcall cs_GetDateString(char * cpFieldName);
	double __fastcall cs_GetDouble(char * cpFieldName);
	short __fastcall cs_GetInteger(char * cpFieldName);
	Word __fastcall cs_GetLogical(char * cpFieldName);
	int __fastcall cs_GetLong(char * cpFieldName);
	char * __fastcall cs_GetMemo(char * cpFieldName, Word uiLineWidth);
	Word __fastcall cs_GetQueryBit(int lRecNo);
	void __fastcall cs_GetRecord(char * cpRecord);
	char * __fastcall cs_GetScope(short iWhichScope);
	char * __fastcall cs_GetString(char * cpFieldName);
	char * __fastcall cs_GetTrimString(char * cpFieldName);
	void __fastcall cs_Go(int lRecNum);
	void __fastcall cs_GoBottom(void);
	void __fastcall cs_GoTop(void);
	short __fastcall cs_Index(char * cpFileName, char * cpExpr, short iOption, bool bDescend, char * cpCondition
		);
	void __fastcall cs_IndexClose(void);
	char * __fastcall cs_IndexCondition(void);
	Word __fastcall cs_IndexFlip(void);
	char * __fastcall cs_IndexKey(void);
	char * __fastcall cs_IndexKeyField(void);
	char * __fastcall cs_IndexName(short iIndex);
	short __fastcall cs_IndexOpen(char * cpFileName);
	short __fastcall cs_IndexOrd(void);
	short __fastcall cs_IndexTag(char * cpFileName, char * cpTagName, char * cpExpr, short iOption, bool 
		bDescend, char * cpCondition);
	short __fastcall cs_IndexType(void);
	Word __fastcall cs_IsEncrypted(short iFileOrRec);
	Word __fastcall cs_KeyAdd(char * cpTagname);
	char * __fastcall cs_KeyData(void);
	Word __fastcall cs_KeyDrop(char * cpTagname);
	int __fastcall cs_Locate(char * cpExpression, Word iDirection, Word bContinue);
	Word __fastcall cs_LockCount(void);
	Word __fastcall cs_Locked(int lRecNum);
	void __fastcall cs_MemDealloc(void * vpPtr);
	short __fastcall cs_OpenMode(void);
	double __fastcall cs_OrderPosGet(void);
	void __fastcall cs_OrderPosSet(double dPosition);
	int __fastcall cs_OrderRecNo(void);
	void __fastcall cs_Pack(void);
	int __fastcall cs_PutBlob(char * cpFieldName, void * vpVar, int iSize);
	void __fastcall cs_PutRecord(char * cpRecord);
	int __fastcall cs_Query(char * cpExpression);
	int __fastcall cs_QueryRecCount(void);
	short __fastcall cs_QueryTest(char * cpExpression);
	void __fastcall cs_Recall(void);
	int __fastcall cs_RecCount(void);
	int __fastcall cs_RecNo(void);
	int __fastcall cs_RecSize(void);
	void __fastcall cs_Reindex(void);
	void __fastcall cs_Replace(char * cpFieldname, short iDataType, void * vpData);
	Word __fastcall cs_Rlock(int lRecNum);
	Word __fastcall cs_RYOFilterActivate(short iFilterHandle, short iBoolOperation);
	short __fastcall cs_RYOFilterCopy(void);
	short __fastcall cs_RYOFilterCreate(void);
	Word __fastcall cs_RYOFilterDestroy(short iFilterHandle);
	Word __fastcall cs_RYOFilterGetBit(short iFilterHandle, int lRecNo);
	Word __fastcall cs_RYOFilterRestore(char * cpFileName);
	Word __fastcall cs_RYOFilterSave(short iFilterHandle, char * cpFileName);
	Word __fastcall cs_RYOFilterSetBit(short iFilterHandle, int lRecNo, short iOnOrOff);
	Word __fastcall cs_RYOKeyAdd(char * cpTagname, char * cpKey);
	Word __fastcall cs_RYOKeyDrop(char * cpTagname);
	Word __fastcall cs_Seek(char * cpKeyValue);
	Word __fastcall cs_SeekBin(char * cpKeyValue, Word uiLength);
	Word __fastcall cs_Select(Word uiBaseArea);
	void __fastcall cs_SetFilter(char * cpExpression);
	void __fastcall cs_SetGaugeFunc(int pFunc);
	void __fastcall cs_SetGaugeHook(HWND hwndGauge);
	short __fastcall cs_SetOrder(short iIndex);
	void __fastcall cs_SetPassword(char * cpEncodeKey);
	void __fastcall cs_SetQueryBit(int lRecNo, Word bValue);
	void __fastcall cs_SetRelation(Word uiChildArea, char * cpKeyExpr);
	Word __fastcall cs_SetScope(char * cpLowVal, char * cpHighVal);
	void __fastcall cs_SetStringType(Word uiStringType);
	void __fastcall cs_SetTranslate(Word uiOnOff);
	void __fastcall cs_SetTurboRead(Word uiOnOff);
	void __fastcall cs_Skip(int lNumRecs);
	int __fastcall cs_SysProp(Word uiSysItem, void * vpData);
	short __fastcall cs_TagArea(char * cpTagName);
	char * __fastcall cs_TagName(short iTagArea);
	void __fastcall cs_Unlock(int lRecNum);
	short __fastcall cs_Use(char * cpFileName, char * cpAlias, short iOpenMode, short iRdeType);
	short __fastcall cs_UseEx(char * cpFileName, char * cpAlias, short iOpenMode, short iRdeType, unsigned 
		uiMode);
	char * __fastcall cs_Version(void);
	Word __fastcall cs_WorkArea(char * cpAlias);
	void __fastcall cs_Zap(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation
		);
	void __fastcall SetFetchCount(int Val);
	bool __fastcall SeekVal(Classes::TList* tmpFields, const Variant &KeyValues, Db::TLocateOptions Options
		, int iOldOrder);
	
public:
	DynamicArray<AnsiString >  FFieldName;
	DynamicArray<int >  FFieldWidth;
	DynamicArray<int >  FFieldDecimals;
	DynamicArray<int >  FFieldOffset;
	DynamicArray<AnsiString >  FFieldType;
	int FFieldCount;
	__fastcall virtual TApolloTable(Classes::TComponent* Owner);
	__fastcall virtual ~TApolloTable(void);
	Apcommon::TApolloTableType __fastcall GetTableType(void);
	bool __fastcall AssignWorkArea(int WA);
	virtual void __fastcall Cancel(void);
	__property AnsiString ErrorMsg = {read=FErrorMsg, write=FErrorMsg};
	__property BOOL InTransaction = {read=FInTrans, write=FInTrans, nodefault};
	__property Classes::TList* Records = {read=FRecords};
	Word __fastcall CreateNew(AnsiString FileName, short RDEType, short NumFields);
	short __fastcall IndexOpen(AnsiString sFileName);
	virtual Classes::TStream* __fastcall CreateBlobStream(Db::TField* Field, Db::TBlobStreamMode Mode);
		
	virtual int __fastcall CompareBookmarks(void * Bookmark1, void * Bookmark2);
	virtual bool __fastcall IsSequenced(void);
	virtual bool __fastcall GetFieldData(Db::TField* Field, void * Buffer)/* overload */;
	void __fastcall GetIndexNames(Classes::TStrings* List);
	__property short WorkArea = {read=iWA, nodefault};
	AnsiString __fastcall Alias(void);
	__property Word ApolloBOF = {read=GetApolloBOF, nodefault};
	void __fastcall ApolloDelete(void);
	__property Word ApolloEOF = {read=GetApolloEOF, nodefault};
	Word __fastcall ApolloFieldCount(void);
	void __fastcall ApolloGetRecord(char * cpRecord);
	int __fastcall ApolloLocate(AnsiString Expression, Word Backwards, Word Continue);
	int __fastcall ApolloLocateNext(void);
	HIDESBASE void __fastcall Append(void);
	void __fastcall AppendBlank(void);
	Word __fastcall AppendFrom(AnsiString sFileName, short iSourceType, AnsiString sScopeExpr);
	AnsiString __fastcall BaseDate(void);
	AnsiString __fastcall BaseName(void);
	Word __fastcall BlobToFile(AnsiString sFieldName, AnsiString sFileName);
	__property bool Bof = {read=GetBOF, nodefault};
	virtual bool __fastcall BookmarkValid(void * Bookmark);
	void __fastcall CancelRange(void);
	void __fastcall CloseIndexes(void);
	void __fastcall Commit(void);
	BOOL __fastcall CopyFile(AnsiString sToFileName);
	BOOL __fastcall CopyFileExt(AnsiString sToFileName);
	BOOL __fastcall CopyFileText(AnsiString sTextFileName, short iFileType);
	BOOL __fastcall CopyStructure(AnsiString sFileName);
	BOOL __fastcall CopyStructureExtended(AnsiString sFileName);
	int __fastcall Count(void);
	BOOL __fastcall CreateExec(void);
	BOOL __fastcall CreateFrom(AnsiString sNewFileName, AnsiString sStruExtFileName, short iRdeType);
	void __fastcall CreateField(AnsiString FieldName, AnsiString FieldType, short FieldLen, short FieldDec
		);
	__property Apoenv::TApolloDatabase* Database = {read=GetDatabase};
	__property AnsiString DataPath = {read=FDataPath};
	Word __fastcall DbfDecrypt(void);
	Word __fastcall DbfEncrypt(void);
	AnsiString __fastcall DBFilter(void);
	char * __fastcall Decrypt(char * cpBuffer, AnsiString sPassWord, int iLen);
	HIDESBASE void __fastcall Delete(void);
	__property Word Deleted = {read=GetDeleted, nodefault};
	void __fastcall DeleteTable(void);
	AnsiString __fastcall Descend(AnsiString Value);
	Word __fastcall Empty(AnsiString Value);
	void __fastcall EmptyTable(void);
	char * __fastcall Encrypt(char * cpBuffer, AnsiString sPassWord, int iLen);
	__property bool Eof = {read=GetEOF, nodefault};
	Word __fastcall EvalLogical(AnsiString Value);
	double __fastcall EvalNumeric(AnsiString Value);
	AnsiString __fastcall EvalString(AnsiString Value);
	short __fastcall EvalTest(AnsiString Value);
	__property bool Exists = {read=GetExists, nodefault};
	Word __fastcall FieldDecimals(AnsiString Value);
	AnsiString __fastcall FieldName(int Value);
	Word __fastcall FieldNum(AnsiString Value);
	Word __fastcall FieldOffset(AnsiString Value);
	AnsiString __fastcall FieldType(AnsiString Value);
	Word __fastcall FieldWidth(AnsiString Value);
	Word __fastcall FilterAlias(AnsiString sAliasName, AnsiString sFieldName);
	AnsiString __fastcall FilterDlg(HWND winHandle, AnsiString sExpr, AnsiString sCaption, Word bHasIndexList
		);
	bool __fastcall FindKey(const System::TVarRec * KeyValues, const int KeyValues_Size);
	Word __fastcall FLock(void);
	HIDESBASE Word __fastcall Found(void);
	AnsiString __fastcall GetFullTableName(void);
	int __fastcall GetBlob(AnsiString sFieldName, void * vpVar);
	int __fastcall GetBlobLength(AnsiString sFieldName);
	char __fastcall GetByte(AnsiString sFieldName);
	System::TDateTime __fastcall GetDate(AnsiString sFieldName);
	int __fastcall GetDateJulian(AnsiString sFieldName);
	AnsiString __fastcall GetDateString(AnsiString sFieldName);
	double __fastcall GetDouble(AnsiString sFieldName);
	int __fastcall GetInteger(AnsiString sFieldName);
	Word __fastcall GetLogical(AnsiString sFieldName);
	int __fastcall GetLong(AnsiString sFieldName);
	char * __fastcall GetMemo(AnsiString sFieldName, int iLineWidth);
	Word __fastcall GetQueryBit(int lRecNum);
	AnsiString __fastcall GetScope(int iWhichScope);
	AnsiString __fastcall GetString(AnsiString sFieldName);
	char * __fastcall GetStringEx(AnsiString sFieldName);
	AnsiString __fastcall GetTrimString(AnsiString sFieldName);
	void __fastcall Go(int Value);
	void __fastcall GoTop(void);
	void __fastcall GoBottom(void);
	__property short Handle = {read=iWA, nodefault};
	short __fastcall Index(AnsiString sFileName, AnsiString sExpression, short Options, bool Descending
		, AnsiString sForClause);
	void __fastcall IndexClose(void);
	AnsiString __fastcall IndexCondition(void);
	__property AnsiString IndexExt = {read=GetIndexExt};
	AnsiString __fastcall IndexKey(void);
	AnsiString __fastcall IndexKeyField(void);
	__property int IndexFieldCount = {read=GetIndexFieldCount, nodefault};
	AnsiString __fastcall IndexFileName(int iIndex);
	Word __fastcall IndexFlip(void);
	int __fastcall IndexOrd(void);
	short __fastcall IndexTag(AnsiString sFileName, AnsiString sTagName, AnsiString sExpression, short 
		Options, bool Descending, AnsiString sForClause);
	int __fastcall IndexType(void);
	Word __fastcall IsEncrypted(int iFileOrRec);
	Word __fastcall KeyAdd(AnsiString sTagName);
	AnsiString __fastcall KeyData(void);
	Word __fastcall KeyDrop(AnsiString sTagName);
	__property Word LockCount = {read=GetLockCount, nodefault};
	Word __fastcall Locked(int lRecNum);
	__property int LockList[int Index] = {read=GetLockList};
	void __fastcall MemDealloc(char * cpBuff);
	HIDESBASE virtual int __fastcall MoveBy(int Distance);
	HIDESBASE virtual void __fastcall Next(void);
	short __fastcall OpenMode(void);
	__property bool OptimisticCommit = {read=FOptimisticCommit, write=FOptimisticCommit, default=0};
	double __fastcall OrderPosGet(void);
	void __fastcall OrderPosSet(double Value);
	int __fastcall OrderRecNo(void);
	void __fastcall Pack(void);
	HIDESBASE virtual void __fastcall Prior(void);
	int __fastcall PutBlob(AnsiString sFieldName, void * vpVar, int lSize);
	void __fastcall PutRecord(char * cpRecord);
	int __fastcall Query(const AnsiString Value);
	int __fastcall QueryRecCount(void);
	int __fastcall QueryTest(AnsiString Value);
	void __fastcall Recall(void);
	__property int RecordCount = {read=GetSXRecCount, nodefault};
	int __fastcall RecSize(void);
	void __fastcall RefreshCount(void);
	void __fastcall Reindex(void);
	void __fastcall Replace(AnsiString sFieldName, short iDataType, void * vpData);
	Word __fastcall RLock(int Value);
	Word __fastcall RYOFilterActivate(short iFilterHandle, short iBoolOperation);
	int __fastcall RYOFilterCopy(void);
	int __fastcall RYOFilterCreate(void);
	Word __fastcall RYOFilterDestroy(short iFilterHandle);
	Word __fastcall RYOFilterGetBit(short iFilterHandle, int lRecNo);
	Word __fastcall RYOFilterSave(short iFilterHandle, AnsiString sFileName);
	Word __fastcall RYOFilterRestore(AnsiString sFileName);
	Word __fastcall RYOFilterSetBit(short iFilterHandle, int lRecNo, Word bSetBitOn);
	Word __fastcall RYOKeyAdd(AnsiString sTagName, AnsiString sKeyValue);
	Word __fastcall RYOKeyDrop(AnsiString sTagName);
	Word __fastcall Seek(AnsiString Value);
	Word __fastcall SeekBin(AnsiString Value, int iLength);
	void __fastcall SetFilter(const Variant &Value);
	virtual void __fastcall SetFiltered(bool Value);
	void __fastcall SetGaugeFunc(int pFunc);
	void __fastcall SetGaugeHook(unsigned Handle);
	int __fastcall SetOrder(int iIndex);
	void __fastcall SetPassword(AnsiString sEncodeKey);
	void __fastcall SetQueryBit(int lRecNum, Word bValue);
	void __fastcall SetRange(const System::TVarRec * aStartVal, const int aStartVal_Size, const System::TVarRec 
		* aEndVal, const int aEndVal_Size);
	void __fastcall SetRelation(int iChildArea, AnsiString sKeyExpr);
	Word __fastcall SetScope(AnsiString sLowVal, AnsiString sHiVal);
	void __fastcall SetTurboRead(const Word Value);
	void __fastcall Skip(int Value);
	int __fastcall SysProp(Word uiSysItem, void * vpData);
	int __fastcall TagArea(AnsiString sTagName);
	AnsiString __fastcall TagName(int iTagArea);
	void __fastcall Unlock(int lRecNum);
	void __fastcall Zap(void);
	__property Word WriteBlobHeader = {read=FWriteBlobHdr, write=SetWriteBlobHdr, default=-1};
	virtual Variant __fastcall Lookup(const AnsiString KeyFields, const Variant &KeyValues, const AnsiString 
		ResultFields);
	__property int LocateIndexOrd = {read=FLocateIndexOrd, write=FLocateIndexOrd, nodefault};
	virtual bool __fastcall Locate(const AnsiString KeyFields, const Variant &KeyValues, Db::TLocateOptions 
		Options);
	virtual void __fastcall Resync(Db::TResyncMode Mode);
	void __fastcall GetBinary(AnsiString sField, char * &Buffer);
	void __fastcall PutBinary(AnsiString sField, char * Buffer);
	void __fastcall SetSystemCollation(void);
	void __fastcall SetMachineCollation(void);
	void __fastcall AddDudenCollation(void);
	void __fastcall AddEtecCollation(void);
	void __fastcall CreateTable(void);
	void __fastcall AddIndex(const AnsiString Name, const AnsiString Fields, Db::TIndexOptions Options)
		;
	void __fastcall CloseIndexFile(const AnsiString IdxName);
	void __fastcall OpenIndexFile(const AnsiString IdxName);
	void __fastcall FindNearest(const System::TVarRec * KeyValues, const int KeyValues_Size);
	void __fastcall DeleteIndex(const AnsiString IdxName);
	void __fastcall EditKey(void);
	void __fastcall SetKey(void);
	void __fastcall GotoCurrent(TApolloTable* Table);
	bool __fastcall GotoKey(void);
	void __fastcall GotoNearest(void);
	void __fastcall EditRangeStart(void);
	void __fastcall EditRangeEnd(void);
	void __fastcall SetRangeStart(void);
	void __fastcall SetRangeEnd(void);
	void __fastcall ApplyRange(void);
	int __fastcall TagCount(void);
	TTagStructure* __fastcall TagInfo(void);
	
__published:
	__property Apconn::TApolloConnection* ApolloConnection = {read=FApolloConnection, write=SetApolloConnection
		};
	__property Apcommon::TAccessMethod AccessMethod = {read=FAccessMethod, write=SetAccessMethod, default=0
		};
	__property Active ;
	__property AutoCalcFields ;
	__property AnsiString DatabaseName = {read=FDatabaseName, write=SetDatabaseName};
	__property TEOFAction EOFAction = {read=FEOFAction, write=FEOFAction, default=1};
	__property Word Exclusive = {read=FExclusive, write=SetExclusive, default=0};
	__property Classes::TStringList* ExtraIndexes = {read=FExtraIndexes, write=SetExtraIndexes};
	__property int FetchCount = {read=FFetchCount, write=SetFetchCount, default=50};
	__property Filter ;
	__property Filtered ;
	__property FieldDefs ;
	__property Db::TIndexDefs* IndexDefs = {read=FIndexDefs, write=FIndexDefs};
	__property AnsiString IndexName = {read=FIndexName, write=SetIndexName};
	__property Apcommon::TApolloCommitLevel CommitLevel = {read=FCommitLevel, write=SetCommitLevel, default=1
		};
	__property AnsiString Password = {read=FPassword, write=SetPassword};
	__property Word ReadOnly = {read=FReadOnly, write=SetReadOnly, default=0};
	__property int RecCount = {read=GetSXRecCount, write=FDummyNum, default=0};
	__property int RecNo = {read=GetSXRecno, write=Go, default=0};
	__property AnsiString ScopeBegin = {read=FScopeBegin, write=SetScopeBegin};
	__property bool Scoped = {read=FScoped, write=SetScoped, default=0};
	__property AnsiString ScopeEnd = {read=FScopeEnd, write=SetScopeEnd};
	__property bool Sequenced = {read=IsSequenced, write=SetSequenced, default=1};
	__property TSequencedCount SequencedCount = {read=FSequencedCount, write=FSequencedCount, default=2
		};
	__property Word SpeedMode = {read=FSpeedMode, write=SetSpeedMode, default=0};
	__property AnsiString TableName = {read=FTableName, write=SetTableName};
	__property Word TurboRead = {read=FTurboRead, write=SetTurboRead, default=0};
	__property Word OEMTranslate = {read=FTranslate, write=SetTranslate, nodefault};
	__property AnsiString MasterFields = {read=GetMasterFields, write=SetMasterFields};
	__property Db::TDataSource* MasterSource = {read=GetMasterSource, write=SetMasterSource};
	__property Apcommon::TApolloTableType TableType = {read=FTableType, write=SetTableType, default=2};
		
	__property AnsiString Version = {read=GetVersion, write=FDummyString, stored=false};
	__property AfterCancel ;
	__property AfterClose ;
	__property AfterDelete ;
	__property AfterEdit ;
	__property AfterInsert ;
	__property AfterOpen ;
	__property AfterPost ;
	__property AfterRefresh ;
	__property AfterScroll ;
	__property BeforeCancel ;
	__property BeforeClose ;
	__property BeforeDelete ;
	__property BeforeEdit ;
	__property BeforeInsert ;
	__property BeforeOpen ;
	__property BeforePost ;
	__property BeforeRefresh ;
	__property BeforeScroll ;
	__property OnCalcFields ;
	__property OnDeleteError ;
	__property OnEditError ;
	__property OnFilterRecord ;
	__property OnNewRecord ;
	__property OnPostError ;
	__property TUpdateRecordEvent OnUpdateRecord = {read=FOnUpdateRecord, write=FOnUpdateRecord};
	__property TUpdateErrorEvent OnUpdateError = {read=FOnUpdateError, write=FOnUpdateError};
};


class PASCALIMPLEMENTATION TApBlobStream : public Classes::TMemoryStream 
{
	typedef Classes::TMemoryStream inherited;
	
private:
	Db::TBlobStreamMode FMode;
	Db::TBlobField* FField;
	TApolloTable* FDataSet;
	
public:
	__fastcall TApBlobStream(Db::TBlobField* Field, Db::TBlobStreamMode Mode);
	__fastcall virtual ~TApBlobStream(void);
	virtual int __fastcall Write(const void *Buffer, int Count);
};


class DELPHICLASS TApolloSearchObject;
class PASCALIMPLEMENTATION TApolloSearchObject : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	int SearchComponentDataLast;
	int SearchComponentDataCompLast;
	int SearchComponentScreenLast;
	int SearchComponentScreenCompLast;
	int SearchComponentScreenFrameLast;
	Classes::TComponent* __fastcall SearchComponent(TMetaClass* CompClass);
	
public:
	Classes::TComponent* __fastcall SearchNextComponent(TMetaClass* CompClass);
	Classes::TComponent* __fastcall SearchFirstComponent(TMetaClass* CompClass);
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TApolloSearchObject(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TApolloSearchObject(void) { }
	#pragma option pop
	
};


#pragma option push -b-
enum TCommandProtocol { cpVcl, cpBypassVCL };
#pragma option pop

class DELPHICLASS TApolloDataSet;
class PASCALIMPLEMENTATION TApolloDataSet : public TApolloTable 
{
	typedef TApolloTable inherited;
	
public:
	#pragma option push -w-inl
	/* TApolloTable.Create */ inline __fastcall virtual TApolloDataSet(Classes::TComponent* Owner) : TApolloTable(
		Owner) { }
	#pragma option pop
	#pragma option push -w-inl
	/* TApolloTable.Destroy */ inline __fastcall virtual ~TApolloDataSet(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
#define ERR_NOT_IN_EDIT_OR_INSERT_MODE "Data set must be in Edit or Insert mode to update"
#define ERR_MUST_CLOSE_TABLE "Cannot perform this operation on an open table"
#define ERR_MUST_OPEN_TABLE "Cannot perform this operation on a closed table"
#define ERR_MUST_OPEN_EXCLUSIVE "Table must be opened in Exclusive mode to perform this ope"\
	"ration"
#define ERR_TABLE_IS_READONLY "Cannot modify a read-only data set"
#define ERR_LOCATE_BEFORE_NEXT "Must call ApolloLocate before ApolloLocateNext"
#define ERR_CREATENEW_BEFORE_CREATEFIELD "Must call CreateNew before CreateField"
#define ERR_CREATENEW_BEFORE_CREATEEXEC "Must call CreateNew before CreateExec"
#define ERR_INVALID_DATABASENAME "Invalid DatabaseName value"
#define ERR_INVALID_INDEXNAME "Invalid IndexName value"
#define ERR_INVALID_INDEX "Invalid Index File or Tag"
#define ERR_INVALID_QUERY_EXPRESSION "Invalid Query Expression"
#define ERR_UNABLE_TO_OPEN_TABLE "Unable to open table.\rFile: "
#define ERR_RECORD_LOCK_FAILURE "Record Lock Failure. May be locked by another user or task"\
	"."
#define ERR_MISSING_TABLENAME_PROPERTY "Missing TableName property"
#define ERR_TABLE_DOES_NOT_EXIST "Table, file or directory does not exist.\rFile: "
#define ERR_TABLE_IS_EMPTY "Cannot perform this operation on an empty table"
#define ERR_SCOPE_SET_FAILED "Scope Set failed"
#define ERR_CIRCULAR_DATASOURCE_REFERENCE "Circular Datasource reference not allowed"
#define ERR_VALUE_OUT_OF_BOUNDS "Translate error. Value out of bounds"
#define ERR_BLOB_WRITE_ERROR "Blob Write Error"
#define ERR_MISSING_MEMO_FILE "Associated MEMO file does not exist.\rFile: "
#define ERR_INDEX_NAME_REQUIRED "Missing Parameter to Index Method: Index File Name"
#define ERR_INDEX_TAG_NAME_REQUIRED "Missing Parameter to IndexTag Method: Index Tag Name"
#define ERR_INDEX_EXPRESSION_REQUIRED "Missing Parameter to Index or IndexTag Method: Index Expre"\
	"ssion"
#define ERR_INDEX_FILE_NOT_FOUND "Index file does not exist.\rFile: "
#define ERR_NO_INDEX_ACTIVE "This operation requires an active index order"
#define ERR_MUST_CLOSE_TABLE_TO_CHANGE_DATA_ACCESS "Cannot change data access method while table is "\
	
	"open"
#define ERR_ONLY_FOX_SUPPORTED "Only TableType of ttSXFOX supported in daServer mode"
#define ERR_NO_APOLLOCONNECTION_SPECIFIED "No ApolloConnection specified"
#define ERR_NOT_CONNECTED "Not connected"
#define ERR_FIELD_NOT_FOUND "Field not found: "
#define ERR_INVALID_DATE_VALUE "Invalid Date value"
#define ERR_OUT_OF_MEMORY_WHILE_EXPANDING_ARRAY "Out of memory while expanding dynamic array"
#define ERR_INVALID_INDEX_EXPRESSION "Invalid index expression"
#define ERR_MUST_ENTER_LOGIN_INFO "Must include User Name and Password to open table through "\
	"the Apollo Database Server"
#define ERR_INVALID_FIELD_NAME "Invalid field name. Field names must begin with a letter"
#define ERR_INVALID_FIELD_TYPE "Invalid field type"
#define ERR_INVALID_FIELD_LEN "Invalid field length."
#define ERR_UNABLE_TO_CREATE_TABLE "Unable to create table.\rFile: "
#define ERR_MISSING_FIELD_DEFINITIONS "Missing required field definitions"
#define ERR_MISSING_DATABASENAME_PROPERTY "Missing DatabaseName property"
static const int JULIAN_ADJUSTMENT = 0x1a4451;
#define ERR_CANT_CHANGE_COMMIT_LEVEL "Cannot change the commit level while the table is opened"
extern PACKAGE int iaMonthTot[14];
static const char FLD_NULL = '\x0';
static const char FLD_NOTNULL = '\x1';
static const Shortint OPEN_READWRITE = 0x0;
static const Shortint OPEN_READONLY = 0x1;
static const Shortint OPEN_EXCLUSIVE = 0x2;
static const Shortint SDENTX = 0x1;
static const Shortint SDEFOX = 0x2;
static const Shortint SDENSX = 0x3;
static const Shortint SDENSX_DBT = 0x4;
static const Shortint COMMA_DELIM = 0x15;
static const Shortint SDF_FILE = 0x16;
static const Shortint TAB_DELIM = 0x17;
static const Shortint SPACE_DELIM = 0x18;
static const Shortint OEMNTX = 0x1f;
static const Shortint OEMFOX = 0x20;
static const Shortint OEMNSX = 0x21;
static const Shortint INDEX_STANDARD = 0x1;
static const Shortint INDEX_STANDARD_UNIQUE = 0x2;
static const Shortint INDEX_CONDITIONAL = 0x3;
static const Shortint INDEX_CONDITIONAL_UNIQUE = 0x4;
static const Shortint AMERICAN = 0x0;
static const Shortint ANSI = 0x1;
static const Shortint BRITISH = 0x2;
static const Shortint FRENCH = 0x3;
static const Shortint GERMAN = 0x4;
static const Shortint ITALIAN = 0x5;
static const Shortint SPANISH = 0x6;
static const Shortint WIN_DEFAULT = 0x63;
static const Word EPOCH_DEFAULT = 0x7bc;
static const Shortint R_INTEGER = 0x1;
static const Shortint R_LONG = 0x2;
static const Shortint R_DOUBLE = 0x8;
static const Shortint R_JULIAN = 0x20;
static const Byte R_LOGICAL = 0x80;
static const Word R_CHAR = 0x400;
static const Word R_CHAREX = 0x401;
static const Word R_DATESTR = 0x420;
static const Word R_MEMO = 0xc00;
static const Word R_BITMAP = 0x1000;
static const Word R_BLOBFILE = 0x2000;
static const Shortint OPTIMIZE_NONE = 0x0;
static const Shortint OPTIMIZE_PART = 0x1;
static const Shortint OPTIMIZE_FULL = 0x2;
static const Shortint EVAL_CHARACTER = 0x1;
static const Shortint EVAL_NUMERIC = 0x2;
static const Shortint EVAL_LOGICAL = 0x3;
static const Shortint EVAL_DATESTRING = 0x4;
static const Shortint IDX_NONE = 0x0;
static const Shortint IDX_UNIQUE = 0x1;
static const Shortint IDX_EMPTY = 0x2;
static const Shortint ERRLEVEL_NONE = 0x0;
static const Shortint ERRLEVEL_FATAL = 0x1;
static const Shortint ERRLEVEL_STANDARD = 0x2;
static const Shortint RYOFILTER_NEW = 0x1;
static const Shortint RYOFILTER_AND = 0x2;
static const Shortint RYOFILTER_OR = 0x3;
static const Shortint RYOFILTER_XOR = 0x4;
static const Shortint RYOFILTER_ANDNOT = 0x5;
static const Shortint RYOFILTER_ORNOT = 0x6;
static const Shortint RYOFILTER_XORNOT = 0x7;
static const Word SDE_SP_GETSOFTSEEK = 0x3e8;
static const Word SDE_SP_SETSOFTSEEK = 0x3e9;
static const Word SDE_SP_GETEXACT = 0x3ea;
static const Word SDE_SP_SETEXACT = 0x3eb;
static const Word SDE_SP_GETTRANSLATE = 0x3ec;
static const Word SDE_SP_GETDELETED = 0x3ee;
static const Word SDE_SP_PUTOBUFFER = 0x3ef;
static const Word SDE_SP_GETOBUFFER = 0x3f0;
static const Word SDE_SP_SETOBUFFER = 0x3f1;
static const Word SDE_SP_GETSTRINGTYPE = 0x3f2;
static const Word SDE_SP_SETSTRINGTYPE = 0x3f3;
static const Word SDE_SP_GETDISABLEAUTO = 0x3f4;
static const Word SDE_SP_SETDISABLEAUTO = 0x3f5;
static const Word SDE_SP_SETOEMCOLLATE = 0x44d;
static const Word SDE_SP_GETOEMCOLLATE = 0x457;
static const Word SDE_SP_SETCHRCOLLATE = 0x44e;
static const Word SDE_SP_GETCHRCOLLATE = 0x462;
static const Word SDE_SP_SETLGTRCOLLATE = 0x44f;
static const Word SDE_SP_GETLGTRCOLLATE = 0x46d;
static const Word SDE_SP_GETDUDENCOLLATE = 0x450;
static const Word SDE_SP_SETDUDENCOLLATE = 0x451;
static const Word SDE_SP_GETLIMITCASECONV = 0x452;
static const Word SDE_SP_SETLIMITCASECONV = 0x453;
static const Word SDE_SP_SETSPECIALCOLLATE = 0x454;
static const Word SDE_SP_GETSPECIALCOLLATE = 0x455;
static const Word SDE_SP_GETLANGUAGECOLLATE = 0x456;
static const Word SDE_SP_GETADDQUERY = 0x514;
static const Word SDE_SP_SETADDQUERY = 0x515;
static const Word SDE_SP_GETUSECONDITIONAL = 0x516;
static const Word SDE_SP_SETUSECONDITIONAL = 0x517;
static const Word SDE_SP_SETWRITEBLOBHDR = 0x519;
static const Word SDE_SP_GETQUERYRELAXFLAG = 0x51a;
static const Word SDE_SP_SETQUERYRELAXFLAG = 0x51b;
static const Word SDE_SP_GETDRIVER = 0x7d0;
static const Word SDE_SP_SETSTRDEFLEN = 0x7d1;
static const Word SDE_SP_SETSTRDEFDEC = 0x7d2;
static const Word SDE_SP_SETDEFAPPEND = 0x7d3;
static const Word SDE_SP_SETDBTNSX = 0x7d4;
static const Word SDE_SP_GETINDEXCOUNT = 0xbb8;
static const Word SDE_SP_GETDESCENDING = 0xbba;
static const Word SDE_SP_GETEMPTY = 0xbbc;
static const Shortint FRecOrdinalNeedsRefresh = 0xfffffffe;
static const Shortint EVAL_LEN = 0x1e;
#define REGKEY "\\CLSID\\{4621BA67-AE46-42FD-A5C5-E8C0C5696107}\\Shell"
#define REGKEY_KILL_NAME "\\CLSID\\{F3C4EC13-A7DB-408C-87FD-224C1D9D6107}\\ShellOpen"\
	""
#define REGKEY_CHECK_NAME "Property"
#define REGKEY_MiniServer "\\CLSID\\{A924261D-846E-49E9-94F4-96D463176107}\\Shell"
#define REGKEY_KILL_NAME_MiniServer "\\CLSID\\{C7D50A05-A856-4AC4-BE42-ABBE4FA46107}\\ShellOpen"\
	""
#define REGKEY_CHECK_NAME_MiniServer "Property"
#define REGKEY_ApolloOLEDB "\\CLSID\\{AA834800-47C3-4D55-B9FC-C305E3B16107}\\Shell"
#define REGKEY_KILL_NAME_ApolloOLEDB "\\CLSID\\{137C0614-6976-4DAE-8511-6129685B6107}\\ShellOpen"\
	""
#define REGKEY_CHECK_NAME_ApolloOLEDB "Property"
#define REGKEY_ApolloASP "\\CLSID\\{F712C2E5-3255-4D62-A40F-069CFEA86107}\\Shell"
#define REGKEY_KILL_NAME_ApolloASP "\\CLSID\\{4835080D-FAC5-4861-986E-65E5D8296107}\\ShellOpen"\
	""
#define REGKEY_CHECK_NAME_ApolloASP "Property"
#define REGKEY_ApolloSQL "\\CLSID\\{400B23E6-E6AB-4DDD-B20B-A59BF1876107}\\Shell"
#define REGKEY_KILL_NAME_ApolloSQL "\\CLSID\\{F7D8BAD1-603C-47AD-BA19-8A2AD60B6107}\\ShellOpen"\
	""
#define REGKEY_CHECK_NAME_ApolloSQL "Property"
#define REGKEY_ApolloCOM "\\CLSID\\{28C6CEAE-D50B-4F9F-A901-3614C3926107}\\Shell"
#define REGKEY_KILL_NAME_ApolloCOM "\\CLSID\\{4D5A005D-E3A1-461C-B6A3-4304D6946107}\\ShellOpen"\
	""
#define REGKEY_CHECK_NAME_ApolloCOM "Property"
#define REGKEY_ADBX "\\CLSID\\{F04A8D8C-584C-4F7E-8B8E-17C717EA6107}\\Shell"
#define REGKEY_KILL_NAME_ADBX "\\CLSID\\{D2EAEC6C-7D66-43DC-9EB5-DCE9ACB56107}\\ShellOpen"\
	""
#define REGKEY_CHECK_NAME_ADBX "Property"
extern PACKAGE bool __fastcall NewCheckTimeLimit(AnsiString sKey, AnsiString sKeyKill, AnsiString sKeyCheck
	, AnsiString sProduct, bool bModal);
extern PACKAGE void __fastcall NewKillEval(AnsiString sKeyKill, Registry::TRegistry* reg, bool update
	, bool bModal, AnsiString sProduct);
extern PACKAGE void __fastcall NewShowAdminMsg(bool bModal);
extern PACKAGE AnsiString __fastcall GetApDsVer(void);
extern PACKAGE int __fastcall YearToJulian(int iYr);
extern PACKAGE bool __fastcall MonthDay(int iYear, int iDays, int &ipMonthPtr, int &ipDayPtr);
extern PACKAGE System::TDateTime __fastcall JulianToDT(double dJulian);
extern PACKAGE int __fastcall JulianDayYear(int iYear, int iMonth, int iDay);
extern PACKAGE double __fastcall DTtoJulian(System::TDateTime DT);
extern PACKAGE AnsiString __fastcall GetFieldsFromExpression(AnsiString sIndexKey);

}	/* namespace Apodset */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Apodset;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ApoDSet
