// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'IntCrypt.pas' rev: 5.00

#ifndef IntCryptHPP
#define IntCryptHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Db.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Intcrypt
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
#define DLL_NAME "ApolloCrypt.DLL"
extern PACKAGE bool CryptDLLLoaded;
extern PACKAGE void __stdcall (*CompressStream)(Classes::TMemoryStream* InStrm, Classes::TMemoryStream* 
	OutStrm);
extern PACKAGE void __stdcall (*UnCompressStream)(Classes::TMemoryStream* InStrm, Classes::TMemoryStream* 
	OutStrm);
extern PACKAGE void __stdcall (*SetCompressionPassword)(char * pPass);
extern PACKAGE void __stdcall (*SetCompressionLevel)(int iLevel);
extern PACKAGE void __fastcall UnLoadCryptDLL(void);
extern PACKAGE void __fastcall LoadCryptDLL(void);

}	/* namespace Intcrypt */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Intcrypt;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// IntCrypt
