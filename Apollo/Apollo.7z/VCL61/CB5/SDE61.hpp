// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'SDE61.pas' rev: 5.00

#ifndef SDE61HPP
#define SDE61HPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Dialogs.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Windows.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Sde61
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TSDEEngine;
class PASCALIMPLEMENTATION TSDEEngine : public System::TObject 
{
	typedef System::TObject inherited;
	
private:
	bool m_bIsLoaded;
	int m_iDllHandle;
	
public:
	__fastcall TSDEEngine(void);
	__fastcall virtual ~TSDEEngine(void);
	bool __stdcall LoadDLLs(void);
	void __fastcall FreeDLLs(void);
	void __fastcall SetSystemCollation(void);
	void __fastcall SetMachineCollation(void);
	void __fastcall AddDudenCollation(void);
	void __fastcall AddEtecCollation(void);
	char * __stdcall GetSystemLocale(void);
	char * __stdcall ViewSystemCharOrder(void);
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE TSDEEngine* SDEEngine;
extern PACKAGE bool DLLLoaded;
extern PACKAGE void __stdcall (*sx_AddDudenCollation)(void);
extern PACKAGE void __stdcall (*sx_AddEtecCollation)(void);
extern PACKAGE char * __stdcall (*sx_Alias)(Word uiWorkArea);
extern PACKAGE void __stdcall (*sx_Append)(void);
extern PACKAGE void __stdcall (*sx_AppendBlank)(void);
extern PACKAGE short __stdcall (*sx_AppendBlankEx)(void);
extern PACKAGE short __stdcall (*sx_AppendEx)(void);
extern PACKAGE BOOL __stdcall (*sx_AppendFrom)(char * cpFileName, short iSourceType, char * cpScopeExpr
	);
extern PACKAGE char * __stdcall (*sx_BaseDate)(void);
extern PACKAGE char * __stdcall (*sx_BaseName)(void);
extern PACKAGE BOOL __stdcall (*sx_BlobToFile)(char * cpFieldName, char * cpFileName);
extern PACKAGE BOOL __stdcall (*sx_Bof)(void);
extern PACKAGE void __stdcall (*sx_Close)(void);
extern PACKAGE void __stdcall (*sx_CloseAll)(void);
extern PACKAGE void __stdcall (*sx_CloseIndexes)(void);
extern PACKAGE void __stdcall (*sx_Commit)(void);
extern PACKAGE int __stdcall (*sx_CommitLevel)(int nNewLevel);
extern PACKAGE BOOL __stdcall (*sx_CopyFile)(char * cpToFileName);
extern PACKAGE BOOL __stdcall (*sx_CopyFileText)(char * cpTextFileName, short iFileType);
extern PACKAGE BOOL __stdcall (*sx_CopyStructure)(char * cpFileName, char * cpAlias);
extern PACKAGE BOOL __stdcall (*sx_CopyStructureExtended)(char * cpFileName);
extern PACKAGE int __stdcall (*sx_Count)(void);
extern PACKAGE BOOL __stdcall (*sx_CreateExec)(void);
extern PACKAGE void __stdcall (*sx_CreateField)(char * cpName, char * cpType, short iLength, short iDecimals
	);
extern PACKAGE BOOL __stdcall (*sx_CreateFrom)(char * cpFileName, char * cpAlias, char * cpStruFile, 
	short iRDEType);
extern PACKAGE short __stdcall (*sx_CreateNew)(char * cpFileName, char * cpAlias, short iRdeType, short 
	iNumFields);
extern PACKAGE short __stdcall (*sx_CreateNewEx)(char * cpFileName, char * cpAlias, short iRdeType, 
	short iNumFields, unsigned uiMode);
extern PACKAGE BOOL __stdcall (*sx_DbfDecrypt)(void);
extern PACKAGE BOOL __stdcall (*sx_DbfEncrypt)(void);
extern PACKAGE char * __stdcall (*sx_DBFilter)(void);
extern PACKAGE void __stdcall (*sx_DBRlockList)(char * ulpArray);
extern PACKAGE char * __stdcall (*sx_Decrypt)(char * cpBuffer, char * cpPassword, int iLen);
extern PACKAGE void __stdcall (*sx_Delete)(void);
extern PACKAGE BOOL __stdcall (*sx_Deleted)(void);
extern PACKAGE char * __stdcall (*sx_Descend)(char * cpKeyString);
extern PACKAGE BOOL __stdcall (*sx_Empty)(char * cpFieldName);
extern PACKAGE char * __stdcall (*sx_Encrypt)(char * cpBuffer, char * cpPassword, int iLen);
extern PACKAGE BOOL __stdcall (*sx_Eof)(void);
extern PACKAGE short __stdcall (*sx_ErrorLevel)(short iErrorLevel);
extern PACKAGE BOOL __stdcall (*sx_EvalLogical)(char * cpExpression);
extern PACKAGE double __stdcall (*sx_EvalNumeric)(char * cpExpression);
extern PACKAGE char * __stdcall (*sx_EvalString)(char * cpExpression);
extern PACKAGE short __stdcall (*sx_EvalTest)(char * cpExpression);
extern PACKAGE Word __stdcall (*sx_FieldCount)(void);
extern PACKAGE Word __stdcall (*sx_FieldDecimals)(char * cpFieldName);
extern PACKAGE char * __stdcall (*sx_FieldName)(Word uiFieldNum);
extern PACKAGE Word __stdcall (*sx_FieldNum)(char * cpFieldName);
extern PACKAGE Word __stdcall (*sx_FieldOffset)(char * cpFieldName);
extern PACKAGE char * __stdcall (*sx_FieldType)(char * cpFieldName);
extern PACKAGE Word __stdcall (*sx_FieldWidth)(char * cpFieldName);
extern PACKAGE BOOL __stdcall (*sx_FilterAlias)(char * cpAliasName, char * cpFieldName);
extern PACKAGE char * __stdcall (*sx_FilterDlg)(HWND hwnd, char * cpExpr, char * cpCaption, Word bHasIndexList
	);
extern PACKAGE void __stdcall (*sx_FinalizeSession)(void);
extern PACKAGE BOOL __stdcall (*sx_Flock)(void);
extern PACKAGE BOOL __stdcall (*sx_Found)(void);
extern PACKAGE int __stdcall (*sx_GetBlob)(char * cpFieldName, void * vpVar);
extern PACKAGE int __stdcall (*sx_GetBlobLength)(char * cpFieldName);
extern PACKAGE char * __stdcall (*sx_GetByte)(char * cpFieldName);
extern PACKAGE int __stdcall (*sx_GetCommitLevel)(short uiWorkArea);
extern PACKAGE int __fastcall (*sx_GetDateFormat)(void);
extern PACKAGE int __stdcall (*sx_GetDateJulian)(char * cpFieldName);
extern PACKAGE char * __stdcall (*sx_GetDateString)(char * cpFieldName);
extern PACKAGE double __stdcall (*sx_GetDouble)(char * cpFieldName);
extern PACKAGE short __stdcall (*sx_GetInteger)(char * cpFieldName);
extern PACKAGE Word __stdcall (*sx_GetLogical)(char * cpFieldName);
extern PACKAGE int __stdcall (*sx_GetLong)(char * cpFieldName);
extern PACKAGE char * __stdcall (*sx_GetMemo)(char * cpFieldName, Word uiLineWidth);
extern PACKAGE BOOL __stdcall (*sx_GetQueryBit)(int lRecNo);
extern PACKAGE void __stdcall (*sx_GetRecord)(char * cpRecord);
extern PACKAGE char * __stdcall (*sx_GetScope)(short iWhichScope);
extern PACKAGE char * __stdcall (*sx_GetString)(char * cpFieldName);
extern PACKAGE char * __stdcall (*sx_GetSystemCharOrder)(void);
extern PACKAGE char * __stdcall (*sx_GetSystemLocale)(void);
extern PACKAGE char * __stdcall (*sx_GetTrimString)(char * cpFieldName);
extern PACKAGE void __stdcall (*sx_GetUDFPath)(char * cpUDFPath, int lMaxBufLen);
extern PACKAGE char * __stdcall (*sx_GetXML)(void);
extern PACKAGE void __stdcall (*sx_Go)(int lRecNum);
extern PACKAGE void __stdcall (*sx_GoBottom)(void);
extern PACKAGE void __stdcall (*sx_GoTop)(void);
extern PACKAGE short __stdcall (*sx_Index)(char * cpFileName, char * cpExpr, short iOption, BOOL bDescend
	, char * cpCondition);
extern PACKAGE void __stdcall (*sx_IndexClose)(void);
extern PACKAGE char * __stdcall (*sx_IndexCondition)(void);
extern PACKAGE BOOL __stdcall (*sx_IndexFlip)(void);
extern PACKAGE char * __stdcall (*sx_IndexKey)(void);
extern PACKAGE char * __stdcall (*sx_IndexKeyField)(void);
extern PACKAGE char * __stdcall (*sx_IndexName)(short iIndex);
extern PACKAGE short __stdcall (*sx_IndexOpen)(char * cpFileName);
extern PACKAGE short __stdcall (*sx_IndexOrd)(void);
extern PACKAGE short __stdcall (*sx_IndexTag)(char * cpFileName, char * cpTagName, char * cpExpr, short 
	iOption, BOOL bDescend, char * cpCondition);
extern PACKAGE short __stdcall (*sx_IndexType)(void);
extern PACKAGE BOOL __stdcall (*sx_IsEncrypted)(short iFileOrRec);
extern PACKAGE BOOL __stdcall (*sx_IsNull)(char * cpFieldName);
extern PACKAGE BOOL __stdcall (*sx_KeyAdd)(char * cpTagname);
extern PACKAGE char * __stdcall (*sx_KeyData)(void);
extern PACKAGE BOOL __stdcall (*sx_KeyDrop)(char * cpTagname);
extern PACKAGE short __stdcall (*sx_KeyLength)(void);
extern PACKAGE int __stdcall (*sx_Locate)(char * cpExpression, Word iDirection, BOOL bContinue);
extern PACKAGE Word __stdcall (*sx_LockCount)(void);
extern PACKAGE BOOL __stdcall (*sx_Locked)(int lRecNum);
extern PACKAGE char * __stdcall (*sx_MemAlloc)(int lNumberOfBytes);
extern PACKAGE void __stdcall (*sx_MemDealloc)(void * vpPtr);
extern PACKAGE char * __stdcall (*sx_MemRealloc)(void * vpPtr, int lSize);
extern PACKAGE short __stdcall (*sx_OpenMode)(void);
extern PACKAGE double __stdcall (*sx_OrderPosGet)(void);
extern PACKAGE void __stdcall (*sx_OrderPosSet)(double dPosition);
extern PACKAGE int __stdcall (*sx_OrderRecNo)(void);
extern PACKAGE void __stdcall (*sx_Pack)(void);
extern PACKAGE int __stdcall (*sx_PutBlob)(char * cpFieldName, void * vpVar, int lSize);
extern PACKAGE void __stdcall (*sx_PutRecord)(char * cpRecord);
extern PACKAGE void __stdcall (*sx_PutString)(char * cpFieldName, char * pVal);
extern PACKAGE void __stdcall (*sx_PutMemo)(char * cpFieldName, char * pMemoText);
extern PACKAGE void __stdcall (*sx_PutDateString)(char * cpFieldName, char * pVal);
extern PACKAGE void __stdcall (*sx_PutInteger)(char * cpFieldName, short iVal);
extern PACKAGE void __stdcall (*sx_PutLong)(char * cpFieldName, int iVal);
extern PACKAGE void __stdcall (*sx_PutLogical)(char * cpFieldName, Word bVal);
extern PACKAGE void __stdcall (*sx_PutDouble)(char * cpFieldName, double dVal);
extern PACKAGE int __stdcall (*sx_Query)(char * cpExpression);
extern PACKAGE int __stdcall (*sx_QueryRecCount)(void);
extern PACKAGE BOOL __stdcall (*sx_QuerySetExact)(BOOL bSetQueryExact);
extern PACKAGE short __stdcall (*sx_QueryTest)(char * cpExpression);
extern PACKAGE void __stdcall (*sx_Recall)(void);
extern PACKAGE int __stdcall (*sx_RecCount)(void);
extern PACKAGE int __stdcall (*sx_RecNo)(void);
extern PACKAGE int __stdcall (*sx_RecSize)(void);
extern PACKAGE void __stdcall (*sx_Reindex)(void);
extern PACKAGE void __stdcall (*sx_Replace)(char * cpFieldname, short iDataType, void * vpData);
extern PACKAGE BOOL __stdcall (*sx_Rlock)(int lRecNum);
extern PACKAGE BOOL __stdcall (*sx_RYOFilterActivate)(short iFilterHandle, short iBoolOperation);
extern PACKAGE short __stdcall (*sx_RYOFilterCopy)(void);
extern PACKAGE short __stdcall (*sx_RYOFilterCreate)(void);
extern PACKAGE BOOL __stdcall (*sx_RYOFilterDestroy)(short iFilterHandle);
extern PACKAGE BOOL __stdcall (*sx_RYOFilterGetBit)(short iFilterHandle, int lRecNo);
extern PACKAGE BOOL __stdcall (*sx_RYOFilterRestore)(char * cpFileName);
extern PACKAGE BOOL __stdcall (*sx_RYOFilterSave)(short iFilterHandle, char * cpFileName);
extern PACKAGE BOOL __stdcall (*sx_RYOFilterSetBit)(short iFilterHandle, int lRecNo, short iOnOrOff)
	;
extern PACKAGE BOOL __stdcall (*sx_RYOKeyAdd)(char * cpTagname, char * cpKey);
extern PACKAGE BOOL __stdcall (*sx_RYOKeyDrop)(char * cpTagname);
extern PACKAGE BOOL __stdcall (*sx_Seek)(char * cpKeyValue);
extern PACKAGE BOOL __stdcall (*sx_SeekBin)(char * cpKeyValue, Word uiLength);
extern PACKAGE Word __stdcall (*sx_Select)(Word uiBaseArea);
extern PACKAGE void __stdcall (*sx_SetCentury)(Word uiOnOff);
extern PACKAGE BOOL __stdcall (*sx_SetCollationRule)(int lRuleType, char * cpSrcSymbSet, char * cpDstSymbSet
	, BOOL bResetPrev, BOOL bOem, int lReserved);
extern PACKAGE void __stdcall (*sx_SetDateFormat)(Word uiDateType);
extern PACKAGE void __stdcall (*sx_SetDeleted)(Word uiDeleted);
extern PACKAGE Word __stdcall (*sx_SetEpoch)(Word uiBaseYear);
extern PACKAGE int __stdcall (*sx_SetErrorFunc)(int pFunc, int pData);
extern PACKAGE void __stdcall (*sx_SetExact)(Word uiOnOff);
extern PACKAGE void __stdcall (*sx_SetFilter)(char * cpExpression);
extern PACKAGE int __stdcall (*sx_SetGaugeFunc)(int pGaugeFunc);
extern PACKAGE void __stdcall (*sx_SetGaugeHook)(HWND hwndGauge);
extern PACKAGE short __stdcall (*sx_SetHandles)(short iNumHandles);
extern PACKAGE void __stdcall (*sx_SetLockTimeout)(short iSeconds);
extern PACKAGE void __stdcall (*sx_SetMachineCollation)(void);
extern PACKAGE Word __stdcall (*sx_SetMemoBlockSize)(Word uiBlockSize);
extern PACKAGE short __stdcall (*sx_SetOrder)(short iIndex);
extern PACKAGE void __stdcall (*sx_SetPassword)(char * cpEncodeKey);
extern PACKAGE void __stdcall (*sx_SetQueryBit)(int lRecNo, BOOL bValue);
extern PACKAGE void __stdcall (*sx_SetRelation)(Word uiChildArea, char * cpKeyExpr);
extern PACKAGE BOOL __stdcall (*sx_SetScope)(char * cpLowVal, char * cpHighVal);
extern PACKAGE void __stdcall (*sx_SetSoftSeek)(Word uiOnOff);
extern PACKAGE void __stdcall (*sx_SetStringType)(Word uiStringType);
extern PACKAGE void __stdcall (*sx_SetSystemCollation)(void);
extern PACKAGE void __stdcall (*sx_SetTranslate)(Word uiOnOff);
extern PACKAGE void __stdcall (*sx_SetTurboRead)(Word uiOnOff);
extern PACKAGE void __stdcall (*sx_SetUDFPath)(char * cpUDFPath);
extern PACKAGE char __stdcall (*sx_SetUserDelimiter)(char cDelimiter, BOOL bMakeTrim, BOOL bReflectMemo
	);
extern PACKAGE void __stdcall (*sx_Skip)(int lNumRecs);
extern PACKAGE int __stdcall (*sx_SysProp)(Word uiSysItem, void * vpData);
extern PACKAGE short __stdcall (*sx_TagArea)(char * cpTagName);
extern PACKAGE int __stdcall (*sx_TagCount)(void);
extern PACKAGE BOOL __stdcall (*sx_TagInfo)(void * cpTagInfo);
extern PACKAGE BOOL __stdcall (*sx_TagDelete)(char * cpTagname);
extern PACKAGE char * __stdcall (*sx_TagName)(short iTagArea);
extern PACKAGE void __stdcall (*sx_Unlock)(int lRecNum);
extern PACKAGE short __stdcall (*sx_Use)(char * cpFileName, char * cpAlias, short iOpenMode, short iRdeType
	);
extern PACKAGE short __stdcall (*sx_UseEx)(char * cpFileName, char * cpAlias, short iOpenMode, short 
	iRdeType, unsigned uiMode);
extern PACKAGE char * __stdcall (*sx_Version)(void);
extern PACKAGE Word __stdcall (*sx_WorkArea)(char * cpAlias);
extern PACKAGE void __stdcall (*sx_Zap)(void);
extern PACKAGE void __fastcall UnLoadDLL(void);
extern PACKAGE void __fastcall LoadDLL(void);

}	/* namespace Sde61 */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Sde61;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// SDE61
