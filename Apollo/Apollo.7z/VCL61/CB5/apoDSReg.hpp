// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Apodsreg.pas' rev: 5.00

#ifndef ApodsregHPP
#define ApodsregHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <IntSQL.hpp>	// Pascal unit
#include <ApoServerDLL.hpp>	// Pascal unit
#include <ApoQSet.hpp>	// Pascal unit
#include <ApConn.hpp>	// Pascal unit
#include <ApCommon.hpp>	// Pascal unit
#include <ApoEnv.hpp>	// Pascal unit
#include <ApoDSet.hpp>	// Pascal unit
#include <Apollo.hpp>	// Pascal unit
#include <SDE61.hpp>	// Pascal unit
#include <DsgnIntf.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <TypInfo.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Apodsreg
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TDBStringProperty;
class PASCALIMPLEMENTATION TDBStringProperty : public Dsgnintf::TStringProperty 
{
	typedef Dsgnintf::TStringProperty inherited;
	
public:
	virtual Dsgnintf::TPropertyAttributes __fastcall GetAttributes(void);
	virtual void __fastcall GetValueList(Classes::TStrings* List) = 0 ;
	virtual void __fastcall GetValues(Classes::TGetStrProc Proc);
protected:
	#pragma option push -w-inl
	/* TPropertyEditor.Create */ inline __fastcall virtual TDBStringProperty(const Dsgnintf::_di_IFormDesigner 
		ADesigner, int APropCount) : Dsgnintf::TStringProperty(ADesigner, APropCount) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TPropertyEditor.Destroy */ inline __fastcall virtual ~TDBStringProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TMasterFieldsProperty;
class PASCALIMPLEMENTATION TMasterFieldsProperty : public TDBStringProperty 
{
	typedef TDBStringProperty inherited;
	
public:
	virtual void __fastcall GetValueList(Classes::TStrings* List);
protected:
	#pragma option push -w-inl
	/* TPropertyEditor.Create */ inline __fastcall virtual TMasterFieldsProperty(const Dsgnintf::_di_IFormDesigner 
		ADesigner, int APropCount) : TDBStringProperty(ADesigner, APropCount) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TPropertyEditor.Destroy */ inline __fastcall virtual ~TMasterFieldsProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TIndexNameProperty;
class PASCALIMPLEMENTATION TIndexNameProperty : public TDBStringProperty 
{
	typedef TDBStringProperty inherited;
	
public:
	virtual void __fastcall GetValueList(Classes::TStrings* List);
protected:
	#pragma option push -w-inl
	/* TPropertyEditor.Create */ inline __fastcall virtual TIndexNameProperty(const Dsgnintf::_di_IFormDesigner 
		ADesigner, int APropCount) : TDBStringProperty(ADesigner, APropCount) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TPropertyEditor.Destroy */ inline __fastcall virtual ~TIndexNameProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TTableNameProperty;
class PASCALIMPLEMENTATION TTableNameProperty : public TDBStringProperty 
{
	typedef TDBStringProperty inherited;
	
public:
	virtual void __fastcall GetValueList(Classes::TStrings* List);
protected:
	#pragma option push -w-inl
	/* TPropertyEditor.Create */ inline __fastcall virtual TTableNameProperty(const Dsgnintf::_di_IFormDesigner 
		ADesigner, int APropCount) : TDBStringProperty(ADesigner, APropCount) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TPropertyEditor.Destroy */ inline __fastcall virtual ~TTableNameProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TDatabaseNameProperty;
class PASCALIMPLEMENTATION TDatabaseNameProperty : public TDBStringProperty 
{
	typedef TDBStringProperty inherited;
	
public:
	virtual void __fastcall GetValueList(Classes::TStrings* List);
protected:
	#pragma option push -w-inl
	/* TPropertyEditor.Create */ inline __fastcall virtual TDatabaseNameProperty(const Dsgnintf::_di_IFormDesigner 
		ADesigner, int APropCount) : TDBStringProperty(ADesigner, APropCount) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TPropertyEditor.Destroy */ inline __fastcall virtual ~TDatabaseNameProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TServerDLLProcNameProperty;
class PASCALIMPLEMENTATION TServerDLLProcNameProperty : public TDBStringProperty 
{
	typedef TDBStringProperty inherited;
	
public:
	virtual void __fastcall GetValueList(Classes::TStrings* List);
protected:
	#pragma option push -w-inl
	/* TPropertyEditor.Create */ inline __fastcall virtual TServerDLLProcNameProperty(const Dsgnintf::_di_IFormDesigner 
		ADesigner, int APropCount) : TDBStringProperty(ADesigner, APropCount) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TPropertyEditor.Destroy */ inline __fastcall virtual ~TServerDLLProcNameProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TServerDLLProcDatabaseNameProperty;
class PASCALIMPLEMENTATION TServerDLLProcDatabaseNameProperty : public TDBStringProperty 
{
	typedef TDBStringProperty inherited;
	
public:
	virtual void __fastcall GetValueList(Classes::TStrings* List);
protected:
	#pragma option push -w-inl
	/* TPropertyEditor.Create */ inline __fastcall virtual TServerDLLProcDatabaseNameProperty(const Dsgnintf::_di_IFormDesigner 
		ADesigner, int APropCount) : TDBStringProperty(ADesigner, APropCount) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TPropertyEditor.Destroy */ inline __fastcall virtual ~TServerDLLProcDatabaseNameProperty(void) { }
		
	#pragma option pop
	
};


class DELPHICLASS TQueryTableNameProperty;
class PASCALIMPLEMENTATION TQueryTableNameProperty : public TDBStringProperty 
{
	typedef TDBStringProperty inherited;
	
public:
	virtual void __fastcall GetValueList(Classes::TStrings* List);
protected:
	#pragma option push -w-inl
	/* TPropertyEditor.Create */ inline __fastcall virtual TQueryTableNameProperty(const Dsgnintf::_di_IFormDesigner 
		ADesigner, int APropCount) : TDBStringProperty(ADesigner, APropCount) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TPropertyEditor.Destroy */ inline __fastcall virtual ~TQueryTableNameProperty(void) { }
	#pragma option pop
	
};


class DELPHICLASS TQueryDatabaseNameProperty;
class PASCALIMPLEMENTATION TQueryDatabaseNameProperty : public TDBStringProperty 
{
	typedef TDBStringProperty inherited;
	
public:
	virtual void __fastcall GetValueList(Classes::TStrings* List);
protected:
	#pragma option push -w-inl
	/* TPropertyEditor.Create */ inline __fastcall virtual TQueryDatabaseNameProperty(const Dsgnintf::_di_IFormDesigner 
		ADesigner, int APropCount) : TDBStringProperty(ADesigner, APropCount) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TPropertyEditor.Destroy */ inline __fastcall virtual ~TQueryDatabaseNameProperty(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall Register(void);

}	/* namespace Apodsreg */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Apodsreg;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Apodsreg
