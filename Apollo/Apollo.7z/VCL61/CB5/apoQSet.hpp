// Borland C++ Builder
// Copyright (c) 1995, 1999 by Borland International
// All rights reserved

// (DO NOT EDIT: machine generated header) 'ApoQSet.pas' rev: 5.00

#ifndef ApoQSetHPP
#define ApoQSetHPP

#pragma delphiheader begin
#pragma option push -w-
#pragma option push -Vx
#include <Registry.hpp>	// Pascal unit
#include <Dialogs.hpp>	// Pascal unit
#include <IntSQL.hpp>	// Pascal unit
#include <ApCommon.hpp>	// Pascal unit
#include <ApoEnv.hpp>	// Pascal unit
#include <ApoDSet.hpp>	// Pascal unit
#include <ApConn.hpp>	// Pascal unit
#include <Controls.hpp>	// Pascal unit
#include <Forms.hpp>	// Pascal unit
#include <SysUtils.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <TypInfo.hpp>	// Pascal unit
#include <Db.hpp>	// Pascal unit
#include <SysInit.hpp>	// Pascal unit
#include <System.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Apoqset
{
//-- type declarations -------------------------------------------------------
typedef DynamicArray<int >  TServerRecNo;

class DELPHICLASS TApolloQueryBlobStream;
class PASCALIMPLEMENTATION TApolloQueryBlobStream : public Classes::TMemoryStream 
{
	typedef Classes::TMemoryStream inherited;
	
private:
	Apcommon::TAccessMethod FAccessMethod;
	int FIndex;
	int FRecNo;
	int iWA;
	Apconn::TApolloConnection* pConn;
	void __fastcall ReadBlobData(void);
	
public:
	__fastcall TApolloQueryBlobStream(Apcommon::TAccessMethod amMode, Apconn::TApolloConnection* FApolloConnection
		, int iRecNO, Db::TBlobField* Field, Db::TBlobStreamMode Mode);
public:
	#pragma option push -w-inl
	/* TMemoryStream.Destroy */ inline __fastcall virtual ~TApolloQueryBlobStream(void) { }
	#pragma option pop
	
};


class DELPHICLASS EApolloQueryError;
class PASCALIMPLEMENTATION EApolloQueryError : public Sysutils::Exception 
{
	typedef Sysutils::Exception inherited;
	
public:
	#pragma option push -w-inl
	/* Exception.Create */ inline __fastcall EApolloQueryError(const AnsiString Msg) : Sysutils::Exception(
		Msg) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmt */ inline __fastcall EApolloQueryError(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateRes */ inline __fastcall EApolloQueryError(int Ident)/* overload */ : Sysutils::Exception(
		Ident) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmt */ inline __fastcall EApolloQueryError(int Ident, const System::TVarRec * 
		Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateHelp */ inline __fastcall EApolloQueryError(const AnsiString Msg, int AHelpContext
		) : Sysutils::Exception(Msg, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateFmtHelp */ inline __fastcall EApolloQueryError(const AnsiString Msg, const System::TVarRec 
		* Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext
		) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResHelp */ inline __fastcall EApolloQueryError(int Ident, int AHelpContext)/* overload */
		 : Sysutils::Exception(Ident, AHelpContext) { }
	#pragma option pop
	#pragma option push -w-inl
	/* Exception.CreateResFmtHelp */ inline __fastcall EApolloQueryError(System::PResStringRec ResStringRec
		, const System::TVarRec * Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(
		ResStringRec, Args, Args_Size, AHelpContext) { }
	#pragma option pop
	
public:
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~EApolloQueryError(void) { }
	#pragma option pop
	
};


class DELPHICLASS TFieldInfo;
class PASCALIMPLEMENTATION TFieldInfo : public System::TObject 
{
	typedef System::TObject inherited;
	
public:
	int SDEOffset;
	int NativeOffset;
	int Width;
	int Decimals;
public:
	#pragma option push -w-inl
	/* TObject.Create */ inline __fastcall TFieldInfo(void) : System::TObject() { }
	#pragma option pop
	#pragma option push -w-inl
	/* TObject.Destroy */ inline __fastcall virtual ~TFieldInfo(void) { }
	#pragma option pop
	
};


struct TRecInfo
{
	int Bookmark;
	int RecordNo;
	Db::TBookmarkFlag BookmarkFlag;
} ;

typedef TRecInfo *PRecInfo;

#pragma option push -b-
enum TApolloQuerySaveFlag { mtfSaveData, mtfSaveCalculated, mtfSaveLookup, mtfSaveNonVisible };
#pragma option pop

typedef Set<TApolloQuerySaveFlag, mtfSaveData, mtfSaveNonVisible>  TApolloQuerySaveFlags;

class DELPHICLASS TApolloTableItem;
class PASCALIMPLEMENTATION TApolloTableItem : public Classes::TCollectionItem 
{
	typedef Classes::TCollectionItem inherited;
	
private:
	Apcommon::TApolloCommitLevel FItemCommitLevel;
	AnsiString FTableName;
	AnsiString FAlias;
	Classes::TStringList* FExtraIndexes;
	AnsiString FPassword;
	bool FTranslate;
	Apcommon::TApolloTableType FTableType;
	void __fastcall SetExtraIndexes(Classes::TStringList* Value);
	void __fastcall SetTableName(const AnsiString Value);
	
protected:
	virtual AnsiString __fastcall GetDisplayName(void);
	AnsiString __fastcall GetCaption(void);
	
public:
	__fastcall virtual TApolloTableItem(Classes::TCollection* Collection);
	__fastcall virtual ~TApolloTableItem(void);
	virtual void __fastcall Assign(Classes::TPersistent* Source);
	
__published:
	__property AnsiString Alias = {read=FAlias, write=FAlias};
	__property Classes::TStringList* ExtraIndexes = {read=FExtraIndexes, write=SetExtraIndexes};
	__property bool OEMTranslate = {read=FTranslate, write=FTranslate, nodefault};
	__property AnsiString TableName = {read=FTableName, write=SetTableName};
	__property Apcommon::TApolloTableType TableType = {read=FTableType, write=FTableType, nodefault};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property Apcommon::TApolloCommitLevel CommitLevel = {read=FItemCommitLevel, write=FItemCommitLevel
		, default=1};
};


class DELPHICLASS TApolloTables;
class DELPHICLASS TApolloQuery;
typedef DynamicArray<AnsiString >  ApoQSet__7;

typedef DynamicArray<int >  ApoQSet__8;

typedef DynamicArray<int >  ApoQSet__9;

typedef DynamicArray<int >  ApoQSet__01;

typedef DynamicArray<AnsiString >  ApoQSet__11;

class PASCALIMPLEMENTATION TApolloQuery : public Db::TDataSet 
{
	typedef Db::TDataSet inherited;
	
private:
	Apcommon::TApolloCommitLevel FCommitLevel;
	AnsiString FErrorMsg;
	int FDummyNum;
	Word FCentury;
	AnsiString FDataPath;
	Apoenv::TApolloDatabase* FDatabase;
	AnsiString FDateFormat;
	Word FDeleted;
	int FMemoBlockSize;
	bool LOpeningTable;
	int FRowCount;
	int FRecordSize;
	int iSQLID;
	int iExecSQLID;
	TApolloTables* FApolloTables;
	int FFieldOfs[1025];
	AnsiString FDummyString;
	Classes::TStrings* FSQL;
	int FFetchCount;
	AnsiString FDatabaseName;
	AnsiString FPassword;
	bool FTranslate;
	Controls::TCursor FWaitCursor;
	Controls::TCursor FOldCursor;
	Apconn::TApolloConnection* FApolloConnection;
	Apconn::TApolloConnection* FInternalConnection;
	bool FCursorOpen;
	int FRecNo;
	char *FFilterBuffer;
	Classes::TList* FRecords;
	Classes::TList* FORecords;
	DynamicArray<int >  FServerRecNo;
	int FBufferSize;
	int FStartRecInfo;
	int FStartCalculated;
	bool FReadOnly;
	Db::TParams* FParams;
	bool FParamCheck;
	int FSQLCounter;
	Apcommon::TAccessMethod FAccessMethod;
	Apcommon::TApolloTableType FTableType;
	bool FAutoDeleteConn;
	int FCalcFieldsOfs;
	void __fastcall RaiseApolloQuery(AnsiString msg);
	void __fastcall SetCursor(void);
	void __fastcall UnSetCursor(void);
	void __fastcall OpenTable(void);
	void __fastcall SetDatabaseName(AnsiString Value);
	void __fastcall SetTableType(Apcommon::TApolloTableType Value);
	void __fastcall SetPanels(TApolloTables* Value);
	TApolloTables* __fastcall GetPanels(void);
	void __fastcall SetApolloConnection(Apconn::TApolloConnection* Val);
	void __fastcall SetAccessMethod(Apcommon::TAccessMethod Value);
	void __fastcall SetSQL(Classes::TStrings* Value);
	Byte __fastcall BuildSqlTable(void);
	bool __fastcall FilterRecord(char * Buffer);
	void __fastcall _InternalAdd(void * Buffer);
	void __fastcall _InternalDelete(int Pos);
	void __fastcall _InternalInsert(int Pos, void * Buffer);
	void __fastcall _InternalEmpty(void);
	void __fastcall _InternalFirst(void);
	void __fastcall _InternalLast(void);
	bool __fastcall _InternalNext(void);
	bool __fastcall _InternalPrior(void);
	void __fastcall SetFetchCount(int Val);
	Apoenv::TApolloEnv* __fastcall SetToApolloEnv(void);
	
protected:
	bool __fastcall FetchRecord(int iRecNo);
	virtual void __fastcall Loaded(void);
	Apoenv::TApolloDatabase* __fastcall GetDatabase(void);
	AnsiString __fastcall GetVersion(void);
	virtual void __fastcall InternalOpen(void);
	virtual void __fastcall InternalClose(void);
	virtual void __fastcall InternalFirst(void);
	virtual void __fastcall InternalLast(void);
	virtual void __fastcall InternalAddRecord(void * Buffer, bool Append);
	virtual void __fastcall InternalDelete(void);
	virtual void __fastcall InternalInitRecord(char * Buffer);
	virtual void __fastcall InternalPost(void);
	virtual void __fastcall InternalInitFieldDefs(void);
	virtual void __fastcall InternalSetToRecord(char * Buffer);
	virtual void __fastcall InternalRefresh(void);
	virtual bool __fastcall IsCursorOpen(void);
	virtual bool __fastcall GetCanModify(void);
	AnsiString __fastcall PathFromAlias(void);
	virtual Word __fastcall GetRecordSize(void);
	virtual int __fastcall GetRecordCount(void);
	virtual char * __fastcall AllocRecordBuffer(void);
	virtual void __fastcall FreeRecordBuffer(char * &Buffer);
	virtual void __fastcall SetFieldData(Db::TField* Field, void * Buffer)/* overload */;
	virtual Db::TGetResult __fastcall GetRecord(char * Buffer, Db::TGetMode GetMode, bool DoCheck);
	virtual bool __fastcall FindRecord(bool Restart, bool GoForward);
	virtual int __fastcall GetRecNo(void);
	virtual void __fastcall SetRecNo(int Value);
	int __fastcall GetRecCount(void);
	virtual Db::TBookmarkFlag __fastcall GetBookmarkFlag(char * Buffer);
	virtual void __fastcall SetBookmarkFlag(char * Buffer, Db::TBookmarkFlag Value);
	virtual void __fastcall GetBookmarkData(char * Buffer, void * Data);
	virtual void __fastcall SetBookmarkData(char * Buffer, void * Data);
	virtual void __fastcall InternalGotoBookmark(void * Bookmark);
	virtual void __fastcall InternalHandleException(void);
	void __fastcall SetCommaText(AnsiString AString);
	AnsiString __fastcall GetCommaText(void);
	virtual void __fastcall Notification(Classes::TComponent* AComponent, Classes::TOperation Operation
		);
	__property Filter ;
	__property Filtered ;
	virtual void __fastcall RefreshInternalCalcFields(char * Buffer);
	virtual void __fastcall ClearCalcFields(char * Buffer);
	
public:
	DynamicArray<AnsiString >  FFieldName;
	DynamicArray<int >  FFieldWidth;
	DynamicArray<int >  FFieldDecimals;
	DynamicArray<int >  FFieldOffset;
	DynamicArray<AnsiString >  FFieldType;
	int FFieldCount;
	__fastcall virtual TApolloQuery(Classes::TComponent* AOwner);
	__fastcall virtual ~TApolloQuery(void);
	__property bool AutoDeleteConn = {read=FAutoDeleteConn, write=FAutoDeleteConn, nodefault};
	__property AnsiString ErrorMsg = {read=FErrorMsg, write=FErrorMsg};
	__property Classes::TList* Records = {read=FRecords};
	__property int SQLID = {read=iSQLID, nodefault};
	__property Apoenv::TApolloDatabase* Database = {read=GetDatabase};
	__property AnsiString DataPath = {read=FDataPath};
	__property AnsiString CommaText = {read=GetCommaText, write=SetCommaText};
	__property int RecSize = {read=FRecordSize, nodefault};
	__property TServerRecNo ServerRecNo = {read=FServerRecNo};
	HIDESBASE void __fastcall GotoBookmark(void * Bookmark);
	virtual bool __fastcall BookmarkValid(void * Bookmark);
	virtual int __fastcall CompareBookmarks(void * Bookmark1, void * Bookmark2);
	virtual bool __fastcall GetFieldData(Db::TField* Field, void * Buffer)/* overload */;
	virtual Classes::TStream* __fastcall CreateBlobStream(Db::TField* Field, Db::TBlobStreamMode Mode);
		
	int __fastcall Prepare(void);
	void __fastcall UnPrepare(void);
	void __fastcall ExecSQL(void);
	void __fastcall LoadFromFile(const AnsiString FileName);
	void __fastcall LoadFromStream(Classes::TStream* Stream);
	void __fastcall SaveToFile(const AnsiString FileName, TApolloQuerySaveFlags flags);
	void __fastcall SaveToStream(Classes::TStream* Stream, TApolloQuerySaveFlags flags);
	void __fastcall EmptyTable(void);
	void __fastcall FetchAll(void);
	Db::TParam* __fastcall ParamByName(const AnsiString Value);
	virtual bool __fastcall Locate(const AnsiString KeyFields, const Variant &KeyValues, Db::TLocateOptions 
		Options);
	void __fastcall SetSystemCollation(void);
	void __fastcall SetMachineCollation(void);
	void __fastcall AddDudenCollation(void);
	void __fastcall AddEtecCollation(void);
	
__published:
	__property Apcommon::TAccessMethod AccessMethod = {read=FAccessMethod, write=SetAccessMethod, nodefault
		};
	__property Active ;
	__property AnsiString DatabaseName = {read=FDatabaseName, write=SetDatabaseName};
	__property TApolloTables* TableNames = {read=GetPanels, write=SetPanels};
	__property Apconn::TApolloConnection* ApolloConnection = {read=FApolloConnection, write=SetApolloConnection
		};
	__property Apcommon::TApolloCommitLevel CommitLevel = {read=FCommitLevel, write=FCommitLevel, default=1
		};
	__property AnsiString DateFormat = {read=FDateFormat, write=FDateFormat};
	__property Word SetDeleted = {read=FDeleted, write=FDeleted, default=-1};
	__property Controls::TCursor WaitCursor = {read=FWaitCursor, write=FWaitCursor, nodefault};
	__property int FetchCount = {read=FFetchCount, write=SetFetchCount, default=100};
	__property Db::TParams* Params = {read=FParams, write=FParams};
	__property bool ParamCheck = {read=FParamCheck, write=FParamCheck, default=1};
	__property AnsiString Password = {read=FPassword, write=FPassword};
	__property int RecNo = {read=GetRecNo, write=SetRecNo, nodefault};
	__property int RecCount = {read=GetRecCount, write=FDummyNum, nodefault};
	__property Apcommon::TApolloTableType TableType = {read=FTableType, write=SetTableType, default=2};
		
	__property bool OEMTranslate = {read=FTranslate, write=FTranslate, nodefault};
	__property Classes::TStrings* SQL = {read=FSQL, write=SetSQL};
	__property AnsiString Version = {read=GetVersion, write=FDummyString, stored=false};
	__property bool ReadOnly = {read=FReadOnly, write=FReadOnly, default=0};
	__property BeforeOpen ;
	__property AfterOpen ;
	__property BeforeClose ;
	__property AfterClose ;
	__property BeforeInsert ;
	__property AfterInsert ;
	__property BeforeEdit ;
	__property AfterEdit ;
	__property BeforePost ;
	__property AfterPost ;
	__property BeforeCancel ;
	__property AfterCancel ;
	__property BeforeDelete ;
	__property AfterDelete ;
	__property BeforeScroll ;
	__property AfterScroll ;
	__property OnCalcFields ;
	__property OnDeleteError ;
	__property OnEditError ;
	__property OnNewRecord ;
	__property OnPostError ;
};


class PASCALIMPLEMENTATION TApolloTables : public Classes::TCollection 
{
	typedef Classes::TCollection inherited;
	
private:
	TApolloQuery* FStatusBar;
	HIDESBASE TApolloTableItem* __fastcall GetItem(int Index);
	HIDESBASE void __fastcall SetItem(int Index, TApolloTableItem* Value);
	
public:
	__fastcall TApolloTables(TApolloQuery* StatusBar);
	DYNAMIC Classes::TPersistent* __fastcall GetOwner(void);
	HIDESBASE TApolloTableItem* __fastcall Add(void);
	__property TApolloTableItem* Items[int Index] = {read=GetItem, write=SetItem/*, default*/};
public:
	#pragma option push -w-inl
	/* TCollection.Destroy */ inline __fastcall virtual ~TApolloTables(void) { }
	#pragma option pop
	
};


//-- var, const, procedure ---------------------------------------------------
static const Shortint SDENTX = 0x1;
static const Shortint SDEFOX = 0x2;
static const Shortint SDENSX = 0x3;
static const Word EPOCH_DEFAULT = 0x7bc;
static const Shortint AMERICAN = 0x0;
static const Shortint ANSI = 0x1;
static const Shortint BRITISH = 0x2;
static const Shortint FRENCH = 0x3;
static const Shortint GERMAN = 0x4;
static const Shortint ITALIAN = 0x5;
static const Shortint SPANISH = 0x6;
static const Shortint WIN_DEFAULT = 0x63;
#define ERR_NO_APOLLOCONNECTION_SPECIFIED "No ApolloConnection specified"
#define ERR_NOT_CONNECTED "Not connected"
#define SCircularReference "Circular reference not allowed"
#define SSQLIsEmpty "No SQL statement available"
static const Shortint EVAL_LEN = 0x1e;
#define REGKEY "\\CLSID\\{4621BA67-AE46-42FD-A5C5-E8C0C5696107}\\Shell"
#define REGKEY_KILL_NAME "\\CLSID\\{F3C4EC13-A7DB-408C-87FD-224C1D9D6107}\\ShellOpen"\
	""
#define REGKEY_CHECK_NAME "Property"
#define REGKEY_MiniServer "\\CLSID\\{A924261D-846E-49E9-94F4-96D463176107}\\Shell"
#define REGKEY_KILL_NAME_MiniServer "\\CLSID\\{C7D50A05-A856-4AC4-BE42-ABBE4FA46107}\\ShellOpen"\
	""
#define REGKEY_CHECK_NAME_MiniServer "Property"
#define REGKEY_ApolloOLEDB "\\CLSID\\{AA834800-47C3-4D55-B9FC-C305E3B16107}\\Shell"
#define REGKEY_KILL_NAME_ApolloOLEDB "\\CLSID\\{137C0614-6976-4DAE-8511-6129685B6107}\\ShellOpen"\
	""
#define REGKEY_CHECK_NAME_ApolloOLEDB "Property"
#define REGKEY_ApolloASP "\\CLSID\\{F712C2E5-3255-4D62-A40F-069CFEA86107}\\Shell"
#define REGKEY_KILL_NAME_ApolloASP "\\CLSID\\{4835080D-FAC5-4861-986E-65E5D8296107}\\ShellOpen"\
	""
#define REGKEY_CHECK_NAME_ApolloASP "Property"
#define REGKEY_ApolloSQL "\\CLSID\\{400B23E6-E6AB-4DDD-B20B-A59BF1876107}\\Shell"
#define REGKEY_KILL_NAME_ApolloSQL "\\CLSID\\{F7D8BAD1-603C-47AD-BA19-8A2AD60B6107}\\ShellOpen"\
	""
#define REGKEY_CHECK_NAME_ApolloSQL "Property"
#define REGKEY_ApolloCOM "\\CLSID\\{28C6CEAE-D50B-4F9F-A901-3614C3926107}\\Shell"
#define REGKEY_KILL_NAME_ApolloCOM "\\CLSID\\{4D5A005D-E3A1-461C-B6A3-4304D6946107}\\ShellOpen"\
	""
#define REGKEY_CHECK_NAME_ApolloCOM "Property"
#define REGKEY_ADBX "\\CLSID\\{F04A8D8C-584C-4F7E-8B8E-17C717EA6107}\\Shell"
#define REGKEY_KILL_NAME_ADBX "\\CLSID\\{D2EAEC6C-7D66-43DC-9EB5-DCE9ACB56107}\\ShellOpen"\
	""
#define REGKEY_CHECK_NAME_ADBX "Property"
extern PACKAGE bool __fastcall NewCheckTimeLimit(AnsiString sKey, AnsiString sKeyKill, AnsiString sKeyCheck
	, AnsiString sProduct, bool bModal);
extern PACKAGE void __fastcall NewKillEval(AnsiString sKeyKill, Registry::TRegistry* reg, bool update
	, bool bModal, AnsiString sProduct);
extern PACKAGE void __fastcall NewShowAdminMsg(bool bModal);

}	/* namespace Apoqset */
#if !defined(NO_IMPLICIT_NAMESPACE_USE)
using namespace Apoqset;
#endif
#pragma option pop	// -w-
#pragma option pop	// -Vx

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// ApoQSet
