//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma link "Grids"
#pragma link "ApoDSet"
#pragma resource "*.dfm"
TForm1 *Form1;
long hBitMap;  // Handle to RYO Bitmap

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
	ApDS->Open();
 	hBitMap = ApDS->RYOFilterCreate();  // Create new, empty bitmap
 	ShowMessage( "Double-click on records to add them to the filter bitmap. " \
               "Then, click the Activate button to view filtered record set." );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
	if (Button1->Caption == "Activate Filter")
  {
		ApDS->RYOFilterActivate( hBitMap, RYOFILTER_NEW );
		Button1->Caption = "Clear Filter";
	}
	else
  {
		ApDS->RYOFilterDestroy( 0 );       // Deactivate, not destroy
		ApDS->RYOFilterDestroy( hBitMap ); // Destroys, freeing allocated memory
   	hBitMap = ApDS->RYOFilterCreate();   // Create new, empty bitmap
		Button1->Caption = "Activate Filter";
	}
	ApDS->First();
  ApDS->Refresh();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Open1Click(TObject *Sender)
{
	if (OpenDialog1->Execute())
		if (ApDS->RYOFilterRestore( OpenDialog1->FileName ))
			Button1->Caption = "Clear Filter";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SaveAs1Click(TObject *Sender)
{
	if (SaveDialog1->Execute())
		ApDS->RYOFilterSave( hBitMap, SaveDialog1->FileName );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Exit1Click(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DBGrid1DblClick(TObject *Sender)
{
	if (ApDS->RYOFilterSetBit( hBitMap, ApDS->RecNo, true ))
		ShowMessage( "Set bit for record " + IntToStr( ApDS->RecNo ) + ".");
	else
		ShowMessage( "Set bit FAILED for record " + IntToStr( ApDS->RecNo ) + ".");
}
//--------------------------------------------------------------------------- 