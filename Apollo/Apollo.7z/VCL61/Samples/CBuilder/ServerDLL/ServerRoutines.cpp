#pragma hdrstop
#include "ServerRoutines.h"
#pragma package(smart_init)
//---------------------------------------------------------------------

extern "C" __declspec(dllexport) void ServerCount(
                     TSessionData *SessionData, TExecType *ExecType)
{
   int i, numberRecords, ERRORCODE;
   int savedWA, iWA;
   String sTableName;

   // get table name passed to us from client
   sTableName = SessionData->Params->ParamByName("TABLENAME")->AsString;
   numberRecords = 0;
   try
   {
      // For fastest data access, use low-level SDE calls
      // must call this function before any SDE calls
      Sde61::LoadDLL();
      // get work area of open table
      iWA = 0;
      for( i = 0; i < 255; i++)
      {  // this only works for open Tables
         if (SessionData->TableName[i] == sTableName)
         {
            iWA = SessionData->WASelected[i]; // get work area of open table
            break;
         }
      }
      if (iWA < 1)
      {
         // set an error condition and exit procedure if table not opened
         SessionData->Params->ParamByName("COUNT")->AsInteger = numberRecords;
         SessionData->Params->ParamByName("ERRORCODE")->AsInteger = 3;
         return;
      }
      savedWA = sx_Select(iWA);
      // could just use sx_Count() function but this is more fun
      sx_GoTop(); // Position cursor on first record
      while (!sx_Eof())
      {
         numberRecords++; // increment count
         sx_Skip(1); // equivalent to Table1->Next();
      }
      sx_Select(savedWA); // This seems redundant to me but it was in the demo
      // return count and error code to client (0 means all was OK)
      SessionData->Params->ParamByName("COUNT")->AsInteger = numberRecords;
      SessionData->Params->ParamByName("ERRORCODE")->AsInteger = 0; // OK
      return;
   }
   catch (...)
   {
      // Unexpected error occurred
      SessionData->Params->ParamByName("ERRORCODE")->AsInteger = 99;
      return;
   }
}
//---------------------------------------------------------------------

extern "C" __declspec(dllexport) void ServerCopyTable(
                     TSessionData *SessionData, TExecType *ExecType)
{
   int i, numberRecords, ERRORCODE;
   int savedWA, iWA;
   String sDatabaseName, sDatabasePath, sPath, sTableName, newTableName;
   String serverAlias, newFileName;

   try
   {
      // For fastest data access, use low-level SDE calls
      // must call this function before any SDE calls
      Sde61::LoadDLL();
      // get table name passed to us from client
      sTableName = SessionData->Params->ParamByName("TABLENAME")->AsString;
      sDatabaseName = SessionData->Params->ParamByName("DATABASENAME")->AsString;
      // we are relying on client to know location of Apollo DB Server
      sDatabasePath = SessionData->Params->ParamByName("DATABASEPATH")->AsString;

      // need to open "ALIAS" database (in ADS52 directory) and read names of
      // aliases to get associated paths
      TApolloTable *AliasTbl = new TApolloTable(0); // create table object
      AliasTbl->AccessMethod = Apcommon::amLocal;
      AliasTbl->DatabaseName = sDatabasePath; //need to refer directly to path
      AliasTbl->TableName = "Alias.dbf";
      AliasTbl->TableType = ttSXNSX;
      AliasTbl->Password = "lorant"; // don't ask me why Vista used this one
      try
      {
         AliasTbl->Open();
         while (!AliasTbl->ApolloEOF)
         {
            serverAlias = AliasTbl->GetString("ALIAS");
            if (serverAlias.Trim() == sDatabaseName)
            {  // trim the excess spaces (field length = 32 characters)
               sPath = AliasTbl->GetString("PATH").Trim();
               break;
            }
            else
               sPath = "";
            AliasTbl->Skip(1);
         }
         AliasTbl->Close();
         delete AliasTbl;
      }
      catch (EApolloError &error)
      {
         AliasTbl->Close();
         delete AliasTbl;
         SessionData->Params->ParamByName("ERRORCODE")->AsInteger = 1; // OhOh
         newTableName = "";
         SessionData->Params->ParamByName("NEWTABLENAME")->AsString = newTableName;
         return;
      }
      if (sPath == "")
      {
         SessionData->Params->ParamByName("ERRORCODE")->AsInteger = 2; // OhOh
         return;
      }
      else
      {
         newTableName = sPath + "\\copyof_" + sTableName; // define new name (incl. path)
         TApolloTable *SourceTbl = new TApolloTable(0); // create table object
         SourceTbl->AccessMethod = Apcommon::amLocal;
         SourceTbl->DatabaseName = sPath; // where table is located
         SourceTbl->TableName = sTableName;
         SourceTbl->TableType = ttSXNSX;
         try
         {
            SourceTbl->Exclusive = true; // it's the law
            SourceTbl->Open();
            //sx_Select( Word( SourceTbl->Handle )); // have to use the direct api calls
            //if (!sx_CopyFile(newTableName.c_str()))
            if (!SourceTbl->CopyFile(newTableName))
            {
               SessionData->Params->ParamByName("ERRORCODE")->AsInteger = 4; // Ooops!
               newTableName = "";
            }
            else
               SessionData->Params->ParamByName("ERRORCODE")->AsInteger = 0; // Success
            // pass new table name back to client
            SessionData->Params->ParamByName("NEWTABLENAME")->AsString = newTableName;
            SourceTbl->Close();
            SourceTbl->Exclusive = false; // allow others to access table again
            SourceTbl->Open(); // I found that if I didn't open table again
            SourceTbl->Close();// then next time opening table would be a problem
            delete SourceTbl;  // remember to delete the object we created
            return;
         }
         catch (EApolloError &error)
         {
            SourceTbl->Close();
            SourceTbl->Exclusive = false; // allow others to access table again
            SourceTbl->Open(); // I found that if I didn't open table again
            SourceTbl->Close();// then next time opening table would be a problem
            delete SourceTbl;  // remember to delete the object we created
            SessionData->Params->ParamByName("ERRORCODE")->AsInteger = 3; // Ooops!
            newTableName = "";
            SessionData->Params->ParamByName("NEWTABLENAME")->AsString = newTableName;
            return;
         }
      }
   }
   catch (...)
   {
      // Unexpected error occurred
      SessionData->Params->ParamByName("ERRORCODE")->AsInteger = 99;
      return;
   }
}
//---------------------------------------------------------------------

/*
   ERRORCODE Return Values:
      0 = success;
      1 = error opening ads52 alias table;
      2 = invalid database path;
      3 = error opening source table;
      4 = error copying table;
*/

