//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Client.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "ApConn"
#pragma link "ApoServerDLL"
#pragma link "APwin"
#pragma link "ApoDSet"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
   : TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall TForm1::FormCreate(TObject *Sender)
{
   IPaddressExit(Sender);
   DatabaseNamesCB->Items->Assign(ApolloConnection1->GetDatabaseNamesList());
}
//---------------------------------------------------------------------------

void __fastcall TForm1::DatabaseNamesCBChange(TObject *Sender)
{
   TableNamesCB->Items->Assign(
         ApolloConnection1->GetTableNamesList(
            DatabaseNamesCB->Items->Strings[DatabaseNamesCB->ItemIndex]));
}
//---------------------------------------------------------------------------

void __fastcall TForm1::IPaddressDblClick(TObject *Sender)
{
   IPaddress->SelectAll();

}
//---------------------------------------------------------------------------

void __fastcall TForm1::IPaddressExit(TObject *Sender)
{
   ApolloConnection1->Active = false;
   ApolloConnection1->Host = IPaddress->Text.Trim();
   ApolloConnection1->Active = true;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::GetRecordCountBtnClick(TObject *Sender)
{
   int ERRORCODE;
   String errorString, tableName;

   Edit1->Visible = false;
   tableName = TableNamesCB->Items->Strings[TableNamesCB->ItemIndex];
   try
   {
      ApolloTbl->DatabaseName =
               DatabaseNamesCB->Items->Strings[DatabaseNamesCB->ItemIndex];
      ApolloTbl->TableName = tableName;
      ApolloTbl->Open();
   }
   catch (EApolloError &error)
   {
      MessageDlg("Error Opening data table", mtError, TMsgDlgButtons() << mbOK, 0);
      ApolloTbl->Close();
      return;
   }
   // if no error then carry on
   ApolloServerDLL1->DatabaseName =
         DatabaseNamesCB->Items->Strings[DatabaseNamesCB->ItemIndex];
   ApolloServerDLL1->ProcName = "ServerCount";

   if (!ApolloServerDLL1->ProcParams->FindParam("TABLENAME"))
      ApolloServerDLL1->ProcParams->CreateParam(ftInteger, "TABLENAME", ptInput);
   if (!ApolloServerDLL1->ProcParams->FindParam("COUNT"))
      ApolloServerDLL1->ProcParams->CreateParam(ftInteger, "COUNT", ptOutput);
   if (!ApolloServerDLL1->ProcParams->FindParam("ERRORCODE"))
      ApolloServerDLL1->ProcParams->CreateParam(ftInteger, "ERRORCODE", ptOutput);

   ApolloServerDLL1->ProcParams->ParamByName("TABLENAME")->AsString = tableName;
   ApolloServerDLL1->ExecProc();
   ERRORCODE = ApolloServerDLL1->ProcParams->ParamByName("ERRORCODE")->AsInteger;
   ApolloTbl->Close();

   if (!ERRORCODE)
   {
      Edit1->Text =
         IntToStr(ApolloServerDLL1->ProcParams->ParamByName("COUNT")->AsInteger);
      Edit1->Visible = true;
   }
   else
   {
      switch (ERRORCODE)
      {
         case 1 : errorString = "Error opening server 'alias' table"; break;
         case 2 : errorString = "Invalid database path on server"; break;
         case 3 : errorString = "Error opening source table"; break;
         case 4 : errorString = "Error copying table"; break;
         default : errorString = "Unexpected Error Occurred";
      }
      MessageDlg(errorString, mtError, TMsgDlgButtons() << mbOK, 0);
   }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::CopyTableBtnClick(TObject *Sender)
{
   int ERRORCODE;
   String errorString, dbName, dbPath, dbTableName;

   Edit1->Visible = false;
   dbName = DatabaseNamesCB->Items->Strings[DatabaseNamesCB->ItemIndex];
   dbPath = "c:\\Program Files\\Apollo\\ADS52"; // path of database server
   dbTableName = TableNamesCB->Items->Strings[TableNamesCB->ItemIndex];
   ApolloServerDLL1->DatabaseName = dbName;
   ApolloServerDLL1->ProcName = "ServerCopyTable";

   if (!ApolloServerDLL1->ProcParams->FindParam("DATABASENAME"))
      ApolloServerDLL1->ProcParams->CreateParam(ftInteger, "DATABASENAME", ptInput);
   if (!ApolloServerDLL1->ProcParams->FindParam("DATABASEPATH"))
      ApolloServerDLL1->ProcParams->CreateParam(ftInteger, "DATABASEPATH", ptInput);
   if (!ApolloServerDLL1->ProcParams->FindParam("TABLENAME"))
      ApolloServerDLL1->ProcParams->CreateParam(ftInteger, "TABLENAME", ptInput);
   if (!ApolloServerDLL1->ProcParams->FindParam("NEWTABLENAME"))
      ApolloServerDLL1->ProcParams->CreateParam(ftInteger, "NEWTABLENAME", ptOutput);
   if (!ApolloServerDLL1->ProcParams->FindParam("ERRORCODE"))
      ApolloServerDLL1->ProcParams->CreateParam(ftInteger, "ERRORCODE", ptOutput);

   ApolloServerDLL1->ProcParams->ParamByName("DATABASENAME")->AsString = dbName;
   ApolloServerDLL1->ProcParams->ParamByName("DATABASEPATH")->AsString = dbPath;
   ApolloServerDLL1->ProcParams->ParamByName("TABLENAME")->AsString = dbTableName;
   ApolloServerDLL1->ExecProc();
   ERRORCODE = ApolloServerDLL1->ProcParams->ParamByName("ERRORCODE")->AsInteger;

   if (!ERRORCODE)
      ShowMessage("Table Copied Successfully\n"
               "New Table Name = " +
               ApolloServerDLL1->ProcParams->ParamByName("NEWTABLENAME")->AsString);
   else
   {
      switch (ERRORCODE)
      {
         case 1 : errorString = "Error opening server 'alias' table"; break;
         case 2 : errorString = "Invalid database path on server"; break;
         case 3 : errorString = "Error opening source table"; break;
         case 4 : errorString = "Error copying table"; break;
         default : errorString = "Unexpected Error Occurred";
      }
      MessageDlg(errorString, mtError, TMsgDlgButtons() << mbOK, 0);
   }
}
//---------------------------------------------------------------------------
/*
   ERRORCODE Return Values:
      0 = success;
      1 = error opening ads52 alias table;
      2 = invalid database path;
      3 = error opening source table;
      4 = error copying table;
*/


