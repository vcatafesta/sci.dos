// ServerRoutines.H

/*
   ERRORCODE Return Values:
      0 = success;
      1 = error opening ads52 alias table;
      2 = invalid database path;
      3 = error opening source table;
      4 = error copying table;
*/

//---------------------------------------------------------------------
#ifndef ServerRoutinesH
#define ServerRoutinesH
//---------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <ExtCtrls.hpp>
#include <Dialogs.hpp>
#include <Db.hpp>

#include "ApWin.hpp"
#include "ApoDSet.hpp"
#include "ApClass.hpp"
//#include <sysutils.hpp> //included in ApWin.hpp
//#include "ApCommon.hpp" //included in ApWin.hpp
//#include "SDE61.hpp" // included in ApCommon.hpp called from ApWin.hpp
//---------------------------------------------------------------------
// exported interface function
extern "C" __declspec(dllexport) void ServerCount(
                     TSessionData *SessionData, TExecType *ExecType);
extern "C" __declspec(dllexport) void ServerCopyTable(
                     TSessionData *SessionData, TExecType *ExecType);

//---------------------------------------------------------------------
#endif

