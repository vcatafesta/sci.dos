//---------------------------------------------------------------------------

#ifndef ClientH
#define ClientH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "ApConn.hpp"
#include "ApoServerDLL.hpp"
#include "APwin.hpp"
#include "ApoDSet.hpp"
#include <Db.hpp>
#include <Mask.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
   TApolloConnection *ApolloConnection1;
   TApolloServerDLL *ApolloServerDLL1;
   TEdit *Edit1;
   TButton *GetRecordCountBtn;
   TApolloTable *ApolloTbl;
   TButton *CopyTableBtn;
   TComboBox *TableNamesCB;
   TComboBox *DatabaseNamesCB;
   TMaskEdit *IPaddressMasked;
   TLabel *Label1;
   TEdit *IPaddress;
   void __fastcall GetRecordCountBtnClick(TObject *Sender);
   void __fastcall CopyTableBtnClick(TObject *Sender);
   void __fastcall FormCreate(TObject *Sender);
   void __fastcall DatabaseNamesCBChange(TObject *Sender);
   void __fastcall IPaddressDblClick(TObject *Sender);
   void __fastcall IPaddressExit(TObject *Sender);
private:	// User declarations
public:		// User declarations
   __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
