//---------------------------------------------------------------------------
#include <vcl\vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma link "Grids"
#pragma link "ApoDSet"
#pragma resource "*.dfm"
TForm1 *Form1;
String QueryStr;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
	ApDS->DatabaseName = ExtractFilePath( Application->ExeName );
 	ApDS->Open();
 	ApDS->SetOrder( ApDS->TagArea( "First" ));
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormClose(TObject *Sender, TCloseAction &Action)
{
	ApDS->Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
	ApDS->Query( "" );
	QueryStr = "First = 'B'";
	ApDS->Query( QueryStr );
	Edit1->Text = QueryStr;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button6Click(TObject *Sender)
{
	ApDS->Query( "" );
	QueryStr = "";
	Edit1->Text = QueryStr;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button4Click(TObject *Sender)
{
 	ApDS->Query( "" );
 	QueryStr = "(First = Padr('Homer',20,' ')) .and. (Last = 'S')";
 	ApDS->Query( QueryStr );
 	Edit1->Text = QueryStr;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button8Click(TObject *Sender)
{
 	Edit1->Text = IntToStr( ApDS->QueryTest( QueryStr )) +
                 " [Note: See code for exact syntax]";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
	String NewStr;

	ApDS->Query( "" );
 	NewStr = "Homer";
 	QueryStr = "First = '" + NewStr + "'";
 	ApDS->Query( QueryStr );
 	Edit1->Text = QueryStr + " [See code for exact syntax.]";
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button5Click(TObject *Sender)
{
 	ApDS->Query( "" );
 	QueryStr = "(Upper(First) = 'C') .and. (.not.(Married)) .and. (Salary > 300000)";

 	// In order for this to be partially optimizable, the index would need to
	//	be built on 'Upper(First)' rather than just 'First'.
 	ApDS->Query( QueryStr );
 	Edit1->Text = QueryStr;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button3Click(TObject *Sender)
{
 	ApDS->Query( "" );
 	QueryStr = "HireDate > CtoD('01/01/93')";
 	ApDS->Query( QueryStr );
 	Edit1->Text = QueryStr;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button7Click(TObject *Sender)
{
 	ApDS->Query( "" );
 	QueryStr = "First == 'B'";
 	ApDS->Query( QueryStr );
 	Edit1->Text = QueryStr + " [Note: there is no 'B' record so there is no result set]";
}
//---------------------------------------------------------------------------
