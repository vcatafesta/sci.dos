//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma link "Grids"
#pragma link "ApoDSet"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::sb1Click(TObject *Sender)
{
	String sDir;

	sDir = ExtractFilePath( Application->ExeName );
	ApDS1->DatabaseName = sDir;
	if (FileExists( "ztest.dbf" ))
  	DeleteFile( "ztest.dbf" );

	if (!ApDS1->CreateNew( "ztest.dbf", SDENSX, 5 ))
  {
		ShowMessage( "Create failed" );
		return;
	}
	ApDS1->CreateField( "Name",    "C", 25, 0 );
	ApDS1->CreateField( "Age",     "N", 10, 2 );
	ApDS1->CreateField( "Married", "L",  1, 0 );
	ApDS1->CreateField( "BDate",   "D",  8, 0 );
	ApDS1->CreateField( "Memo",    "M", 10, 0 );
	if (ApDS1->CreateExec())
		ShowMessage( "Create succeeded" );
	else
		ShowMessage( "Create failed" );

	ApDS1->Open();
	sb1->Enabled = false;
	sb2->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::sb2Click(TObject *Sender)
{
	int iAge;
	char cpName[100];
  char cpBdate[100];
	char* cpMemo;
	String sDir;
  String sName;
  String sBdate;
	bool bMarried;

	sDir = ExtractFilePath( Application->ExeName );
	ApDS2->DatabaseName = sDir;
	ApDS2->Open();
	ApDS2->GoTop();

	do {
		// Read data out of data.dbf
		sName = ApDS2->GetString( "Name" );
   	StrPCopy( cpName, sName );
		iAge = ApDS2->GetInteger( "Age" );
		bMarried = ApDS2->GetLogical( "Married" );
		sBdate = ApDS2->GetString( "Bdate" );
		StrPCopy( cpBdate, sBdate );
		cpMemo = ApDS2->GetMemo( "Memo", 0 );

  	// Read data into ztest.dbf
		ApDS1->Append();
		ApDS1->Replace( "Name",    R_CHAR,    cpName );
		ApDS1->Replace( "Age",     R_INTEGER, &iAge );
  	ApDS1->Replace( "Married", R_LOGICAL, &bMarried );
    ApDS1->Replace( "Bdate",   R_CHAR,    cpBdate );
    ApDS1->Replace( "Memo",    R_MEMO,    cpMemo );

		ApDS2->Skip( 1L );

    // Deallocate memory used by GetMemo
		ApDS1->MemDealloc( cpMemo );
    } while (!ApDS2->Eof);

	ApDS1->GoTop();
	ApDS2->Close();
	ShowMessage( "Finished with Replace..." );
	sb2->Enabled = false;
	sb3->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::sb3Click(TObject *Sender)
{
	ApDS1->IndexTag( "", "NameTag", "Name", IDX_NONE, false, "" );
	ShowMessage( "Finished with IndexTag..." );
	sb3->Enabled = false;
	sb4->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::sb4Click(TObject *Sender)
{
	ApDS1->Query( "Name = 'Vicki'" );
	ShowMessage( "Finished with Query..." );
  sb4->Enabled = false;
	sb5->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::sb5Click(TObject *Sender)
{
  ApDS1->Query( "" );
	ShowMessage( "Reset Complete..." );
  sb5->Enabled = false;
	sb6->Enabled = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::sb6Click(TObject *Sender)
{
	// Limits view of records from "Rollo" to "Vicki"
	ApDS1->SetScope( "Rollo", "Vicki" );
  ShowMessage( "Finished Setting Scope..." );
	sb6->Enabled = false;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::GoodByeClick(TObject *Sender)
{
	Close();
}
//---------------------------------------------------------------------------
