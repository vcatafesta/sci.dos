//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Buttons.hpp>
#include <Classes.hpp>
#include <Controls.hpp>
#include <Db.hpp>
#include <DBCtrls.hpp>
#include <DBGrids.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <StdCtrls.hpp>
#include "ApoDSet.hpp"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TPanel *Panel1;
	TSpeedButton *sb1;
	TSpeedButton *sb2;
	TSpeedButton *sb3;
	TSpeedButton *sb4;
	TSpeedButton *GoodBye;
	TSpeedButton *sb5;
	TSpeedButton *sb6;
	TPanel *Panel2;
	TDBGrid *DBGrid1;
	TDBMemo *DBMemo1;
	TDataSource *DataSource1;
	TDataSource *DataSource2;
	TApolloEnv *ApolloEnv1;
	TApolloTable *ApDS1;
	TApolloTable *ApDS2;
	void __fastcall sb1Click(TObject *Sender);
	void __fastcall sb2Click(TObject *Sender);
	
	void __fastcall sb3Click(TObject *Sender);
	void __fastcall sb4Click(TObject *Sender);
	void __fastcall sb5Click(TObject *Sender);
	void __fastcall sb6Click(TObject *Sender);
	void __fastcall GoodByeClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
