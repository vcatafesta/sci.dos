//---------------------------------------------------------------------------
//#include <bde.hpp>
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma link "Grids"
#pragma link "ApoDSet"
#pragma link "ApoDSet"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DataSource1DataChange(TObject *Sender, TField *Field)
{
	 Label1->Caption = IntToStr( Apollo1->RecNo ) + "/" +
                      IntToStr( Apollo1->RecCount );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
  /* Create index on UPPER(LAST+FIRST) */
  Screen->Cursor = crHourGlass;
  ProgressBar1->Visible = true;
  Apollo1->SetGaugeHook( int( Form1->Handle ));
  Apollo1->IndexTag( "", "NAME", "UPPER(LAST+FIRST)", IDX_NONE, false, "" );
  Apollo1->SetGaugeHook( 0 );
  Sleep(100);   // Pause just a bit so we can see the gauge at 100%
  ProgressBar1->Position = 0;
  Screen->Cursor = crDefault;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormKeyDown(TObject *Sender, WORD &Key,
	TShiftState Shift)
{
  WORD wVal;
  if ((Key && 0x7000) != 0)
  {
    wVal = -Char(Key);
    ProgressBar1->Position = wVal;
    Key = 0;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
  Apollo1->DatabaseName = ExtractFilePath( Application->ExeName );
  Apollo1->Open();
}
//---------------------------------------------------------------------------
