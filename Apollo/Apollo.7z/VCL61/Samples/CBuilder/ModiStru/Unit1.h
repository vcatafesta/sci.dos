//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Buttons.hpp>
#include <Classes.hpp>
#include <Controls.hpp>
#include <Db.hpp>
#include <DBGrids.hpp>
#include <Dialogs.hpp>
#include <ExtCtrls.hpp>
#include <Grids.hpp>
#include <Menus.hpp>
#include <StdCtrls.hpp>
#include "ApoDSet.hpp"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TLabel *Label1;
	TLabel *Label2;
	TBevel *Bevel1;
	TLabel *Label3;
	TBevel *Bevel2;
	TBevel *Bevel3;
	TPanel *panProgress;
	TDBGrid *DBGrid1;
	TPanel *panStatus;
	TComboBox *cmbSource;
	TComboBox *cmbDest;
	TComboBox *cmbMemoBlock;
	TBitBtn *butInsert;
	TBitBtn *butDelete;
	TMainMenu *MainMenu1;
	TMenuItem *File1;
	TMenuItem *Open1;
	TMenuItem *Close1;
	TMenuItem *Save1;
	TMenuItem *SaveAs1;
	TMenuItem *N1;
	TMenuItem *Exit1;
	TMenuItem *About1;
	TOpenDialog *OpenDialog1;
	TSaveDialog *SaveDialog1;
	TDataSource *DataSource1;
	TApolloEnv *ApolloEnv1;
	TDataSource *DataSource2;
  TApolloTable *Ap1;
  TApolloTable *Ap2;
	void __fastcall FormCreate(TObject *Sender);
	void __fastcall FormKeyDown(TObject *Sender, WORD &Key, TShiftState Shift);
	void __fastcall Open1Click(TObject *Sender);
	void __fastcall Close1Click(TObject *Sender);
	void __fastcall Save1Click(TObject *Sender);
	void __fastcall SaveAs1Click(TObject *Sender);
	void __fastcall About1Click(TObject *Sender);
	void __fastcall cmbSourceChange(TObject *Sender);
	void __fastcall cmbDestChange(TObject *Sender);
	void __fastcall DBGrid1KeyPress(TObject *Sender, char &Key);
	void __fastcall butInsertClick(TObject *Sender);
	void __fastcall butDeleteClick(TObject *Sender);
private:	// User declarations
	void __fastcall TForm1::CleanUp( void );
	void __fastcall TForm1::MoveMemoFile( String sSource, String sDest );   
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
