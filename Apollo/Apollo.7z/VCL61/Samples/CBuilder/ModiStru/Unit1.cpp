/*-------------------------------------------------------------------
  Project:  MODISTRU.EXE - APOLLO Modify Structure Utiltity
  Author :  Loren Scott
  Notice :  Copyright (c)1999-2003 Vista Software
  Notes  :  For use with Apollo 6.0 (C++Builder).
-------------------------------------------------------------------*/

//---------------------------------------------------------------------------
//#include <bde.hpp>
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma link "Grids"
#pragma link "ApoDSet"
#pragma resource "*.dfm"
TForm1 *Form1;
String sAppPath;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
	sAppPath = ExtractFileDir( Application->ExeName );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormKeyDown(TObject *Sender, WORD &Key,
	TShiftState Shift)
{
  WORD wVal;
  if ((Key && 0x7000) != 0)
  {
  	wVal = -Char(Key);
   	panProgress->Caption = "Processing: " + IntToStr( wVal ) + "%";
   	Application->ProcessMessages();
	  Key = 0;

    if (wVal == 100)
    	panProgress->Caption = "";
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Open1Click(TObject *Sender)
{
	String s;
	char cpMsg[128];

	CleanUp();
	if (OpenDialog1->Execute())
  	{
		s = UpperCase( OpenDialog1->FileName );
   	Ap2->Close();
   	Ap2->DatabaseName = ExtractFileDir( s );
   	Ap2->TableName = ExtractFileName( s );
    if (cmbSource->Text == "Clipper")
			Ap2->TableType = ttSXNTX;
		else if (cmbSource->Text == "FoxPro")
			Ap2->TableType = ttSXFOX;
		else if (cmbSource->Text == "HiPer-SIx")
			Ap2->TableType = ttSXNSX;

	  try
		{
			Ap2->Open();
		}
		catch (...)
    {
			StrPCopy( cpMsg, "Unable to open " + s + ".\n" +
                "Make sure source table type is selected correctly." );
  		Application->MessageBox( cpMsg, "Error!", MB_ICONHAND | MB_OK );
     	return;
		}
		Screen->Cursor = crHourGlass;
		Ap2->CopyStructureExtended( sAppPath + "\\TEMP0001.DBF" );
    Ap2->Close();
    Ap1->TableName = "TEMP0001.DBF";
    Ap1->DatabaseName = sAppPath;
    Ap1->Open();
    Close1->Enabled = true;
    Save1->Enabled = true;
    SaveAs1->Enabled = true;
		panStatus->Caption = s;
    cmbSource->Enabled = false;
		Screen->Cursor = crDefault;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::MoveMemoFile( String sSource, String sDest )
{
	char cpFile[128];

	// Delete existing file
	if (cmbDest->Text == "Clipper")
		sDest = ChangeFileExt( sDest, ".DBT" );
	else if (cmbDest->Text == "FoxPro")
		sDest = ChangeFileExt( sDest, ".FPT" );
	else if (cmbDest->Text == "HiPer-SIx")
		sDest = ChangeFileExt( sDest, ".SMT" );
	StrPCopy( cpFile, sDest );
	DeleteFile( cpFile );

  // Rename temp file to new name
	if (cmbSource->Text == "Clipper")
		sSource = ChangeFileExt( sSource, ".DBT" );
	else if (cmbSource->Text == "FoxPro")
		sSource = ChangeFileExt( sSource, ".FPT" );
	else if (cmbSource->Text == "HiPer-SIx")
		sSource = ChangeFileExt( sSource, ".SMT" );
	RenameFile( sSource, sDest );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::CleanUp( void )
{
	char cpFile[128];

	Ap1->Close();
  Ap2->Close();
	cmbSource->Enabled = true;
	Close1->Enabled = false;
  Save1->Enabled = false;
  SaveAs1->Enabled = false;
  StrPCopy( cpFile, sAppPath + "\\TEMP0001.DBF" );
	DeleteFile( cpFile );
  StrPCopy( cpFile, sAppPath + "\\TEMP0002.DBF" );
	DeleteFile( cpFile );
  StrPCopy( cpFile, sAppPath + "\\TEMP0002.DBT" );
	DeleteFile( cpFile );
  StrPCopy( cpFile, sAppPath + "\\TEMP0002.FPT" );
	DeleteFile( cpFile );
  StrPCopy( cpFile, sAppPath + "\\TEMP0002.SMT" );
	DeleteFile( cpFile );
	panStatus->Caption = "";
	Screen->Cursor = crDefault;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Close1Click(TObject *Sender)
{
	CleanUp();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Save1Click(TObject *Sender)
{
	char cpFile[128];

	Screen->Cursor = crHourGlass;
 	Ap1->Pack();
 	Ap1->Close();
  if (!Ap2->CreateFrom( sAppPath + "\\TEMP0002.DBF",
                          sAppPath + "\\TEMP0001.DBF",
                          cmbDest->Items->IndexOf( cmbDest->Text )+1 ) )
  {
		Application->MessageBox( "Error Creating Temp Table", "Error!",
                               MB_ICONHAND | MB_OK );
   	CleanUp();
   	Close();
  }
	if (cmbDest->Text == "Clipper")
		Ap2->TableType = ttSXNTX;
	else if (cmbDest->Text == "FoxPro")
		Ap2->TableType = ttSXFOX;
	else if (cmbDest->Text == "HiPer-SIx")
		Ap2->TableType = ttSXNSX;
	Ap2->Exclusive = true;
	Ap2->Open();
 	ApolloEnv1->SetMemoBlockSize( StrToInt( cmbMemoBlock->Text ));
	Ap2->Pack();
	Ap2->SetGaugeHook( Word( Form1->Handle ));
 	Ap2->AppendFrom( panStatus->Caption,
                      cmbSource->Items->IndexOf( cmbSource->Text )+1, "" );
	Ap2->SetGaugeHook( 0 );

	// Move .DBF
  StrPCopy( cpFile, panStatus->Caption );
  DeleteFile( cpFile );
  RenameFile( sAppPath + "\\TEMP0002.DBF", panStatus->Caption );

	// Move Memo File (if any)
  MoveMemoFile( sAppPath + "\\TEMP0002.DBF", panStatus->Caption );

	Screen->Cursor = crDefault;
  ShowMessage( panStatus->Caption + " modified." );
  CleanUp();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SaveAs1Click(TObject *Sender)
{
	String s;
	char cpMsg[128];

	if (SaveDialog1->Execute() )
  {
		Screen->Cursor = crHourGlass;
  	Ap1->Pack();
  	Ap1->Close();
		s = UpperCase( SaveDialog1->FileName );
		if (!Ap2->CreateFrom( s, sAppPath + "\\TEMP0001.DBF",
                           cmbDest->Items->IndexOf( cmbDest->Text )+1 ))
    {
			StrPCopy( cpMsg, "Error Creating Table: " + s );
  		Application->MessageBox( cpMsg, "Error!", MB_ICONHAND | MB_OK );
     	CleanUp();
     	Close();
    }
    Ap2->DatabaseName = ExtractFileDir( s );
		Ap2->TableName = ExtractFileName( s );

		if (cmbDest->Text == "Clipper")
			Ap2->TableType = ttSXNTX;
		else if (cmbDest->Text == "FoxPro")
			Ap2->TableType = ttSXFOX;
		else if (cmbDest->Text == "HiPer-SIx")
			Ap2->TableType = ttSXNSX;

		Ap2->Exclusive = true;
    Ap2->Open();
    ApolloEnv1->SetMemoBlockSize( StrToInt( cmbMemoBlock->Text ));
		Ap2->Pack();

   	Ap2->SetGaugeHook( Word( Form1->Handle ));
   	if (!Ap2->AppendFrom( panStatus->Caption,
                     cmbSource->Items->IndexOf( cmbSource->Text )+1, "" ))
		ShowMessage( "AppendFrom failed!" );
   	Ap2->SetGaugeHook( 0 );
		CleanUp();
		Screen->Cursor = crDefault;
   	ShowMessage( s + " created." );
 	}
}
//---------------------------------------------------------------------------
void __fastcall TForm1::About1Click(TObject *Sender)
{
	ShowMessage( "APOLLO Modify Structure Utility" );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::cmbSourceChange(TObject *Sender)
{
	cmbDest->Text = cmbSource->Text;
	cmbMemoBlock->Enabled = (cmbDest->Text != "Clipper");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::cmbDestChange(TObject *Sender)
{
	cmbMemoBlock->Enabled = (cmbDest->Text != "Clipper");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DBGrid1KeyPress(TObject *Sender, char &Key)
{
	Key = UpCase( Key );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::butInsertClick(TObject *Sender)
{
	int iRecPos;
	char caRecBuf[20];

	Ap1->FieldByName("FIELD_NAME")->Required = false;
	Ap1->FieldByName("FIELD_TYPE")->Required = false;
	Ap1->FieldByName("FIELD_LEN")->Required = false;
	Ap1->FieldByName("FIELD_DEC")->Required = false;

  Ap1->SpeedMode = TRUE;
	Ap1->DisableControls();
	iRecPos = Ap1->RecNo;             // Save current record position
  Ap1->GoBottom();                  // Move to last field definition
  Ap1->ApolloGetRecord( caRecBuf ); // Read in field definition data
  Ap1->AppendBlank();               // Add new record
  Ap1->Commit();                    // Commit new, blank record
  Ap1->PutRecord( caRecBuf );       // Write data from previous rec
  Ap1->GoBottom();                  // Make SURE we're on the new rec
  Ap1->Skip( -1L );                 // Move back to last record
  while (Ap1->RecNo > iRecPos)      // While not yet at insert point
	{
		Ap1->Skip( -1L );                 // Move up one,
    if (Ap1->Bof)
      break;
   	Ap1->ApolloGetRecord( caRecBuf ); // Read in field definition data
    Ap1->Skip( 1L );                  // Move back down and...
    Ap1->PutRecord( caRecBuf );       // Write data from previous rec
 		Ap1->Skip( -1L );                 // Move up one,
 	}
 	Ap1->PutRecord( PChar( "                    " ));   // 20 spaces
  Ap1->Go( iRecPos );                // Make SURE we're on the new rec
  Ap1->SpeedMode = FALSE;
  Ap1->Edit();                       // and put it in Edit mode
  Ap1->Refresh();
 	Ap1->EnableControls();
  DBGrid1->SetFocus();

	Ap1->FieldByName("FIELD_NAME")->Required = true;
	Ap1->FieldByName("FIELD_TYPE")->Required = true;
	Ap1->FieldByName("FIELD_LEN")->Required = true;
	Ap1->FieldByName("FIELD_DEC")->Required = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::butDeleteClick(TObject *Sender)
{
	int iRecPos;

	Ap1->FieldByName("FIELD_NAME")->Required = false;
	Ap1->FieldByName("FIELD_TYPE")->Required = false;
	Ap1->FieldByName("FIELD_LEN")->Required = false;
	Ap1->FieldByName("FIELD_DEC")->Required = false;

	Ap1->DisableControls();

   // If we are removing last record...
	if ( Ap1->RecNo == Ap1->RecCount )
 	{
 		Ap1->Skip( -1L );
		iRecPos = Ap1->RecNo;  // Save previous record number
    Ap1->Skip( 1L );
	}
	else
 	{
 		Ap1->Skip( 1L );
		iRecPos = Ap1->RecNo;  // Save next record number
    Ap1->Skip( -1 );
 	}
	Ap1->Delete();           // Delete selected record and...
  Ap1->Go( iRecPos );      //  ...move to saved record position
  Ap1->Refresh();
	Ap1->EnableControls();
  DBGrid1->SetFocus();

	Ap1->FieldByName("FIELD_NAME")->Required = true;
	Ap1->FieldByName("FIELD_TYPE")->Required = true;
	Ap1->FieldByName("FIELD_LEN")->Required = true;
	Ap1->FieldByName("FIELD_DEC")->Required = true;
}
//---------------------------------------------------------------------------