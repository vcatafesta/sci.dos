/*-------------------------------------------------------------------
  Project:  CREATOR.EXE - Apollo Table Creation Utiltity
  Author :  Loren Scott
  Notice :  Copyright (c)1999-2003 Vista Software
  Notes  :  For use with Apollo 6.x (C++Builder).
-------------------------------------------------------------------*/

//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "Unit1.h"

//---------------------------------------------------------------------------
#pragma link "Grids"
#pragma link "ApoDSet"
#pragma resource "*.dfm"
TForm1 *Form1;
String sAppPath;

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
	char cpPath[255];

	sAppPath = ExtractFileDir( Application->ExeName );
	if (!ApDS1->CreateNew( sAppPath + "\\TEMP0001.DBF", SDEFOX, 4 ))
	{
   	ShowMessage( sAppPath + "\\TEMP0001.DBF Create failed!" );
   	return;
	}
	ApDS1->CreateField( "FIELD_NAME", "C", 10, 0 );
  ApDS1->CreateField( "FIELD_TYPE", "C",  1, 0 );
	ApDS1->CreateField( "FIELD_LEN",  "N",  5, 0 );
  ApDS1->CreateField( "FIELD_DEC",  "N",  3, 0 );
	if (!ApDS1->CreateExec())
  {
		StrPCopy( cpPath, sAppPath + "\\TEMP0001.DBF Create failed!" );
 		Application->MessageBox( cpPath, "Error!", MB_ICONHAND | MB_OK );
		return;
	}
	ApDS1->Close();
	ApDS1->DatabaseName = sAppPath;
	ApDS1->TableName = "TEMP0001.DBF";
	ApDS1->TableType = ttSXFOX;
	ApDS1->Open();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SaveAs1Click(TObject *Sender)
{
	String s;
	char cpMsg[128];

	if (SaveDialog1->Execute())
 	{
		Screen->Cursor = crHourGlass;
 		ApDS1->Pack();
 		ApDS1->Close();
		s = UpperCase( SaveDialog1->FileName );
   	ApolloEnv1->SetMemoBlockSize( StrToInt( cmbMemoBlock->Text ));
		if (!ApDS2->CreateFrom( s, sAppPath + "\\TEMP0001.DBF",
                           cmbDest->Items->IndexOf( cmbDest->Text )+1 ))
    	{
			StrPCopy( cpMsg, "Error Creating Table: " + s );
 			Application->MessageBox( cpMsg, "Error!", MB_ICONHAND | MB_OK );
     	return;
   	}
		ApDS2->Close();
		ApDS2->DatabaseName = ExtractFileDir( s );
		ApDS2->TableName = ExtractFileName( s );
		ApDS2->Exclusive = true;
		ApDS2->Open();
		ApDS2->Pack();
   	ApDS2->Close();
   	ApDS1->Close();
		Screen->Cursor = crDefault;
   	ShowMessage( s + " created." );
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Exit1Click(TObject *Sender)
{
	char cpFile[128];
	StrPCopy( cpFile, sAppPath + "\\TEMP0001.DBF" );
	DeleteFile( cpFile );
	Close();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::About1Click(TObject *Sender)
{
	ShowMessage( "Apollo Table Creation Utility" );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::cmbDestChange(TObject *Sender)
{
	cmbMemoBlock->Enabled = (cmbDest->Text != "Clipper");
}
//---------------------------------------------------------------------------
void __fastcall TForm1::butInsertClick(TObject *Sender)
{
	int iRecPos;
	char caRecBuf[20];

	ApDS1->FieldByName("FIELD_NAME")->Required = false;
	ApDS1->FieldByName("FIELD_TYPE")->Required = false;
	ApDS1->FieldByName("FIELD_LEN")->Required = false;
	ApDS1->FieldByName("FIELD_DEC")->Required = false;

	ApDS1->DisableControls();
	iRecPos = ApDS1->RecNo;             // Save current record position
	ApDS1->GoBottom();                  // Move to last field definition
  ApDS1->ApolloGetRecord( caRecBuf ); // Read in field definition data
  ApDS1->AppendBlank();               // Add new record
  ApDS1->Post();                      // Commit new, blank record
  ApDS1->PutRecord( caRecBuf );       // Write data from previous rec
  ApDS1->GoBottom();                  // Make SURE we're on the new rec
  ApDS1->Skip( -1L );                 // Move back to last record
  while (ApDS1->RecNo > iRecPos)      // While not yet at insert point
 	{
		ApDS1->Skip( -1L );                 // Move up one,
		ApDS1->ApolloGetRecord( caRecBuf ); // Read in field definition data
		ApDS1->Skip( 1L );                  // Move back down and...
		ApDS1->PutRecord( caRecBuf );       // Write data from previous rec
	}
	ApDS1->PutRecord( PChar( "                    " ));   // 20 spaces
  ApDS1->Go( iRecPos );               // Make SURE we're on the new rec
  ApDS1->Edit();                      // and put it in Edit mode
	ApDS1->Refresh();
	ApDS1->EnableControls();
  DBGrid1->SetFocus();

	ApDS1->FieldByName("FIELD_NAME")->Required = true;
	ApDS1->FieldByName("FIELD_TYPE")->Required = true;
	ApDS1->FieldByName("FIELD_LEN")->Required = true;
	ApDS1->FieldByName("FIELD_DEC")->Required = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::butDeleteClick(TObject *Sender)
{
	int iRecPos;

	ApDS1->FieldByName("FIELD_NAME")->Required = false;
	ApDS1->FieldByName("FIELD_TYPE")->Required = false;
	ApDS1->FieldByName("FIELD_LEN")->Required = false;
	ApDS1->FieldByName("FIELD_DEC")->Required = false;

	ApDS1->DisableControls();

	// If we are removing last record..->
	if (ApDS1->RecNo == ApDS1->RecCount)
  {
 		ApDS1->Skip( -1L );
		iRecPos = ApDS1->RecNo;    // Save previous record number
		ApDS1->Skip( 1L );
	}
	else
	{
		ApDS1->Skip( 1L );
		iRecPos = ApDS1->RecNo;     // Save next record number
		ApDS1->Skip( -1L );
	}
	ApDS1->Delete();              // Delete selected record and...
 	ApDS1->Go( iRecPos );         //  ...move to saved record position
  ApDS1->Refresh();
	ApDS1->EnableControls();
  DBGrid1->SetFocus();

	ApDS1->FieldByName("FIELD_NAME")->Required = true;
	ApDS1->FieldByName("FIELD_TYPE")->Required = true;
	ApDS1->FieldByName("FIELD_LEN")->Required = true;
	ApDS1->FieldByName("FIELD_DEC")->Required = true;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DBGrid1KeyPress(TObject *Sender, char &Key)
{
	Key = UpCase( Key );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DataSource1DataChange(TObject *Sender, TField *Field)
{
	if (ApDS1->RecCount == 0)
	 	SaveAs1->Enabled = false;
	else
		SaveAs1->Enabled = true;
}
//---------------------------------------------------------------------------