//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma link "Grids"
#pragma link "ApoDSet"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormCreate(TObject *Sender)
{
	String s1;

	// Save current drive/directory name to s1
	s1 = ExtractFilePath( Application->ExeName );

	ApDS->DatabaseName = s1;
  ApDS->Open();
	ApDS->Index( s1 + "\\Test.Idx", "Upper(LAST+FIRST)", IDX_EMPTY, false, "" );
 	ApDS->SetOrder( 0 );
  ApDS->GoTop();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton1Click(TObject *Sender)
{
	if (!ApDS->KeyAdd( "Test.Idx" ))
		ShowMessage( "Key Add Failed!" );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton2Click(TObject *Sender)
{
	if (ApDS->KeyDrop( "Test.Idx" ))
  {
  	ApDS->Skip( 1L );
		if (ApDS->Eof)
   		ApDS->GoTop();
		ApDS->Refresh();
	}
	else
		ShowMessage( "Key Drop Failed!" );
}
//---------------------------------------------------------------------------
void __fastcall TForm1::SpeedButton3Click(TObject *Sender)
{
	if (SpeedButton3->Caption == "View Keys")
  {
   	SpeedButton1->Enabled = false;
   	SpeedButton2->Enabled = true;
	 	ApDS->IndexOpen( ExtractFilePath( Application->ExeName ) + "\\Test.Idx" );
		SpeedButton3->Caption = "View All";
		ApDS->GoTop();
	}
	else
   {
     	SpeedButton1->Enabled = true;
	   	SpeedButton2->Enabled = false;
     	ApDS->SetOrder( 0 );
      SpeedButton3->Caption = "View Keys";
      ApDS->GoTop();
	}
}
//---------------------------------------------------------------------------
 