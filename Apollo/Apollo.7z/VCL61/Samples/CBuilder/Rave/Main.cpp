//---------------------------------------------------------------------------
/*
This is a sample project showing Apollo Database Engine customers how to use
Apollo with the RAVE Reporting System

My personal opinion is that both of these products knock the socks off the
competition, especially when it comes to ease of deployment and use.
Anyone currently using Crystal Reports
should have a serious look at these tools!!!

Note:  I developed this sample project using Apollo VCL 5.2 RC7 and RAVE 4.01
        There is a bug in the end-user designer in this build of RAVE where you
        get a windows Access Violation when closing the RAVE Designer.
        This is apparently corrected in the latest version of RAVE.
        Although annoying, it doesn't seem to be detrimental to the projects.

Scott Prokopetz
proks@attcanada.ca
*/
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "ApoDSet"
#pragma link "ApoEnv"
#pragma link "RPBase"
#pragma link "RPCon"
#pragma link "RPConDS"
#pragma link "RPDefine"
#pragma link "RPRave"
#pragma link "RPSystem"
#pragma resource "*.dfm"
TMainForm *MainForm;
//---------------------------------------------------------------------------
__fastcall TMainForm::TMainForm(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::CreateRAVEReportBtnClick(TObject *Sender)
{
  // if you moved the project file to a different location, change it here
  // or in the Object Inspector directly
  RaveProject->ProjectFile = ExtractFilePath(Application->ExeName) +
                             "ApolloTableSample.rav"; 
  RaveProject->Open();
  // you can have many different reports in the same project file
  // so you must tell RAVE which report you want to run
  RaveProject->ExecuteReport("ApolloTestTable");
  RaveProject->Close();
}
//---------------------------------------------------------------------------
void __fastcall TMainForm::GotoRAVEDesignerBtnClick(TObject *Sender)
{
  RaveProject->Open();
  // you can have many different reports in the same project file
  // so you must tell RAVE which report you want to edit
  // *** RAVE returns True if the user made any changes to the report ***
  try
  {
    if (RaveProject->DesignReport("ApolloTestTable"))
      if (MessageDlg("Do you wish to Save Changes to Report(s)?", mtInformation,
                      TMsgDlgButtons() << mbYes << mbNo, 0) == mrYes)
        RaveProject->Save(); // save the changes to the report
  }
  catch (...)
  { // user is most likely missing the "ravesolo.dll" from the application's directory
    MessageDlg("Error Opening RAVE Designer.\n"
                "Be sure you have the file 'ravesolo.dll' in the same directory "
                "as this executable.", mtError, TMsgDlgButtons() << mbOK, 0);
  }
  RaveProject->Close();
}
//---------------------------------------------------------------------------

