//---------------------------------------------------------------------------

#ifndef MainH
#define MainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include "ApoDSet.hpp"
#include "ApoEnv.hpp"
#include "RPBase.hpp"
#include "RPCon.hpp"
#include "RPConDS.hpp"
#include "RPDefine.hpp"
#include "RPRave.hpp"
#include "RPSystem.hpp"
#include <Buttons.hpp>
#include <Db.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
  TApolloTable *ApolloTestTbl;
  TApolloDatabase *ApolloDatabase;
  TDataSource *DataSource1;
  TDBGrid *DBGrid1;
  TRPDataSetConnection *RPDataSetConnection1;
  TRaveProject *RaveProject;
  TReportSystem *ReportSystem;
  TBitBtn *GotoRAVEDesignerBtn;
  TBitBtn *CreateRAVEReportBtn;
  void __fastcall CreateRAVEReportBtnClick(TObject *Sender);
  void __fastcall GotoRAVEDesignerBtnClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
  __fastcall TMainForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
