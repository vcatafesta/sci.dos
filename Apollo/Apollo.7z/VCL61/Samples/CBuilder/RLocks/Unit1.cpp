// **************************************************************************
// This sample will only work with C++ Builder 4
// **************************************************************************
//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "ApoDSet"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}


//---------------------------------------------------------------------------
void __fastcall TForm1::UpdateStats( void )
{
	int i;
  int iCount;

	iCount = ap->LockCount;
	lblCount->Caption = IntToStr( iCount );
	lbLocks->Clear();
	for (i=0; i<iCount; i++)
  {
		lbLocks->Items->Add( IntToStr( ap->LockList[i-1] ));
	}
  IsLocked();
}

//---------------------------------------------------------------------------
void __fastcall TForm1::IsLocked( void )
{
  if (ap->Locked( ap->RecNo ))
		sBar->Panels->Items[1]->Text = "LOCKED";
  else
  	sBar->Panels->Items[1]->Text = "";
}

//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
	ap->Open();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnUnlockAllClick(TObject *Sender)
{
	Screen->Cursor = crHourGlass;
	ap->Unlock( 0 );
	UpdateStats();
	Screen->Cursor = crDefault;
}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnUnlockClick(TObject *Sender)
{
	Screen->Cursor = crHourGlass;
	ap->Unlock( ap->RecNo );
	UpdateStats();
	Screen->Cursor = crDefault;

}
//---------------------------------------------------------------------------
void __fastcall TForm1::btnLockClick(TObject *Sender)
{
	if (!ap->RLock( ap->RecNo ))
  {
  	ShowMessage( "RLock Failed!" );
  }
	UpdateStats();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::DataSource1DataChange(TObject *Sender,
      TField *Field)
{
	sBar->Panels->Items[0]->Text = IntToStr( ap->RecNo ) + " / " +
                          IntToStr( ap->RecCount );
  IsLocked();
}
//---------------------------------------------------------------------------
 
