//---------------------------------------------------------------------------
#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <ComCtrls.hpp>
#include <Controls.hpp>
#include <Db.hpp>
#include <DBGrids.hpp>
#include <Grids.hpp>
#include <StdCtrls.hpp>
#include "ApoDSet.hpp"
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TLabel *Label1;
	TLabel *lblCount;
	TDBGrid *DBGrid1;
	TButton *btnLock;
	TButton *btnUnlock;
	TListBox *lbLocks;
	TStatusBar *sBar;
	TButton *btnUnlockAll;
	TApolloTable *ap;
	TApolloEnv *ApolloEnv1;
	TDataSource *DataSource1;
	void __fastcall FormActivate(TObject *Sender);
	void __fastcall btnUnlockAllClick(TObject *Sender);
	void __fastcall btnUnlockClick(TObject *Sender);
	void __fastcall btnLockClick(TObject *Sender);
	void __fastcall DataSource1DataChange(TObject *Sender, TField *Field);
	void __fastcall UpdateStats( void );
	void __fastcall IsLocked( void );
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
 