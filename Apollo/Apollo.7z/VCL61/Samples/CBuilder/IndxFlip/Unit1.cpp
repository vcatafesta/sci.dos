//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma link "Grids"
#pragma link "ApoDSet"
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
	ApDS->IndexFlip();
	ApDS->Refresh();
}
//---------------------------------------------------------------------------
void __fastcall TForm1::FormActivate(TObject *Sender)
{
	ApDS->Exclusive = true;
	ApDS->TableType = ttSXFOX;
 	ApDS->Open();
 	ApDS->IndexTag( "", "NAME", "LAST+FIRST", IDX_NONE, false, "" );
 	ApDS->First();
}
//--------------------------------------------------------------------------- 